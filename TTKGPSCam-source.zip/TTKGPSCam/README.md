# TTK GPS Cam

Free, ad-free, account-free Android GPS camera (`com.ttk.gpscam`). It takes real photos with CameraX and burns a
configurable GPS dashboard (address, coordinates, map, date/time, altitude, speed, compass, accuracy, company logo) into the image.

## Build status — read this first
This source was written in an environment with **no Android SDK and no access to Google/Maven hosts, so it has NOT been compiled,
unit-tested, or run on a device or emulator.** No APK has been built. Expect that a first build may reveal compile errors that need small fixes.
The project is complete and a GitHub Actions workflow is included to build the debug APK.

## Get the APK (free, no local setup)
1. Create a new GitHub repository and push this folder (`git init && git add . && git commit -m init && git push`).
2. Open the repo → **Actions** → *Build TTK GPS Cam APK* (runs on push, or press *Run workflow*).
3. When it finishes, download the artifact **TTK-GPS-Cam-debug-apk** (contains `app-debug.apk`).
4. If the build fails, open the log; compile errors list file and line.

## Build locally
Android Studio (Ladybug or newer) → Open this folder → Run. Or: JDK 17 + Android SDK 35, then `./gradlew testDebugUnitTest assembleDebug`
→ `app/build/outputs/apk/debug/app-debug.apk`.

## Install
Copy `app-debug.apk` to the phone, open it, allow "Install unknown apps" for your file manager/browser when asked. Requires Android 10+ (API 29).

## Features
- CameraX preview, front/rear, flash auto/on/off, pinch + slider zoom, tap-to-focus, 4:3 / 16:9, resolution preference, orientation-correct capture.
- Real location via Fused Location Provider (high accuracy); shows Android's real accuracy in metres, categories Excellent ≤5 m, Good ≤15 m, Moderate ≤50 m, Poor >50 m.
  Statuses: acquiring, acquired, high/low accuracy, cached (stale >30 s, labelled), unavailable, permission denied, services off. Mock-provider and approximate-only warnings.
- Optional "require accurate location": waits up to 25 s for your threshold (10/20/50/custom); if not reached the photo is still taken and the real accuracy is stamped.
- Reverse geocoding with Android Geocoder (street, area, city, district, state, country, postal). Offline → coordinates only; address is never invented.
- 10 templates + saved custom templates; full editor (position, size, font, colours, opacity, radius, border, shadow, padding, spacing, alignment, map, text, formats, visibility).
- Company logo: PNG/JPG/WebP, transparency and aspect ratio preserved, size/opacity/position/alignment/padding/background/border/corner controls, persisted.
- Real OpenStreetMap tiles (also HOT and OpenTopoMap), disk cache, attribution drawn on the map. No tiles → photo is saved without the map.
- Gallery (Pictures/TTK GPS Cam): minimal 3-column grid, long-press to multi-select and delete, swipeable zoomable viewer with share, delete and GPS info. Each capture saves exactly ONE stamped photo and shows no "saved" notification.
- Map styles for the stamp: Esri Streets (Google-Maps-like, default, no API key), Standard OSM, Satellite (Esri imagery, optional) and more. Company logo can be uploaded straight from the stamp card in the camera preview (tap the dashed Logo slot).
- Live location screen: map, details, refresh, centre, zoom, copy, share (only on tap), open in maps app, map style.
- Settings persisted with DataStore; light/dark/system theme; privacy and about.

## Not implemented / limitations
- Optional extras (weather, QR, voice notes, tags, history, favourites, batch stamping, PDF, video) are not implemented.
- Photos from a previous install are not listed after reinstalling (Android scoped storage; avoids needing a storage permission).
- Compass is the device rotation-vector heading (direction the camera faces); it can be inaccurate near magnets.
- The front camera uses no screen flash. Resolution choice is a preference mapped to the closest supported size.
- Tile servers are community services; keep usage light. Address lookup depends on the phone's geocoder service.
- 16 MP decode cap when stamping very high-resolution (50/108 MP) photos to avoid out-of-memory; only the stamped photo is saved.


## Stamp card, rotation and intro
- Default template "GPS camera card": map thumbnail with a green tag, place name with flag, plus code + address, Lat/Long, date with GMT offset, logo slot on the right and a "TTK GPS Cam" tab above the top-right corner.
- The app UI is portrait-only; the live stamp card and the icons rotate smoothly with the phone (sensor based, works even with the system rotation lock on). The saved photo carries the card upright in the photo's own orientation.
- A ~2.8 s intro (two cats playing, then a "Created By Tasirul" bubble) plays on launch; tap to skip.

- Templates: six illustrated cards (Night glass, Cream wave, Neon night, Sunny polaroid, Starry night, Sunny sky) are the first six templates; they are drawn in code (CardStyles.kt) so the preview and the saved photo match. Pick one in the Templates tab. The colours of these cards are part of the design; the editor still controls position, size, which details are shown, formats, map style/zoom and the logo.
- The opening screen plays assets/intro.gif for 3 seconds (tap to skip) with a "Created By Tasirul" bubble.
