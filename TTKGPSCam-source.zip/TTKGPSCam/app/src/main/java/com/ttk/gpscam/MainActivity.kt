package com.ttk.gpscam

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.ttk.gpscam.data.ThemeMode
import com.ttk.gpscam.ui.CameraScreen
import com.ttk.gpscam.ui.GalleryScreen
import com.ttk.gpscam.ui.LocationScreen
import com.ttk.gpscam.ui.SettingsScreen
import com.ttk.gpscam.ui.TemplatesScreen
import com.ttk.gpscam.ui.TtkTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App(vm) }
    }

    override fun onStop() {
        super.onStop()
        vm.flush()
    }
}

private data class Tab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun App(vm: MainViewModel) {
    val settings by vm.settings.collectAsState()
    val viewerOpen by vm.viewerOpen.collectAsState()
    val s = settings
    val dark = when (s?.theme ?: ThemeMode.SYSTEM) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    var tab by rememberSaveable { mutableIntStateOf(1) }
    val snack = remember { SnackbarHostState() }
    val view = LocalView.current

    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val light = !(dark || tab == 1 || tab == 2 || viewerOpen)
            WindowCompat.getInsetsController(w, view).isAppearanceLightStatusBars = light
        }
    }

    // 0 Templates, 1 Camera, 2 Gallery, 3 Settings, 4 Location (opened from the GPS chip)
    val tabs = listOf(
        Tab("Templates", Icons.Outlined.Dashboard), Tab("Camera", Icons.Outlined.PhotoCamera),
        Tab("Gallery", Icons.Outlined.PhotoLibrary), Tab("Settings", Icons.Outlined.Settings),
    )

    var splash by rememberSaveable { androidx.compose.runtime.mutableStateOf(true) }
    TtkTheme(dark) {
      Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                if (!viewerOpen) Row(
                    Modifier.fillMaxWidth().background(Color(0xFF021812)).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    tabs.forEachIndexed { i, t ->
                        val sel = tab == i
                        Row(
                            Modifier.weight(if (sel) 1.35f else 1f).height(46.dp).clip(RoundedCornerShape(23.dp))
                                .background(if (sel) Color(0xFF1DE9B6) else Color(0x22FFFFFF))
                                .border(1.dp, if (sel) Color(0xFF1DE9B6) else Color(0x4D3FE0B0), RoundedCornerShape(23.dp))
                                .clickable { tab = i },
                            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (sel) {
                                androidx.compose.material3.Icon(t.icon, null, tint = Color(0xFF02221A), modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(
                                t.label, color = if (sel) Color(0xFF02221A) else Color(0xFFD7F5EA),
                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                                style = MaterialTheme.typography.labelLarge, maxLines = 1,
                            )
                        }
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background,
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(bottom = pad.calculateBottomPadding())) {
                if (s == null) CircularProgressIndicator(Modifier.align(Alignment.Center))
                else when (tab) {
                    0 -> TemplatesScreen(vm, s)
                    1 -> CameraScreen(vm, s, onOpenLocation = { tab = 4 }, onOpenSettings = { tab = 3 }, onOpenGallery = { tab = 2 })
                    2 -> GalleryScreen(vm, s)
                    3 -> SettingsScreen(vm, s, openEditor = { tab = 0 })
                    else -> LocationScreen(vm, s)
                }
            }
        }
        if (splash) com.ttk.gpscam.ui.IntroSplash { splash = false }
      }
    }
}
