package com.ttk.gpscam

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.ttk.gpscam.data.ThemeMode
import com.ttk.gpscam.ui.CameraScreen
import com.ttk.gpscam.ui.GalleryScreen
import com.ttk.gpscam.ui.LocationScreen
import com.ttk.gpscam.ui.SettingsScreen
import com.ttk.gpscam.ui.TemplatesScreen
import com.ttk.gpscam.ui.TtkTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App(vm) }
    }

    override fun onStop() {
        super.onStop()
        vm.flush()
    }
}

private data class Tab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun App(vm: MainViewModel) {
    val settings by vm.settings.collectAsState()
    val viewerOpen by vm.viewerOpen.collectAsState()
    val s = settings
    val dark = when (s?.theme ?: ThemeMode.SYSTEM) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    val view = LocalView.current

    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val light = !(dark || tab == 0 || viewerOpen)
            WindowCompat.getInsetsController(w, view).isAppearanceLightStatusBars = light
        }
    }

    val tabs = listOf(
        Tab("Camera", Icons.Outlined.PhotoCamera), Tab("Gallery", Icons.Outlined.PhotoLibrary),
        Tab("Templates", Icons.Outlined.Dashboard), Tab("Location", Icons.Outlined.Map), Tab("Settings", Icons.Outlined.Settings),
    )

    TtkTheme(dark) {
        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                if (!viewerOpen) NavigationBar {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(t.icon, t.label) }, label = { Text(t.label) })
                    }
                }
            },
            containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(bottom = pad.calculateBottomPadding())) {
                if (s == null) CircularProgressIndicator(Modifier.align(Alignment.Center))
                else when (tab) {
                    0 -> CameraScreen(vm, s)
                    1 -> GalleryScreen(vm, s)
                    2 -> TemplatesScreen(vm, s)
                    3 -> LocationScreen(vm, s)
                    else -> SettingsScreen(vm, s, openEditor = { tab = 2 })
                }
            }
        }
    }
}
