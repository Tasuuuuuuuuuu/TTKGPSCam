package com.ttk.gpscam

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ttk.gpscam.data.AppSettings
import com.ttk.gpscam.data.CustomTemplate
import com.ttk.gpscam.data.StampConfig
import com.ttk.gpscam.data.Templates
import com.ttk.gpscam.stamp.PhotoProcessor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed interface CaptureUi {
    data object Idle : CaptureUi
    data class Waiting(val accuracyM: Float?, val targetM: Int) : CaptureUi
    data object Saving : CaptureUi
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ttk = app as TtkApp
    private val repo = ttk.settingsRepo
    val location = ttk.locationRepo

    private val _settings = MutableStateFlow<AppSettings?>(null)
    val settings: StateFlow<AppSettings?> = _settings.asStateFlow()

    private val _logo = MutableStateFlow<Bitmap?>(null)
    val logo: StateFlow<Bitmap?> = _logo.asStateFlow()

    private val _capture = MutableStateFlow<CaptureUi>(CaptureUi.Idle)
    val capture: StateFlow<CaptureUi> = _capture.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    /** Bumped after every saved photo so the gallery reloads. */
    private val _galleryVersion = MutableStateFlow(0)
    val galleryVersion: StateFlow<Int> = _galleryVersion.asStateFlow()

    /** True while the full-screen gallery viewer is open (hides the bottom bar). */
    val viewerOpen = MutableStateFlow(false)

    private var persistJob: Job? = null
    private var captureJob: Job? = null
    @Volatile private var skipWait = false

    init {
        viewModelScope.launch {
            val s = repo.load()
            _settings.value = s
            if (s.logoSaved) _logo.value = withContext(Dispatchers.IO) { repo.loadLogo() }
        }
    }

    fun galleryChanged() { _galleryVersion.update { it + 1 } }

    fun toast(msg: String) { _messages.tryEmit(msg) }

    // ---------- settings ----------
    fun update(f: (AppSettings) -> AppSettings) {
        _settings.update { cur -> cur?.let(f) }
        persistJob?.cancel()
        persistJob = ttk.appScope.launch {
            delay(250)
            _settings.value?.let { repo.save(it) }
        }
    }

    fun updateStamp(f: (StampConfig) -> StampConfig) = update { it.copy(stamp = f(it.stamp)) }

    fun flush() {
        persistJob?.cancel()
        val s = _settings.value ?: return
        ttk.appScope.launch { repo.save(s) }
    }

    fun applyTemplate(id: String) = updateStamp { Templates.apply(id, it) }

    fun applyCustomTemplate(t: CustomTemplate) = updateStamp {
        // keep user's own text, company and logo file association, but take the saved look + logo style
        t.config.copy(templateId = t.id)
    }

    fun saveCustomTemplate(name: String) {
        val clean = name.trim().ifBlank { "My template" }
        update { s ->
            val id = "user_" + System.currentTimeMillis()
            s.copy(
                customTemplates = s.customTemplates + CustomTemplate(id, clean, s.stamp.copy(templateId = id)),
                stamp = s.stamp.copy(templateId = id),
            )
        }
        toast("Saved template “$clean”")
    }

    fun deleteCustomTemplate(id: String) = update { s ->
        s.copy(
            customTemplates = s.customTemplates.filterNot { it.id == id },
            stamp = if (s.stamp.templateId == id) s.stamp.copy(templateId = Templates.CUSTOM_ID) else s.stamp,
        )
    }

    /** Resets the current template to its built-in defaults (branding text and formats are kept). */
    fun resetCurrentTemplate() = updateStamp { cur ->
        val id = if (Templates.builtIn.any { it.id == cur.templateId }) cur.templateId else "classic"
        Templates.apply(id, StampConfig().copy(
            companyName = cur.companyName, title = cur.title, subtitle = cur.subtitle, customText = cur.customText,
        ))
    }

    fun resetAll() {
        viewModelScope.launch {
            persistJob?.cancel()
            repo.clear()
            _settings.value = AppSettings()
            _logo.value = null
            toast("All settings were reset")
        }
    }

    // ---------- logo ----------
    fun importLogo(uri: Uri) {
        viewModelScope.launch {
            repo.importLogo(uri).fold(
                onSuccess = { bmp ->
                    _logo.value = bmp
                    update { it.copy(logoSaved = true, logoVersion = it.logoVersion + 1, stamp = it.stamp.copy(logoOn = true)) }
                    toast("Logo saved")
                },
                onFailure = { toast(it.message ?: "Invalid logo file") },
            )
        }
    }

    fun removeLogo() {
        viewModelScope.launch {
            repo.deleteLogo()
            _logo.value = null
            update { it.copy(logoSaved = false, logoVersion = it.logoVersion + 1) }
            toast("Logo removed")
        }
    }

    // ---------- capture ----------
    fun skipAccuracyWait() { skipWait = true }

    fun capture(ic: ImageCapture) {
        if (captureJob?.isActive == true) return
        val s0 = _settings.value ?: return
        skipWait = false
        captureJob = viewModelScope.launch {
            try {
                var note: String? = null
                if (s0.requireAccurate) {
                    if (!waitForAccuracy(s0.accuracyThreshold)) {
                        note = "Target accuracy ±${s0.accuracyThreshold} m was not reached."
                    }
                }
                _capture.value = CaptureUi.Saving
                val s = _settings.value ?: s0
                val now = System.currentTimeMillis()
                val data = location.state.value.toStampData(now)
                val tmp = File(ttk.cacheDir, "cap_$now.jpg")
                try {
                    takePicture(ic, tmp)
                    val res = PhotoProcessor.processCapture(ttk, tmp, data, s, _logo.value)
                    _galleryVersion.update { it + 1 }
                    // No "saved" notification: only warn when something affects the result.
                    val parts = ArrayList<String>()
                    if (data.lat == null) parts += "No GPS fix, so no location was stamped."
                    if (res.mapMissing) parts += "Map omitted (offline)."
                    if (parts.isNotEmpty()) toast(parts.joinToString(" "))
                } finally {
                    tmp.delete()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast(e.message ?: "Capture failed")
            } finally {
                _capture.value = CaptureUi.Idle
            }
        }
    }

    private suspend fun waitForAccuracy(target: Int): Boolean {
        val deadline = System.currentTimeMillis() + 25_000L
        while (System.currentTimeMillis() < deadline && !skipWait) {
            val st = location.state.value
            val acc = st.fix?.accuracyM
            _capture.value = CaptureUi.Waiting(acc, target)
            if (acc != null && acc <= target && !st.isStale) return true
            delay(300)
        }
        val st = location.state.value
        return st.fix?.accuracyM?.let { it <= target && !st.isStale } == true
    }

    private suspend fun takePicture(ic: ImageCapture, file: File): Unit = suspendCancellableCoroutine<Unit> { cont ->
        val opts = ImageCapture.OutputFileOptions.Builder(file).build()
        ic.takePicture(opts, ContextCompat.getMainExecutor(ttk), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) { if (cont.isActive) cont.resume(Unit) }
            override fun onError(e: ImageCaptureException) {
                if (cont.isActive) cont.resumeWithException(java.io.IOException("Camera capture failed: ${e.message}"))
            }
        })
    }
}
