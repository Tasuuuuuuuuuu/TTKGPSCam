package com.ttk.gpscam

import android.app.Application
import com.ttk.gpscam.data.SettingsRepository
import com.ttk.gpscam.location.LocationRepo
import com.ttk.gpscam.map.TileStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class TtkApp : Application() {
    lateinit var settingsRepo: SettingsRepository
        private set
    lateinit var locationRepo: LocationRepo
        private set
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        settingsRepo = SettingsRepository(this)
        locationRepo = LocationRepo(this)
        appScope.launch(Dispatchers.IO) { TileStore.trimCache(this@TtkApp) }
    }
}
