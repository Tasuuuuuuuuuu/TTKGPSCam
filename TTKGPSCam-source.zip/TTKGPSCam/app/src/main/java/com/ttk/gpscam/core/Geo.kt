package com.ttk.gpscam.core

import java.util.Locale
import kotlin.math.*

enum class CoordFormat(val label: String) {
    DD("Decimal degrees"), DMS("Degrees, minutes, seconds"), DDM("Decimal minutes")
}

enum class UnitSystem(val label: String) { METRIC("Metric"), IMPERIAL("Imperial") }

enum class AccuracyLevel(val label: String) {
    EXCELLENT("Excellent"), GOOD("Good"), MODERATE("Moderate"), POOR("Poor")
}

/** Pure (Android-free) geo helpers so they can be unit-tested on the JVM. */
object Geo {
    /** Android reports horizontal accuracy as a 68% confidence radius in metres. */
    fun accuracyLevel(meters: Float): AccuracyLevel = when {
        meters <= 5f -> AccuracyLevel.EXCELLENT
        meters <= 15f -> AccuracyLevel.GOOD
        meters <= 50f -> AccuracyLevel.MODERATE
        else -> AccuracyLevel.POOR
    }

    fun coordinate(value: Double, isLat: Boolean, fmt: CoordFormat): String {
        val hemi = if (isLat) (if (value >= 0) "N" else "S") else (if (value >= 0) "E" else "W")
        val a = abs(value)
        return when (fmt) {
            CoordFormat.DD -> String.format(Locale.US, "%.6f° %s", a, hemi)
            CoordFormat.DMS -> {
                val cs = (a * 3600.0 * 100.0).roundToLong()
                val deg = cs / 360000L
                val min = (cs % 360000L) / 6000L
                val sec = (cs % 6000L) / 100.0
                String.format(Locale.US, "%d° %d′ %.2f″ %s", deg, min, sec, hemi)
            }
            CoordFormat.DDM -> {
                val u = (a * 60.0 * 10000.0).roundToLong()
                val deg = u / 600000L
                val min = (u % 600000L) / 10000.0
                String.format(Locale.US, "%d° %.4f′ %s", deg, min, hemi)
            }
        }
    }

    fun plainLatLon(lat: Double, lon: Double): String = String.format(Locale.US, "%.6f, %.6f", lat, lon)

    fun distance(m: Double, units: UnitSystem): String =
        if (units == UnitSystem.METRIC) String.format(Locale.US, "%.0f m", m)
        else String.format(Locale.US, "%.0f ft", m * 3.28084)

    fun accuracy(m: Float, units: UnitSystem): String =
        if (units == UnitSystem.METRIC) String.format(Locale.US, "±%.0f m", m.toDouble())
        else String.format(Locale.US, "±%.0f ft", m * 3.28084)

    fun speed(mps: Float, units: UnitSystem): String =
        if (units == UnitSystem.METRIC) String.format(Locale.US, "%.1f km/h", mps * 3.6)
        else String.format(Locale.US, "%.1f mph", mps * 2.23694)

    private val POINTS = arrayOf("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW")

    fun cardinal(deg: Float): String {
        val d = ((deg % 360f) + 360f) % 360f
        return POINTS[((d / 22.5f) + 0.5f).toInt() % 16]
    }

    fun heading(deg: Float): String {
        val d = ((deg % 360f) + 360f) % 360f
        return String.format(Locale.US, "%s %.0f°", cardinal(d), d.toDouble())
    }

    fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = p2 - p1
        val dl = Math.toRadians(lon2 - lon1)
        val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * r * asin(min(1.0, sqrt(a)))
    }

    fun ageText(ms: Long): String {
        val s = ms / 1000
        return when {
            s < 60 -> "${s}s"
            s < 3600 -> "${s / 60} min"
            else -> "${s / 3600} h"
        }
    }
}

/** Web-Mercator tile maths (OpenStreetMap slippy map). World pixels use 256px tiles. */
object TileMath {
    const val TILE = 256

    fun worldSize(z: Int): Double = TILE * 2.0.pow(z)

    fun worldX(lon: Double, z: Int): Double = (lon + 180.0) / 360.0 * worldSize(z)

    fun worldY(lat: Double, z: Int): Double {
        val l = lat.coerceIn(-85.05112878, 85.05112878)
        val s = sin(Math.toRadians(l))
        return (0.5 - ln((1 + s) / (1 - s)) / (4 * PI)) * worldSize(z)
    }

    fun lonFromX(x: Double, z: Int): Double = x / worldSize(z) * 360.0 - 180.0

    fun latFromY(y: Double, z: Int): Double {
        val n = PI - 2 * PI * y / worldSize(z)
        return Math.toDegrees(atan(sinh(n)))
    }

    fun metersPerPixel(lat: Double, z: Int): Double =
        156543.03392 * cos(Math.toRadians(lat)) / 2.0.pow(z)
}
