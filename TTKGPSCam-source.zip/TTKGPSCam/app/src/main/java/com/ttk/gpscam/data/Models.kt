package com.ttk.gpscam.data

import com.ttk.gpscam.core.CoordFormat
import com.ttk.gpscam.core.UnitSystem
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

enum class StampPosition(val label: String) {
    TOP_LEFT("Top left"), TOP_CENTER("Top center"), TOP_RIGHT("Top right"),
    BOTTOM_LEFT("Bottom left"), BOTTOM_CENTER("Bottom center"), BOTTOM_RIGHT("Bottom right")
}

enum class MapPos(val label: String) { LEFT("Left"), RIGHT("Right"), TOP("Top") }
enum class LogoPos(val label: String) { LEFT("Left"), RIGHT("Right"), TOP("Top"), BOTTOM("Bottom") }
enum class LogoAlign(val label: String) { START("Start"), CENTER("Center"), END("End") }
enum class TextAlignment(val label: String) { LEFT("Left"), CENTER("Center"), RIGHT("Right") }
enum class FontFace(val label: String) { SANS("Sans"), SERIF("Serif"), MONO("Mono"), CONDENSED("Condensed"), LIGHT("Light") }

enum class LayoutKind {
    CLASSIC, MODERN, COMPACT, MAP_FOCUS, FULL_ADDRESS, COORDS_FOCUS, MINIMAL, BUSINESS, LANDSCAPE
}

enum class MapStyle(val label: String, private val url: String, val attribution: String, val maxZoom: Int) {
    VOYAGER("Streets (CARTO Voyager)", "https://a.basemaps.cartocdn.com/rastertiles/voyager/%d/%d/%d.png", "© OpenStreetMap contributors © CARTO", 19),
    SATELLITE("Satellite (Esri)", "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/%1\$d/%3\$d/%2\$d", "Imagery © Esri, Maxar, Earthstar Geographics", 18),
    STANDARD("Standard (OpenStreetMap)", "https://tile.openstreetmap.org/%d/%d/%d.png", "© OpenStreetMap contributors", 19),
    HUMANITARIAN("Humanitarian (HOT)", "https://a.tile.openstreetmap.fr/hot/%d/%d/%d.png", "© OpenStreetMap contributors, HOT", 19),
    TOPO("Topographic (OpenTopoMap)", "https://a.tile.opentopomap.org/%d/%d/%d.png", "© OpenTopoMap (CC-BY-SA), © OSM contributors", 17);

    fun tileUrl(z: Int, x: Int, y: Int): String = String.format(Locale.US, url, z, x, y)
}

enum class FlashPref(val label: String) { AUTO("Auto"), ON("On"), OFF("Off") }
enum class ResPref(val label: String) { MAX("Maximum"), HIGH("High (~8 MP)"), STANDARD("Standard (~2 MP)") }
enum class AspectPref(val label: String) { R4_3("4:3"), R16_9("16:9") }
enum class ThemeMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

val DATE_FORMATS = listOf("dd MMM yyyy", "EEE, dd MMM yyyy", "yyyy-MM-dd", "dd/MM/yyyy", "MM/dd/yyyy")

private inline fun <reified E : Enum<E>> JSONObject.enumOr(key: String, def: E): E =
    runCatching { enumValueOf<E>(optString(key, def.name)) }.getOrDefault(def)

private fun JSONObject.f(key: String, def: Float): Float = optDouble(key, def.toDouble()).toFloat()

data class StampConfig(
    val templateId: String = "classic",
    val layout: LayoutKind = LayoutKind.CLASSIC,
    val position: StampPosition = StampPosition.BOTTOM_LEFT,
    val cardWidth: Float = 0.94f,
    val fontFace: FontFace = FontFace.SANS,
    val fontScale: Float = 1f,
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val bgColor: Int = 0xFF2B2B2B.toInt(),
    val bgOpacity: Float = 0.72f,
    val cardAlpha: Float = 1f,
    val cornerRadius: Float = 18f,
    val borderOn: Boolean = false,
    val borderColor: Int = 0xFFFFFFFF.toInt(),
    val borderWidth: Float = 2f,
    val shadow: Boolean = false,
    val padding: Float = 22f,
    val spacing: Float = 8f,
    val align: TextAlignment = TextAlignment.LEFT,
    // map
    val showMap: Boolean = true,
    val mapPos: MapPos = MapPos.LEFT,
    val mapSize: Float = 0.28f,
    val mapZoom: Int = 16,
    val mapStyle: MapStyle = MapStyle.VOYAGER,
    // visibility
    val showAddress: Boolean = true,
    val showCoords: Boolean = true,
    val showDate: Boolean = true,
    val showTime: Boolean = true,
    val showTimezone: Boolean = false,
    val showAltitude: Boolean = true,
    val showSpeed: Boolean = true,
    val showCompass: Boolean = true,
    val showAccuracy: Boolean = true,
    val showCompany: Boolean = true,
    val showAppBadge: Boolean = true,
    // text
    val companyName: String = "",
    val title: String = "",
    val subtitle: String = "",
    val customText: String = "",
    // formats
    val dateFormat: String = DATE_FORMATS[1],
    val use24h: Boolean = false,
    val showSeconds: Boolean = false,
    val coordFormat: CoordFormat = CoordFormat.DD,
    val units: UnitSystem = UnitSystem.METRIC,
    // logo
    val logoOn: Boolean = true,
    val logoSize: Float = 70f,          // max logo height in design units
    val logoOpacity: Float = 1f,
    val logoPos: LogoPos = LogoPos.RIGHT,
    val logoAlign: LogoAlign = LogoAlign.CENTER,
    val logoPadding: Float = 8f,
    val logoBgOn: Boolean = false,
    val logoBgColor: Int = 0xFFFFFFFF.toInt(),
    val logoBgOpacity: Float = 0.9f,
    val logoBorderOn: Boolean = false,
    val logoBorderColor: Int = 0xFFFFFFFF.toInt(),
    val logoCorner: Float = 10f,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("templateId", templateId); put("layout", layout.name); put("position", position.name)
        put("cardWidth", cardWidth.toDouble()); put("fontFace", fontFace.name); put("fontScale", fontScale.toDouble())
        put("textColor", textColor); put("bgColor", bgColor); put("bgOpacity", bgOpacity.toDouble())
        put("cardAlpha", cardAlpha.toDouble()); put("cornerRadius", cornerRadius.toDouble())
        put("borderOn", borderOn); put("borderColor", borderColor); put("borderWidth", borderWidth.toDouble())
        put("shadow", shadow); put("padding", padding.toDouble()); put("spacing", spacing.toDouble()); put("align", align.name)
        put("showMap", showMap); put("mapPos", mapPos.name); put("mapSize", mapSize.toDouble())
        put("mapZoom", mapZoom); put("mapStyle", mapStyle.name)
        put("showAddress", showAddress); put("showCoords", showCoords); put("showDate", showDate)
        put("showTime", showTime); put("showTimezone", showTimezone); put("showAltitude", showAltitude)
        put("showSpeed", showSpeed); put("showCompass", showCompass); put("showAccuracy", showAccuracy)
        put("showCompany", showCompany); put("showAppBadge", showAppBadge)
        put("companyName", companyName); put("title", title); put("subtitle", subtitle); put("customText", customText)
        put("dateFormat", dateFormat); put("use24h", use24h); put("showSeconds", showSeconds)
        put("coordFormat", coordFormat.name); put("units", units.name)
        put("logoOn", logoOn); put("logoSize", logoSize.toDouble()); put("logoOpacity", logoOpacity.toDouble())
        put("logoPos", logoPos.name); put("logoAlign", logoAlign.name); put("logoPadding", logoPadding.toDouble())
        put("logoBgOn", logoBgOn); put("logoBgColor", logoBgColor); put("logoBgOpacity", logoBgOpacity.toDouble())
        put("logoBorderOn", logoBorderOn); put("logoBorderColor", logoBorderColor); put("logoCorner", logoCorner.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject): StampConfig {
            val d = StampConfig()
            return StampConfig(
                templateId = o.optString("templateId", d.templateId),
                layout = o.enumOr("layout", d.layout),
                position = o.enumOr("position", d.position),
                cardWidth = o.f("cardWidth", d.cardWidth),
                fontFace = o.enumOr("fontFace", d.fontFace),
                fontScale = o.f("fontScale", d.fontScale),
                textColor = o.optInt("textColor", d.textColor),
                bgColor = o.optInt("bgColor", d.bgColor),
                bgOpacity = o.f("bgOpacity", d.bgOpacity),
                cardAlpha = o.f("cardAlpha", d.cardAlpha),
                cornerRadius = o.f("cornerRadius", d.cornerRadius),
                borderOn = o.optBoolean("borderOn", d.borderOn),
                borderColor = o.optInt("borderColor", d.borderColor),
                borderWidth = o.f("borderWidth", d.borderWidth),
                shadow = o.optBoolean("shadow", d.shadow),
                padding = o.f("padding", d.padding),
                spacing = o.f("spacing", d.spacing),
                align = o.enumOr("align", d.align),
                showMap = o.optBoolean("showMap", d.showMap),
                mapPos = o.enumOr("mapPos", d.mapPos),
                mapSize = o.f("mapSize", d.mapSize),
                mapZoom = o.optInt("mapZoom", d.mapZoom),
                mapStyle = o.enumOr("mapStyle", d.mapStyle),
                showAddress = o.optBoolean("showAddress", d.showAddress),
                showCoords = o.optBoolean("showCoords", d.showCoords),
                showDate = o.optBoolean("showDate", d.showDate),
                showTime = o.optBoolean("showTime", d.showTime),
                showTimezone = o.optBoolean("showTimezone", d.showTimezone),
                showAltitude = o.optBoolean("showAltitude", d.showAltitude),
                showSpeed = o.optBoolean("showSpeed", d.showSpeed),
                showCompass = o.optBoolean("showCompass", d.showCompass),
                showAccuracy = o.optBoolean("showAccuracy", d.showAccuracy),
                showCompany = o.optBoolean("showCompany", d.showCompany),
                showAppBadge = o.optBoolean("showAppBadge", d.showAppBadge),
                companyName = o.optString("companyName", d.companyName),
                title = o.optString("title", d.title),
                subtitle = o.optString("subtitle", d.subtitle),
                customText = o.optString("customText", d.customText),
                dateFormat = o.optString("dateFormat", d.dateFormat),
                use24h = o.optBoolean("use24h", d.use24h),
                showSeconds = o.optBoolean("showSeconds", d.showSeconds),
                coordFormat = o.enumOr("coordFormat", d.coordFormat),
                units = o.enumOr("units", d.units),
                logoOn = o.optBoolean("logoOn", d.logoOn),
                logoSize = o.f("logoSize", d.logoSize),
                logoOpacity = o.f("logoOpacity", d.logoOpacity),
                logoPos = o.enumOr("logoPos", d.logoPos),
                logoAlign = o.enumOr("logoAlign", d.logoAlign),
                logoPadding = o.f("logoPadding", d.logoPadding),
                logoBgOn = o.optBoolean("logoBgOn", d.logoBgOn),
                logoBgColor = o.optInt("logoBgColor", d.logoBgColor),
                logoBgOpacity = o.f("logoBgOpacity", d.logoBgOpacity),
                logoBorderOn = o.optBoolean("logoBorderOn", d.logoBorderOn),
                logoBorderColor = o.optInt("logoBorderColor", d.logoBorderColor),
                logoCorner = o.f("logoCorner", d.logoCorner),
            )
        }
    }
}

data class CustomTemplate(val id: String, val name: String, val config: StampConfig)

data class AppSettings(
    // camera
    val frontCamera: Boolean = false,
    val flash: FlashPref = FlashPref.AUTO,
    val resolution: ResPref = ResPref.MAX,
    val aspect: AspectPref = AspectPref.R4_3,
    val defaultZoom: Float = 1f,
    // gps
    val requireAccurate: Boolean = false,
    val accuracyThreshold: Int = 20,
    // output
    val jpegQuality: Int = 95,
    val saveOriginal: Boolean = false,
    val stampEnabled: Boolean = true,
    // app
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val liveMapStyle: MapStyle = MapStyle.VOYAGER,
    // stamp
    val stamp: StampConfig = StampConfig(),
    val customTemplates: List<CustomTemplate> = emptyList(),
    val logoSaved: Boolean = false,
    val logoVersion: Int = 0,
    val schema: Int = 2,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("schema", schema)
        put("frontCamera", frontCamera); put("flash", flash.name); put("resolution", resolution.name)
        put("aspect", aspect.name); put("defaultZoom", defaultZoom.toDouble())
        put("requireAccurate", requireAccurate); put("accuracyThreshold", accuracyThreshold)
        put("jpegQuality", jpegQuality); put("saveOriginal", saveOriginal); put("stampEnabled", stampEnabled)
        put("theme", theme.name); put("liveMapStyle", liveMapStyle.name)
        put("stamp", stamp.toJson())
        put("logoSaved", logoSaved); put("logoVersion", logoVersion)
        put("customTemplates", JSONArray().also { arr ->
            customTemplates.forEach { t ->
                arr.put(JSONObject().put("id", t.id).put("name", t.name).put("config", t.config.toJson()))
            }
        })
    }

    companion object {
        fun fromJson(o: JSONObject): AppSettings {
            val d = AppSettings()
            val templates = ArrayList<CustomTemplate>()
            val arr = o.optJSONArray("customTemplates")
            if (arr != null) for (i in 0 until arr.length()) {
                val t = arr.optJSONObject(i) ?: continue
                val cfg = t.optJSONObject("config") ?: continue
                templates += CustomTemplate(t.optString("id"), t.optString("name", "Custom"), StampConfig.fromJson(cfg))
            }
            val oldSchema = o.optInt("schema", 1)
            val loadedStamp = o.optJSONObject("stamp")?.let { StampConfig.fromJson(it) } ?: d.stamp
            // Schema 2 changed the default look (map style, logo on the right): upgrade old saved looks once.
            val stamp = if (oldSchema < 2) StampConfig().copy(companyName = loadedStamp.companyName) else loadedStamp
            return AppSettings(
                frontCamera = o.optBoolean("frontCamera", d.frontCamera),
                flash = o.enumOr("flash", d.flash),
                resolution = o.enumOr("resolution", d.resolution),
                aspect = o.enumOr("aspect", d.aspect),
                defaultZoom = o.f("defaultZoom", d.defaultZoom),
                requireAccurate = o.optBoolean("requireAccurate", d.requireAccurate),
                accuracyThreshold = o.optInt("accuracyThreshold", d.accuracyThreshold),
                jpegQuality = o.optInt("jpegQuality", d.jpegQuality),
                saveOriginal = false,
                stampEnabled = o.optBoolean("stampEnabled", d.stampEnabled),
                theme = o.enumOr("theme", d.theme),
                liveMapStyle = if (oldSchema < 2) d.liveMapStyle else o.enumOr("liveMapStyle", d.liveMapStyle),
                stamp = stamp,
                customTemplates = templates,
                logoSaved = o.optBoolean("logoSaved", d.logoSaved),
                logoVersion = o.optInt("logoVersion", d.logoVersion),
                schema = 2,
            )
        }
    }
}

/** Real address parts returned by the platform geocoder. Never invented. */
data class AddressInfo(
    val line: String?, val street: String?, val area: String?, val city: String?,
    val district: String?, val state: String?, val country: String?, val postal: String?,
    val forLat: Double, val forLon: Double,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("line", line ?: JSONObject.NULL); put("street", street ?: JSONObject.NULL); put("area", area ?: JSONObject.NULL)
        put("city", city ?: JSONObject.NULL); put("district", district ?: JSONObject.NULL); put("state", state ?: JSONObject.NULL)
        put("country", country ?: JSONObject.NULL); put("postal", postal ?: JSONObject.NULL)
        put("forLat", forLat); put("forLon", forLon)
    }

    companion object {
        private fun JSONObject.s(k: String): String? = if (isNull(k)) null else optString(k).takeIf { it.isNotBlank() }
        fun fromJson(o: JSONObject) = AddressInfo(
            o.s("line"), o.s("street"), o.s("area"), o.s("city"), o.s("district"), o.s("state"),
            o.s("country"), o.s("postal"), o.optDouble("forLat"), o.optDouble("forLon"),
        )
    }
}

/** Everything the stamp needs, captured at shutter time. Null lat/lon means no GPS fix existed. */
data class StampData(
    val lat: Double?, val lon: Double?, val accuracyM: Float?, val altitudeM: Double?,
    val speedMps: Float?, val headingDeg: Float?, val captureTimeMs: Long, val fixTimeMs: Long?,
    val fixAgeMs: Long?, val tzId: String, val isMock: Boolean, val address: AddressInfo?,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("lat", lat ?: JSONObject.NULL); put("lon", lon ?: JSONObject.NULL)
        put("accuracyM", accuracyM?.toDouble() ?: JSONObject.NULL); put("altitudeM", altitudeM ?: JSONObject.NULL)
        put("speedMps", speedMps?.toDouble() ?: JSONObject.NULL); put("headingDeg", headingDeg?.toDouble() ?: JSONObject.NULL)
        put("captureTimeMs", captureTimeMs); put("fixTimeMs", fixTimeMs ?: JSONObject.NULL)
        put("fixAgeMs", fixAgeMs ?: JSONObject.NULL); put("tzId", tzId); put("isMock", isMock)
        put("address", address?.toJson() ?: JSONObject.NULL)
    }

    companion object {
        fun fromJson(o: JSONObject): StampData = StampData(
            lat = if (o.isNull("lat")) null else o.optDouble("lat"),
            lon = if (o.isNull("lon")) null else o.optDouble("lon"),
            accuracyM = if (o.isNull("accuracyM")) null else o.optDouble("accuracyM").toFloat(),
            altitudeM = if (o.isNull("altitudeM")) null else o.optDouble("altitudeM"),
            speedMps = if (o.isNull("speedMps")) null else o.optDouble("speedMps").toFloat(),
            headingDeg = if (o.isNull("headingDeg")) null else o.optDouble("headingDeg").toFloat(),
            captureTimeMs = o.optLong("captureTimeMs"),
            fixTimeMs = if (o.isNull("fixTimeMs")) null else o.optLong("fixTimeMs"),
            fixAgeMs = if (o.isNull("fixAgeMs")) null else o.optLong("fixAgeMs"),
            tzId = o.optString("tzId", java.util.TimeZone.getDefault().id),
            isMock = o.optBoolean("isMock", false),
            address = o.optJSONObject("address")?.let { AddressInfo.fromJson(it) },
        )
    }
}
