package com.ttk.gpscam.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import kotlin.math.max

private val Context.dataStore by preferencesDataStore(name = "ttk_settings")

class SettingsRepository(private val context: Context) {
    private val key = stringPreferencesKey("settings_json")
    private val logoFile get() = File(context.filesDir, "company_logo.png")

    suspend fun load(): AppSettings {
        val raw = context.dataStore.data.first()[key] ?: return AppSettings()
        return runCatching { AppSettings.fromJson(JSONObject(raw)) }.getOrDefault(AppSettings())
    }

    suspend fun save(s: AppSettings) {
        context.dataStore.edit { it[key] = s.toJson().toString() }
    }

    suspend fun clear() {
        context.dataStore.edit { it.clear() }
        withContext(Dispatchers.IO) { logoFile.delete() }
    }

    fun loadLogo(): Bitmap? = runCatching {
        if (logoFile.exists()) BitmapFactory.decodeFile(logoFile.absolutePath) else null
    }.getOrNull()

    /**
     * Validates and stores a user-chosen logo as PNG (keeps transparency, never resized non-uniformly).
     * Returns the decoded bitmap, or a failure with a user-readable message.
     */
    suspend fun importLogo(uri: Uri): Result<Bitmap> = withContext(Dispatchers.IO) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                ?: return@withContext Result.failure(IllegalArgumentException("Could not open the selected file."))
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                return@withContext Result.failure(IllegalArgumentException("Unsupported or invalid image. Please choose a PNG, JPG or WebP file."))
            }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext Result.failure(IllegalArgumentException("The image could not be decoded."))
            logoFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            Result.success(bmp)
        } catch (e: OutOfMemoryError) {
            Result.failure(IllegalStateException("The logo is too large to load."))
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("Logo could not be loaded: ${e.message ?: "unknown error"}"))
        }
    }

    suspend fun deleteLogo() = withContext(Dispatchers.IO) { logoFile.delete(); Unit }
}
