package com.ttk.gpscam.data

data class TemplateDef(val id: String, val name: String, val description: String, val layout: LayoutKind)

object Templates {
    const val CUSTOM_ID = "custom"

    val builtIn = listOf(
        TemplateDef("card1", "Night glass", "Dark glass card with a monument skyline", LayoutKind.CARDS),
        TemplateDef("card2", "Cream wave", "Soft cream card with a camera badge", LayoutKind.CARDS),
        TemplateDef("card3", "Neon night", "Glowing neon border and a 3D pin", LayoutKind.CARDS),
        TemplateDef("card4", "Sunny polaroid", "Polaroid map, sun and paper plane", LayoutKind.CARDS),
        TemplateDef("card7", "Night polaroid", "Polaroid map, sleepy moon and stars", LayoutKind.CARDS),
        TemplateDef("card5", "Starry night", "Round map, moon and stars", LayoutKind.CARDS),
        TemplateDef("card6", "Sunny sky", "Blue sky, hills and a folded map", LayoutKind.CARDS),
        TemplateDef("gmc", "GPS camera card", "Map, place name, coordinates, date and app tab", LayoutKind.GMC),
        TemplateDef("classic", "Classic GPS stamp", "Map on the left, address, coordinates and time", LayoutKind.CLASSIC),
        TemplateDef("modern", "Modern professional", "Light card with a branded header", LayoutKind.MODERN),
        TemplateDef("compact", "Compact location card", "Small card, essentials only", LayoutKind.COMPACT),
        TemplateDef("map_focus", "Map-focused dashboard", "Large map above the details", LayoutKind.MAP_FOCUS),
        TemplateDef("full_address", "Full address dashboard", "Street, area, city, state, country, postal code", LayoutKind.FULL_ADDRESS),
        TemplateDef("coords", "Coordinates-focused", "Large latitude and longitude", LayoutKind.COORDS_FOCUS),
        TemplateDef("minimal", "Minimal", "Plain text with shadow, no card", LayoutKind.MINIMAL),
        TemplateDef("business", "Business documentation", "Label / value table for site records", LayoutKind.BUSINESS),
        TemplateDef("landscape", "Landscape dashboard", "Full-width two-column strip", LayoutKind.LANDSCAPE),
        TemplateDef(CUSTOM_ID, "Custom dashboard", "Keeps your own style settings", LayoutKind.CLASSIC),
    )

    fun nameOf(id: String, customs: List<CustomTemplate>): String =
        builtIn.firstOrNull { it.id == id }?.name ?: customs.firstOrNull { it.id == id }?.name ?: "Custom"

    /**
     * Applies a built-in template's look to [base]. Branding (company, texts, logo file/style),
     * formats (date, time, coordinates, units) and map zoom/style are always preserved.
     */
    fun apply(id: String, base: StampConfig): StampConfig {
        val c = base.copy(templateId = id)
        return when (id) {
            "card1" -> c.copy(
                layout = LayoutKind.CARDS, cardStyle = 1, cardWidth = 0.95f, showMap = true, align = TextAlignment.LEFT,
                logoOn = true, showAddress = true, showCoords = true, showDate = true, showTime = true, showTimezone = true,
                showAltitude = false, showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "card2" -> c.copy(
                layout = LayoutKind.CARDS, cardStyle = 2, cardWidth = 0.95f, showMap = true, align = TextAlignment.LEFT,
                logoOn = true, showAddress = true, showCoords = true, showDate = true, showTime = true, showTimezone = true,
                showAltitude = false, showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "card3" -> c.copy(
                layout = LayoutKind.CARDS, cardStyle = 3, cardWidth = 0.95f, showMap = true, align = TextAlignment.LEFT,
                logoOn = true, showAddress = true, showCoords = true, showDate = true, showTime = true, showTimezone = true,
                showAltitude = false, showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "card4" -> c.copy(
                layout = LayoutKind.CARDS, cardStyle = 4, cardWidth = 0.95f, showMap = true, align = TextAlignment.LEFT,
                logoOn = true, showAddress = true, showCoords = true, showDate = true, showTime = true, showTimezone = true,
                showAltitude = false, showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "card7" -> c.copy(
                layout = LayoutKind.CARDS, cardStyle = 7, cardWidth = 0.95f, showMap = true, align = TextAlignment.LEFT,
                logoOn = true, showAddress = true, showCoords = true, showDate = true, showTime = true, showTimezone = true,
                showAltitude = false, showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "card5" -> c.copy(
                layout = LayoutKind.CARDS, cardStyle = 5, cardWidth = 0.95f, showMap = true, align = TextAlignment.LEFT,
                logoOn = true, showAddress = true, showCoords = true, showDate = true, showTime = true, showTimezone = true,
                showAltitude = false, showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "card6" -> c.copy(
                layout = LayoutKind.CARDS, cardStyle = 6, cardWidth = 0.95f, showMap = true, align = TextAlignment.LEFT,
                logoOn = true, showAddress = true, showCoords = true, showDate = true, showTime = true, showTimezone = true,
                showAltitude = false, showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "gmc" -> c.copy(
                layout = LayoutKind.GMC, cardWidth = 0.95f, textColor = WHITE, bgColor = 0xFF3A3A38.toInt(), bgOpacity = 0.84f,
                cornerRadius = 14f, borderOn = false, shadow = false, fontScale = 1f, showMap = true, align = TextAlignment.LEFT,
                logoOn = true, showAddress = true, showCoords = true, showDate = true, showTime = true, showTimezone = true,
                showAltitude = false, showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "classic" -> c.copy(
                layout = LayoutKind.CLASSIC, cardWidth = 0.95f, textColor = WHITE, bgColor = 0xFF2B2B2B.toInt(), bgOpacity = 0.72f,
                cornerRadius = 22f, borderOn = false, shadow = false, padding = 20f, spacing = 8f, fontScale = 1f,
                showMap = true, mapPos = MapPos.LEFT, mapSize = 0.27f, align = TextAlignment.LEFT, logoPos = LogoPos.RIGHT, logoAlign = LogoAlign.CENTER,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = true,
                showSpeed = true, showCompass = true, showAccuracy = true,
            )
            "modern" -> c.copy(
                layout = LayoutKind.MODERN, cardWidth = 0.94f, textColor = 0xFF14202B.toInt(), bgColor = WHITE, bgOpacity = 0.93f,
                cornerRadius = 30f, borderOn = false, shadow = true, padding = 26f, spacing = 9f, fontScale = 1f,
                showMap = true, mapPos = MapPos.LEFT, mapSize = 0.26f, align = TextAlignment.LEFT, logoPos = LogoPos.RIGHT, logoAlign = LogoAlign.CENTER,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = true,
                showSpeed = false, showCompass = true, showAccuracy = true,
            )
            "compact" -> c.copy(
                layout = LayoutKind.COMPACT, cardWidth = 0.66f, textColor = WHITE, bgColor = BLACK, bgOpacity = 0.6f,
                cornerRadius = 14f, borderOn = false, shadow = false, padding = 16f, spacing = 5f, fontScale = 0.85f,
                showMap = true, mapPos = MapPos.LEFT, mapSize = 0.24f, align = TextAlignment.LEFT, logoPos = LogoPos.RIGHT,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = false,
                showSpeed = false, showCompass = false, showAccuracy = false,
            )
            "map_focus" -> c.copy(
                layout = LayoutKind.MAP_FOCUS, cardWidth = 0.9f, textColor = WHITE, bgColor = BLACK, bgOpacity = 0.62f,
                cornerRadius = 22f, borderOn = false, shadow = false, padding = 16f, spacing = 7f, fontScale = 1f,
                showMap = true, mapPos = MapPos.TOP, mapSize = 0.5f, align = TextAlignment.LEFT, logoPos = LogoPos.BOTTOM,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = false,
                showSpeed = false, showCompass = false, showAccuracy = true,
            )
            "full_address" -> c.copy(
                layout = LayoutKind.FULL_ADDRESS, cardWidth = 0.94f, textColor = WHITE, bgColor = 0xFF0B2A3A.toInt(), bgOpacity = 0.7f,
                cornerRadius = 18f, borderOn = false, shadow = false, padding = 22f, spacing = 8f, fontScale = 1f,
                showMap = true, mapPos = MapPos.RIGHT, mapSize = 0.22f, align = TextAlignment.LEFT, logoPos = LogoPos.TOP,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = true,
                showSpeed = false, showCompass = false, showAccuracy = true,
            )
            "coords" -> c.copy(
                layout = LayoutKind.COORDS_FOCUS, cardWidth = 0.86f, textColor = WHITE, bgColor = BLACK, bgOpacity = 0.6f,
                cornerRadius = 20f, borderOn = true, borderColor = 0xFFFBBF24.toInt(), borderWidth = 2f, shadow = false,
                padding = 24f, spacing = 8f, fontScale = 1f, showMap = false, mapPos = MapPos.LEFT, mapSize = 0.25f,
                align = TextAlignment.CENTER, logoPos = LogoPos.TOP, logoAlign = LogoAlign.CENTER,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = true,
                showSpeed = false, showCompass = true, showAccuracy = true,
            )
            "minimal" -> c.copy(
                layout = LayoutKind.MINIMAL, cardWidth = 0.92f, textColor = WHITE, bgColor = BLACK, bgOpacity = 0f,
                cornerRadius = 0f, borderOn = false, shadow = true, padding = 8f, spacing = 5f, fontScale = 0.95f,
                showMap = false, align = TextAlignment.LEFT, logoPos = LogoPos.LEFT,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = false,
                showSpeed = false, showCompass = false, showAccuracy = false, showAppBadge = false,
            )
            "business" -> c.copy(
                layout = LayoutKind.BUSINESS, cardWidth = 0.94f, textColor = 0xFF111827.toInt(), bgColor = WHITE, bgOpacity = 0.95f,
                cornerRadius = 8f, borderOn = true, borderColor = 0xFF0F766E.toInt(), borderWidth = 3f, shadow = false,
                padding = 22f, spacing = 6f, fontScale = 0.95f, showMap = true, mapPos = MapPos.RIGHT, mapSize = 0.24f,
                align = TextAlignment.LEFT, logoPos = LogoPos.LEFT,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = true,
                showSpeed = false, showCompass = true, showAccuracy = true,
            )
            "landscape" -> c.copy(
                layout = LayoutKind.LANDSCAPE, cardWidth = 1f, textColor = WHITE, bgColor = BLACK, bgOpacity = 0.6f,
                cornerRadius = 0f, borderOn = false, shadow = false, padding = 18f, spacing = 6f, fontScale = 0.9f,
                showMap = true, mapPos = MapPos.LEFT, mapSize = 0.2f, align = TextAlignment.LEFT, logoPos = LogoPos.RIGHT,
                position = if (c.position.name.startsWith("TOP")) StampPosition.TOP_CENTER else StampPosition.BOTTOM_CENTER,
                showAddress = true, showCoords = true, showDate = true, showTime = true, showAltitude = true,
                showSpeed = true, showCompass = true, showAccuracy = true,
            )
            else -> c // custom: keep user's style as-is
        }
    }

    private const val WHITE = 0xFFFFFFFF.toInt()
    private const val BLACK = 0xFF000000.toInt()
}
