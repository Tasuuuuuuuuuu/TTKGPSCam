package com.ttk.gpscam.location

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.google.android.gms.location.CurrentLocationRequest
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.core.AccuracyLevel
import com.ttk.gpscam.data.AddressInfo
import com.ttk.gpscam.data.StampData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs

data class LocationFix(
    val lat: Double,
    val lon: Double,
    val accuracyM: Float?,
    val altitudeM: Double?,
    val speedMps: Float?,
    val bearingDeg: Float?,
    val fixTimeMs: Long,
    val elapsedNs: Long,
    val isMock: Boolean,
) {
    fun ageMs(): Long = ((SystemClock.elapsedRealtimeNanos() - elapsedNs) / 1_000_000L).coerceAtLeast(0L)
}

enum class GpsStatus(val label: String) {
    PERMISSION_DENIED("Permission denied"),
    SERVICES_DISABLED("Location services disabled"),
    ACQUIRING("Acquiring GPS…"),
    UNAVAILABLE("GPS unavailable"),
    STALE("Cached location"),
    LOW_ACCURACY("Low accuracy"),
    ACQUIRED("Location acquired"),
    HIGH_ACCURACY("High accuracy"),
}

data class LocState(
    val status: GpsStatus = GpsStatus.ACQUIRING,
    val fix: LocationFix? = null,
    val ageMs: Long = 0L,
    val address: AddressInfo? = null,
    val addressMessage: String? = null,
    val heading: Float? = null,
    val approxOnly: Boolean = false,
) {
    val accuracyLevel: AccuracyLevel? get() = fix?.accuracyM?.let { Geo.accuracyLevel(it) }
    val hasFix: Boolean get() = fix != null
    val isStale: Boolean get() = fix != null && ageMs > STALE_MS

    /** Warning text shown to the user when the fix should not be trusted blindly. */
    val warning: String?
        get() = when {
            approxOnly -> "Only approximate location permission granted – accuracy is limited."
            fix == null -> null
            isStale -> "This is a cached location from ${Geo.ageText(ageMs)} ago."
            fix.isMock -> "A mock/test location provider is active."
            (fix.accuracyM ?: 0f) > 50f -> "Low accuracy (${Geo.accuracy(fix.accuracyM ?: 0f, com.ttk.gpscam.core.UnitSystem.METRIC)}). Move to open sky for a better fix."
            else -> null
        }

    fun toStampData(captureTimeMs: Long): StampData {
        val f = fix
        val addr = address?.takeIf { f != null && Geo.haversineMeters(it.forLat, it.forLon, f.lat, f.lon) < 75.0 }
        return StampData(
            lat = f?.lat, lon = f?.lon, accuracyM = f?.accuracyM, altitudeM = f?.altitudeM,
            speedMps = f?.speedMps, headingDeg = heading, captureTimeMs = captureTimeMs,
            fixTimeMs = f?.fixTimeMs, fixAgeMs = f?.ageMs(), tzId = TimeZone.getDefault().id,
            isMock = f?.isMock ?: false, address = addr,
        )
    }

    companion object { const val STALE_MS = 30_000L }
}

/**
 * Single source of truth for location. Uses the Fused Location Provider with high-accuracy priority.
 * Updates run only while at least one screen has called [acquire] (ref-counted), saving battery.
 */
class LocationRepo(private val app: Context) {
    private val fused = LocationServices.getFusedLocationProviderClient(app)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val compass = CompassSensor(app)

    private val _state = MutableStateFlow(LocState())
    val state: StateFlow<LocState> = _state.asStateFlow()

    private var users = 0
    private var callback: LocationCallback? = null
    private var tick: Job? = null
    private var geocodeJob: Job? = null
    private var startedAt = 0L

    private var fix: LocationFix? = null
    private var address: AddressInfo? = null
    private var addressMessage: String? = null
    private var lastGeocodeAttempt = 0L

    fun hasFine() = ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    fun hasCoarse() = ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    fun hasPermission() = hasFine() || hasCoarse()

    fun servicesEnabled(): Boolean {
        val lm = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return LocationManagerCompat.isLocationEnabled(lm)
    }

    fun acquire() {
        users++
        if (users == 1) start()
    }

    fun release() {
        if (users > 0) users--
        if (users == 0) stop()
    }

    /** Call after the user changed location permission. */
    fun onPermissionChanged() {
        if (users > 0) { stop(); start() } else publish()
    }

    /** Drops the current fix and asks the platform for a brand-new one. */
    fun refresh() {
        fix = null; address = null; addressMessage = null
        startedAt = SystemClock.elapsedRealtime()
        publish()
        if (!hasPermission()) return
        try {
            val req = CurrentLocationRequest.Builder()
                .setPriority(if (hasFine()) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY)
                .setMaxUpdateAgeMillis(0)
                .setDurationMillis(15_000)
                .build()
            fused.getCurrentLocation(req, CancellationTokenSource().token)
                .addOnSuccessListener { l -> if (l != null) onLocation(l) }
        } catch (_: SecurityException) { publish() }
        if (users > 0 && callback == null) start()
    }

    private fun start() {
        startedAt = SystemClock.elapsedRealtime()
        if (!hasPermission()) { publish(); return }
        val priority = if (hasFine()) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        val req = LocationRequest.Builder(priority, 1000L).setMinUpdateIntervalMillis(500L).build()
        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) { result.lastLocation?.let { onLocation(it) } }
        }
        callback = cb
        try {
            fused.requestLocationUpdates(req, cb, Looper.getMainLooper())
            // Seed with last known location, but it is flagged as cached via its real age.
            fused.lastLocation.addOnSuccessListener { l -> if (l != null && fix == null) onLocation(l) }
        } catch (_: SecurityException) { callback = null }
        compass.start { fix?.let { f -> declinationFor(f) } ?: 0f }
        tick = scope.launch {
            while (isActive) { delay(1000); publish() }
        }
        publish()
    }

    private fun stop() {
        callback?.let { fused.removeLocationUpdates(it) }
        callback = null
        compass.stop()
        tick?.cancel(); tick = null
        geocodeJob?.cancel(); geocodeJob = null
    }

    @Suppress("DEPRECATION")
    private fun isMockLocation(l: Location): Boolean =
        if (Build.VERSION.SDK_INT >= 31) l.isMock else l.isFromMockProvider

    private fun declinationFor(f: LocationFix): Float =
        GeomagneticField(f.lat.toFloat(), f.lon.toFloat(), (f.altitudeM ?: 0.0).toFloat(), System.currentTimeMillis()).declination

    private fun onLocation(l: Location) {
        val mock = isMockLocation(l)
        val newFix = LocationFix(
            lat = l.latitude, lon = l.longitude,
            accuracyM = if (l.hasAccuracy()) l.accuracy else null,
            altitudeM = if (l.hasAltitude()) l.altitude else null,
            speedMps = if (l.hasSpeed()) l.speed else null,
            bearingDeg = if (l.hasBearing()) l.bearing else null,
            fixTimeMs = l.time, elapsedNs = l.elapsedRealtimeNanos, isMock = mock,
        )
        // Ignore an older fix arriving after a newer one.
        val cur = fix
        if (cur != null && newFix.elapsedNs < cur.elapsedNs) return
        fix = newFix
        publish()
        maybeGeocode(newFix)
    }

    private fun publish() {
        val f = fix
        val perm = hasPermission()
        val age = f?.ageMs() ?: 0L
        val acc = f?.accuracyM
        val status = when {
            !perm -> GpsStatus.PERMISSION_DENIED
            !servicesEnabled() -> GpsStatus.SERVICES_DISABLED
            f == null -> if (SystemClock.elapsedRealtime() - startedAt > 40_000L) GpsStatus.UNAVAILABLE else GpsStatus.ACQUIRING
            age > LocState.STALE_MS -> GpsStatus.STALE
            acc == null || acc > 50f -> GpsStatus.LOW_ACCURACY
            acc <= 15f -> GpsStatus.HIGH_ACCURACY
            else -> GpsStatus.ACQUIRED
        }
        val bearingHeading = if (f?.bearingDeg != null && (f.speedMps ?: 0f) > 1.5f) f.bearingDeg else null
        _state.value = LocState(
            status = status, fix = f, ageMs = age, address = address, addressMessage = addressMessage,
            heading = bearingHeading ?: compass.heading.value, approxOnly = perm && !hasFine(),
        )
    }

    private fun maybeGeocode(f: LocationFix) {
        val a = address
        val moved = a == null || Geo.haversineMeters(a.forLat, a.forLon, f.lat, f.lon) > 30.0
        if (!moved || geocodeJob?.isActive == true) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastGeocodeAttempt < 6000L) return
        lastGeocodeAttempt = now
        geocodeJob = scope.launch {
            val result = runCatching { reverse(f.lat, f.lon) }
            val info = result.getOrNull()
            if (info != null) {
                address = info; addressMessage = null
            } else if (result.isFailure) {
                addressMessage = "Address unavailable (no internet or geocoder service). Coordinates are still accurate."
            } else {
                addressMessage = "No address found for this location."
            }
            publish()
        }
    }

    @Suppress("DEPRECATION")
    private fun legacyLookup(g: Geocoder, lat: Double, lon: Double): Address? = g.getFromLocation(lat, lon, 1)?.firstOrNull()

    private suspend fun reverse(lat: Double, lon: Double): AddressInfo? {
        if (!Geocoder.isPresent()) throw IOException("No geocoder")
        val geocoder = Geocoder(app, Locale.getDefault())
        val addr: Address? = if (Build.VERSION.SDK_INT >= 33) {
            suspendCancellableCoroutine { cont ->
                geocoder.getFromLocation(lat, lon, 1, object : Geocoder.GeocodeListener {
                    override fun onGeocode(addresses: MutableList<Address>) { if (cont.isActive) cont.resume(addresses.firstOrNull()) }
                    override fun onError(errorMessage: String?) { if (cont.isActive) cont.resumeWithException(IOException(errorMessage ?: "geocoder error")) }
                })
            }
        } else {
            withContext(Dispatchers.IO) { legacyLookup(geocoder, lat, lon) }
        }
        addr ?: return null
        val street = listOfNotNull(addr.subThoroughfare, addr.thoroughfare).joinToString(" ").ifBlank { null }
        return AddressInfo(
            line = addr.getAddressLine(0)?.ifBlank { null }, street = street,
            area = addr.subLocality, city = addr.locality, district = addr.subAdminArea,
            state = addr.adminArea, country = addr.countryName, postal = addr.postalCode,
            forLat = lat, forLon = lon,
        )
    }
}

/** Rotation-vector based compass; reports degrees from true north for the direction the camera faces. */
class CompassSensor(ctx: Context) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    val heading = MutableStateFlow<Float?>(null)
    private var declination: () -> Float = { 0f }
    private val r = FloatArray(9)
    private val r2 = FloatArray(9)
    private val o = FloatArray(3)

    fun start(declinationProvider: () -> Float) {
        declination = declinationProvider
        sensor?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    fun stop() { sm.unregisterListener(this) }

    override fun onSensorChanged(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(r, e.values)
        SensorManager.getOrientation(r, o)
        var az = o[0]
        if (abs(Math.toDegrees(o[1].toDouble())) > 45.0) {
            // Phone held upright (typical camera use): use the back-camera axis.
            SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2)
            SensorManager.getOrientation(r2, o)
            az = o[0]
        }
        val deg = ((Math.toDegrees(az.toDouble()).toFloat() + declination() + 360f) % 360f)
        val cur = heading.value
        if (cur == null || abs(deg - cur).let { minOf(it, 360f - it) } > 2f) heading.value = deg
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
