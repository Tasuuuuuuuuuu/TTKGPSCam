package com.ttk.gpscam.map

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.LruCache
import com.ttk.gpscam.core.TileMath
import com.ttk.gpscam.data.MapStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.floor
import kotlin.math.max

/**
 * OpenStreetMap-compatible raster tiles with an on-disk cache (cacheDir/tiles).
 * Requests identify the app via User-Agent as required by the OSM tile usage policy.
 */
object TileStore {
    private const val UA = "TTKGPSCam/1.0 (Android; free open-source GPS camera)"
    private val memory = object : LruCache<String, Bitmap>(96) {}

    private fun file(ctx: Context, style: MapStyle, z: Int, x: Int, y: Int) =
        File(ctx.cacheDir, "tiles/${style.name}/$z/$x/$y.png")

    private fun key(style: MapStyle, z: Int, x: Int, y: Int) = "${style.name}/$z/$x/$y"

    /** Returns the tile, or null if it is neither cached nor downloadable. */
    suspend fun get(ctx: Context, style: MapStyle, z: Int, x: Int, y: Int, network: Boolean): Bitmap? {
        val k = key(style, z, x, y)
        synchronized(memory) { memory.get(k) }?.let { return it }
        return withContext(Dispatchers.IO) {
            val f = file(ctx, style, z, x, y)
            var bmp: Bitmap? = null
            if (f.exists() && f.length() > 0) {
                bmp = BitmapFactory.decodeFile(f.absolutePath)
                if (bmp == null) f.delete()
            }
            if (bmp == null && network) bmp = download(style, z, x, y, f)
            if (bmp != null) synchronized(memory) { memory.put(k, bmp) }
            bmp
        }
    }

    private fun download(style: MapStyle, z: Int, x: Int, y: Int, target: File): Bitmap? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(style.tileUrl(z, x, y)).openConnection() as HttpURLConnection).apply {
                connectTimeout = 4000; readTimeout = 5000
                setRequestProperty("User-Agent", UA)
            }
            if (conn.responseCode != 200) return null
            val bytes = conn.inputStream.use { it.readBytes() }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            target.parentFile?.mkdirs()
            val tmp = File(target.parentFile, target.name + ".tmp")
            tmp.writeBytes(bytes)
            tmp.renameTo(target)
            bmp
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    /** Keeps the tile cache below ~60 MB by deleting the oldest files. */
    fun trimCache(ctx: Context, maxBytes: Long = 60L * 1024 * 1024) {
        runCatching {
            val root = File(ctx.cacheDir, "tiles")
            val files = root.walkTopDown().filter { it.isFile }.toList()
            var total = files.sumOf { it.length() }
            if (total <= maxBytes) return
            for (f in files.sortedBy { it.lastModified() }) {
                total -= f.length(); f.delete()
                if (total <= maxBytes * 0.8) break
            }
        }
    }
}

object MapRenderer {
    /**
     * Renders a real map centred on [lat]/[lon] with a marker (and accuracy circle when meaningful).
     * Returns null when any required tile is unavailable – callers then simply omit the map.
     */
    suspend fun render(
        ctx: Context, style: MapStyle, lat: Double, lon: Double, zoomIn: Int,
        w: Int, h: Int, network: Boolean, accuracyM: Float?,
    ): Bitmap? {
        if (w < 32 || h < 32) return null
        val z = zoomIn.coerceIn(3, style.maxZoom)
        val n = 1 shl z
        val cx = TileMath.worldX(lon, z)
        val cy = TileMath.worldY(lat, z)
        val left = cx - w / 2.0
        val top = cy - h / 2.0
        val tx0 = floor(left / 256.0).toInt()
        val tx1 = floor((left + w - 1) / 256.0).toInt()
        val ty0 = floor(top / 256.0).toInt()
        val ty1 = floor((top + h - 1) / 256.0).toInt()

        data class T(val tx: Int, val ty: Int, val bmp: Bitmap?, val valid: Boolean)

        val tiles = coroutineScope {
            val jobs = ArrayList<kotlinx.coroutines.Deferred<T>>()
            for (ty in ty0..ty1) for (tx in tx0..tx1) {
                jobs += async {
                    if (ty < 0 || ty >= n) T(tx, ty, null, false)
                    else T(tx, ty, TileStore.get(ctx, style, z, ((tx % n) + n) % n, ty, network), true)
                }
            }
            jobs.awaitAll()
        }
        if (tiles.any { it.valid && it.bmp == null }) return null

        val out = try { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) } catch (e: OutOfMemoryError) { return null }
        val c = Canvas(out)
        c.drawColor(Color.rgb(221, 224, 228))
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        for (t in tiles) t.bmp?.let { c.drawBitmap(it, (t.tx * 256 - left).toFloat(), (t.ty * 256 - top).toFloat(), p) }

        val mx = w / 2f
        val my = h / 2f
        val minSide = minOf(w, h).toFloat()
        // accuracy circle (only when it is visible and not larger than the map)
        if (accuracyM != null) {
            val rPx = (accuracyM / TileMath.metersPerPixel(lat, z)).toFloat()
            if (rPx > minSide * 0.03f && rPx < minSide * 0.5f) {
                val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(45, 25, 118, 210) }
                val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.argb(160, 25, 118, 210); style = Paint.Style.STROKE; strokeWidth = minSide * 0.006f
                }
                c.drawCircle(mx, my, rPx, fill); c.drawCircle(mx, my, rPx, stroke)
            }
        }
        drawPin(c, mx, my, minSide * 0.075f)
        drawAttribution(c, w, h, style.attribution)
        return out
    }

    /** Draws a pin whose tip is exactly at (x, y). */
    fun drawPin(c: Canvas, x: Float, y: Float, r: Float) {
        val cy = y - r * 2.1f
        val path = Path().apply {
            moveTo(x, y)
            lineTo(x - r * 0.88f, cy + r * 0.5f)
            lineTo(x + r * 0.88f, cy + r * 0.5f)
            close()
            addCircle(x, cy, r, Path.Direction.CW)
        }
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 0, 0, 0) }
        c.drawOval(RectF(x - r * 0.6f, y - r * 0.2f, x + r * 0.6f, y + r * 0.2f), shadow)
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(222, 53, 53) })
        c.drawCircle(x, cy, r * 0.42f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
    }

    private fun drawAttribution(c: Canvas, w: Int, h: Int, text: String) {
        val size = max(9f, w * 0.032f)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; color = Color.rgb(40, 40, 40) }
        val tw = tp.measureText(text)
        val bg = Paint().apply { color = Color.argb(190, 255, 255, 255) }
        val pad = size * 0.3f
        val availW = w.toFloat()
        if (tw + pad * 2 > availW) tp.textSize = size * (availW - pad * 2) / tw
        val tw2 = tp.measureText(text)
        c.drawRect(w - tw2 - pad * 2, h - tp.textSize - pad * 2, w.toFloat(), h.toFloat(), bg)
        c.drawText(text, w - tw2 - pad, h - pad - tp.descent(), tp)
    }
}
