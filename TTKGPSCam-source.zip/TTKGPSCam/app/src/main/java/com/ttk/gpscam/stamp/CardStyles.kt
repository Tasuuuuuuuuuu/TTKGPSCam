package com.ttk.gpscam.stamp

import android.graphics.BlurMaskFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.data.StampConfig
import com.ttk.gpscam.data.StampData
import com.ttk.gpscam.data.StampPosition
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max
import kotlin.math.min

/**
 * Six illustrated GPS cards (night glass, cream wave, neon night, sunny polaroid, starry night, sunny sky).
 * Everything is drawn with canvas code, so the live preview and the saved photo are identical.
 * All sizes are "design units" (short side of the image / 1080).
 */
object CardStyles {
    /** Map bitmap requested for the cards, in design units (square, centre-cropped). */
    const val MAP_REQ = 330f
    const val COUNT = 6

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
    private fun line(color: Int, width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = Paint.Style.STROKE; strokeWidth = width; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private fun vGrad(top: Float, bottom: Float, c0: Int, c1: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, top, 0f, bottom, c0, c1, Shader.TileMode.CLAMP)
    }
    private fun hGrad(left: Float, right: Float, c0: Int, c1: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(left, 0f, right, 0f, c0, c1, Shader.TileMode.CLAMP)
    }
    private fun argb(v: Long): Int = v.toInt()

    private class Look(val title: Int, val sub: Int, val pin: Int, val clock: Int)

    private fun look(s: Int): Look = when (s) {
        1 -> Look(argb(0xFFFFFFFF), argb(0xFFE6EEF3), argb(0xFF7FD3F7), argb(0xFFFFFFFF))
        2 -> Look(argb(0xFF1D1A2F), argb(0xFF2B2740), argb(0xFFE5383B), argb(0xFF8B5CF6))
        3 -> Look(argb(0xFFFFFFFF), argb(0xFFEAE6FF), argb(0xFF5EEAD4), argb(0xFFB9A7FF))
        4 -> Look(argb(0xFF1D1A2F), argb(0xFF2B2740), argb(0xFFFF5A5F), argb(0xFF3B82F6))
        5 -> Look(argb(0xFFFFFFFF), argb(0xFFE8E6FF), argb(0xFFB57BFF), argb(0xFFB57BFF))
        else -> Look(argb(0xFF0F2447), argb(0xFF16305A), argb(0xFFF59E0B), argb(0xFF7C5CE0))
    }

    // ---------------------------------------------------------------- small drawing helpers

    private fun cloud(c: Canvas, cx: Float, cy: Float, s: Float, p: Paint) {
        c.drawCircle(cx - s * 0.55f, cy, s * 0.42f, p)
        c.drawCircle(cx, cy - s * 0.25f, s * 0.55f, p)
        c.drawCircle(cx + s * 0.6f, cy, s * 0.4f, p)
        c.drawRoundRect(RectF(cx - s * 0.95f, cy - s * 0.05f, cx + s * 1.0f, cy + s * 0.42f), s * 0.2f, s * 0.2f, p)
    }

    private fun roundTree(c: Canvas, x: Float, base: Float, s: Float, leaf: Int, leaf2: Int) {
        c.drawRoundRect(RectF(x - s * 0.07f, base - s * 0.5f, x + s * 0.07f, base), s * 0.03f, s * 0.03f, fill(argb(0xFF6B4A2B)))
        c.drawCircle(x, base - s * 0.8f, s * 0.42f, fill(leaf))
        c.drawCircle(x - s * 0.18f, base - s * 0.7f, s * 0.3f, fill(leaf2))
    }

    private fun pine(c: Canvas, x: Float, base: Float, s: Float, color: Int) {
        val p = Path().apply {
            moveTo(x, base - s)
            lineTo(x + s * 0.3f, base - s * 0.45f); lineTo(x + s * 0.14f, base - s * 0.45f)
            lineTo(x + s * 0.4f, base); lineTo(x - s * 0.4f, base)
            lineTo(x - s * 0.14f, base - s * 0.45f); lineTo(x - s * 0.3f, base - s * 0.45f)
            close()
        }
        c.drawPath(p, fill(color))
    }

    private fun star4(c: Canvas, cx: Float, cy: Float, r: Float, p: Paint) {
        val path = Path().apply {
            moveTo(cx, cy - r); quadTo(cx, cy, cx + r, cy); quadTo(cx, cy, cx, cy + r)
            quadTo(cx, cy, cx - r, cy); quadTo(cx, cy, cx, cy - r); close()
        }
        c.drawPath(path, p)
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        val p = Path().apply {
            moveTo(cx, cy + s * 0.9f)
            cubicTo(cx - s * 1.5f, cy - s * 0.1f, cx - s * 0.6f, cy - s * 1.2f, cx, cy - s * 0.35f)
            cubicTo(cx + s * 0.6f, cy - s * 1.2f, cx + s * 1.5f, cy - s * 0.1f, cx, cy + s * 0.9f)
            close()
        }
        c.drawPath(p, fill(color))
    }

    private fun sparks(c: Canvas, x: Float, y: Float, u: Float, color: Int) {
        val p = line(color, 3.5f * u)
        c.drawLine(x, y, x + 14f * u, y - 12f * u, p)
        c.drawLine(x + 12f * u, y + 6f * u, x + 30f * u, y - 2f * u, p)
        c.drawLine(x + 2f * u, y + 16f * u, x + 18f * u, y + 18f * u, p)
    }

    private fun pinShape(cx: Float, cy: Float, r: Float): Path = Path().apply {
        // teardrop: circle of radius r centred at (cx, cy) with a tip below
        moveTo(cx, cy + r * 2.0f)
        cubicTo(cx - r * 0.2f, cy + r * 1.4f, cx - r * 1.0f, cy + r * 0.9f, cx - r, cy)
        arcTo(RectF(cx - r, cy - r, cx + r, cy + r), 180f, 180f, false)
        cubicTo(cx + r * 1.0f, cy + r * 0.9f, cx + r * 0.2f, cy + r * 1.4f, cx, cy + r * 2.0f)
        close()
    }

    private fun drawPin(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, holeColor: Int) {
        c.drawPath(pinShape(cx, cy, r), fill(color))
        c.drawCircle(cx, cy, r * 0.42f, fill(holeColor))
    }

    private fun drawClock(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, faceColor: Int) {
        c.drawCircle(cx, cy, r, fill(color))
        val h = line(faceColor, r * 0.18f)
        c.drawLine(cx, cy, cx, cy - r * 0.6f, h)
        c.drawLine(cx, cy, cx + r * 0.45f, cy + r * 0.2f, h)
    }

    /** kind: 0 satellite, 1 camera, 2 paper plane */
    private fun glyph(c: Canvas, kind: Int, cx: Float, cy: Float, r: Float, color: Int) {
        val f = fill(color)
        val l = line(color, r * 0.2f)
        when (kind) {
            0 -> {
                c.save(); c.rotate(-40f, cx, cy)
                c.drawRoundRect(RectF(cx - r * 0.3f, cy - r * 0.3f, cx + r * 0.3f, cy + r * 0.3f), r * 0.1f, r * 0.1f, f)
                c.drawRect(cx - r * 1.0f, cy - r * 0.22f, cx - r * 0.45f, cy + r * 0.22f, f)
                c.drawRect(cx + r * 0.45f, cy - r * 0.22f, cx + r * 1.0f, cy + r * 0.22f, f)
                c.drawLine(cx, cy + r * 0.3f, cx, cy + r * 0.8f, l)
                c.restore()
            }
            1 -> {
                c.drawRoundRect(RectF(cx - r, cy - r * 0.62f, cx + r, cy + r * 0.78f), r * 0.28f, r * 0.28f, f)
                c.drawRect(cx - r * 0.38f, cy - r * 0.92f, cx + r * 0.3f, cy - r * 0.55f, f)
                c.drawCircle(cx, cy + r * 0.1f, r * 0.44f, fill(argb(0x66000000)))
                c.drawCircle(cx, cy + r * 0.1f, r * 0.3f, fill(argb(0xFFFFFFFF)))
            }
            else -> {
                val p = Path().apply {
                    moveTo(cx - r, cy - r * 0.1f); lineTo(cx + r, cy - r * 0.85f); lineTo(cx + r * 0.25f, cy + r * 0.85f)
                    lineTo(cx - r * 0.1f, cy + r * 0.2f); close()
                }
                c.drawPath(p, f)
                c.drawLine(cx - r * 0.1f, cy + r * 0.2f, cx + r, cy - r * 0.85f, line(argb(0x66FFFFFF), r * 0.12f))
            }
        }
    }

    private fun wavy(r: RectF, cr: Float, amp: Float, n: Int): Path {
        val p = Path()
        val seg = (r.width() - 2 * cr) / n
        p.moveTo(r.left + cr, r.top)
        for (i in 0 until n) {
            val dy = if (i % 2 == 0) -amp * 2f else amp * 2f
            p.quadTo(r.left + cr + seg * (i + 0.5f), r.top + dy, r.left + cr + seg * (i + 1), r.top)
        }
        p.quadTo(r.right, r.top, r.right, r.top + cr)
        p.lineTo(r.right, r.bottom - cr)
        p.quadTo(r.right, r.bottom, r.right - cr, r.bottom)
        for (i in n - 1 downTo 0) {
            val dy = if (i % 2 == 0) amp * 2f else -amp * 2f
            p.quadTo(r.left + cr + seg * (i + 0.5f), r.bottom + dy, r.left + cr + seg * i, r.bottom)
        }
        p.quadTo(r.left, r.bottom, r.left, r.bottom - cr)
        p.lineTo(r.left, r.top + cr)
        p.quadTo(r.left, r.top, r.left + cr, r.top)
        p.close()
        return p
    }

    private fun textLayout(text: CharSequence, p: TextPaint, w: Int, maxLines: Int) =
        StaticLayout.Builder.obtain(text, 0, text.length, p, w.coerceAtLeast(1))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(false).setLineSpacing(0f, 1.02f)
            .setMaxLines(maxLines).setEllipsize(TextUtils.TruncateAt.END).build()

    // ---------------------------------------------------------------- main layout + paint

    fun compose(
        canvas: Canvas?, w: Int, h: Int, u: Float, c: StampConfig, d: StampData, map: Bitmap?, logo: Bitmap?,
        y0: Float, placeholder: Boolean, hit: StampRenderer.StampHit?,
    ): Float {
        val st = c.cardStyle.coerceIn(1, COUNT)
        val lk = look(st)
        val fs = c.fontScale
        val margin = 24f * u
        val cardW = min(w - 2 * margin, 1060f * u * (c.cardWidth / 0.95f).coerceIn(0.5f, 1.1f))
        val x0 = when (c.position) {
            StampPosition.TOP_LEFT, StampPosition.BOTTOM_LEFT -> margin
            StampPosition.TOP_RIGHT, StampPosition.BOTTOM_RIGHT -> w - margin - cardW
            else -> (w - cardW) / 2f
        }
        val pad = 24f * u
        val gap = 22f * u
        // map size follows the "Map size" slider (0.15..0.6): 130..300 design units; the round map is a little larger
        val ms = (if (st == 5) 1.1f else 1f) * (130f + 170f * ((c.mapSize - 0.15f) / 0.45f).coerceIn(0f, 1f)) * u
        val msFrame = if (st == 4) ms + 26f * u else ms
        val showMap = c.showMap && d.lat != null && map != null
        val realLogo = c.logoOn && logo != null && !logo.isRecycled && logo.width > 0 && logo.height > 0
        val logoOn = realLogo || (c.logoOn && placeholder)
        val logoW = 130f * u
        val textW = cardW - 2 * pad - (if (showMap) msFrame + gap else 0f) - (if (logoOn) logoW + gap else 0f)
        val gutter = 40f * u * fs
        val tz = TimeZone.getTimeZone(d.tzId)

        fun tp(sizeU: Float, bold: Boolean, color: Int) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = sizeU * u * fs
            typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
            this.color = color
        }

        val a = d.address
        val lat = d.lat
        val lon = d.lon
        var titleL: StaticLayout? = null
        val rows = ArrayList<Pair<StaticLayout, Int>>() // layout, icon kind (0 none, 1 pin, 2 clock)
        if (lat == null || lon == null) {
            titleL = textLayout("GPS location unavailable", tp(38f, true, lk.title), textW.toInt(), 3)
        } else {
            if (c.showAddress) {
                val head = listOfNotNull(a?.city ?: a?.area, a?.state, a?.country).distinct().joinToString(", ")
                val flag = GmcCard.flagOf(a?.country)
                val base = if (head.isNotBlank()) head else (a?.line ?: "Location")
                titleL = textLayout(if (flag.isNotEmpty()) "$base  $flag" else base, tp(40f, true, lk.title), textW.toInt(), 3)
            }
            if (c.showCoords) {
                val la = Geo.coordinate(lat, true, c.coordFormat)
                val lo = Geo.coordinate(lon, false, c.coordFormat)
                rows += Pair(textLayout("$la, $lo", tp(26f, false, lk.sub), (textW - gutter).toInt(), 2), 1)
            }
        }
        if (c.showDate || c.showTime) {
            val pat = (if (c.showDate) "EEE, dd/MM/yyyy" else "") + (if (c.showDate && c.showTime) " • " else "") +
                (if (c.showTime) (if (c.use24h) "HH:mm" else "hh:mm a") else "")
            val off = tz.getOffset(d.captureTimeMs) / 60000
            val gmt = " GMT " + (if (off < 0) "-" else "+") + String.format(Locale.US, "%02d:%02d", Math.abs(off) / 60, Math.abs(off) % 60)
            val s = SimpleDateFormat(pat, Locale.getDefault()).apply { timeZone = tz }.format(Date(d.captureTimeMs)) +
                (if (c.showTimezone) gmt else "")
            rows += Pair(textLayout(s, tp(24f, false, lk.sub), (textW - gutter).toInt(), 2), 2)
        }
        if (lat != null && (c.showAltitude || c.showSpeed || c.showAccuracy || c.showCompass)) {
            val parts = ArrayList<String>()
            val alt = d.altitudeM
            val spd = d.speedMps
            val hd = d.headingDeg
            val acc = d.accuracyM
            if (c.showAltitude && alt != null) parts += "Alt " + Geo.distance(alt, c.units)
            if (c.showSpeed && spd != null) parts += "Speed " + Geo.speed(spd, c.units)
            if (c.showCompass && hd != null) parts += Geo.heading(hd)
            if (c.showAccuracy && acc != null) parts += Geo.accuracy(acc, c.units)
            if (parts.isNotEmpty()) rows += Pair(textLayout(parts.joinToString("  ·  "), tp(20f, false, lk.sub), (textW - gutter).toInt(), 2), 0)
        }
        if (c.customText.isNotBlank()) rows += Pair(textLayout(c.customText.trim(), tp(21f, false, lk.sub), (textW - gutter).toInt(), 2), 0)

        val g1 = 12f * u
        val g2 = 8f * u
        var textH = 0f
        titleL?.let { textH += it.height + (if (rows.isNotEmpty()) g1 else 0f) }
        rows.forEachIndexed { i, r -> textH += r.first.height + (if (i < rows.size - 1) g2 else 0f) }

        val overflow = if (st == 2 || st == 4) 38f * u else 0f
        val padTop = 14f * u
        val pillH = 44f * u
        val gapHB = 12f * u
        val padBottom = 24f * u
        val bodyH = max(textH, max(if (showMap) msFrame else 0f, if (logoOn) logoW else 0f)).coerceAtLeast(110f * u)
        val cardH = padTop + pillH + gapHB + bodyH + padBottom
        val total = overflow + cardH
        if (canvas == null) return total

        val top = y0 + overflow
        val rect = RectF(x0, top, x0 + cardW, top + cardH)
        hit?.card = RectF(rect)
        val ext = 60f * u
        val layer = canvas.saveLayerAlpha(rect.left - ext, rect.top - ext, rect.right + ext, rect.bottom + ext, (c.cardAlpha * 255).toInt().coerceIn(0, 255))

        val cr = 34f * u
        val shape: Path = if (st == 2 || st == 4) wavy(rect, cr, 7f * u, 7) else Path().apply { addRoundRect(rect, cr, cr, Path.Direction.CW) }

        // ---- background + illustration (clipped to the card shape)
        if (st == 3) {
            val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 8f * u; maskFilter = BlurMaskFilter(16f * u, BlurMaskFilter.Blur.NORMAL)
                shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, argb(0xFF35E0FF), argb(0xFFB06BFF), Shader.TileMode.CLAMP)
            }
            canvas.drawPath(shape, glow)
        }
        canvas.save()
        canvas.clipPath(shape)
        paintBackground(canvas, st, rect, u)
        canvas.restore()

        // ---- outline
        when (st) {
            1 -> canvas.drawPath(shape, line(argb(0x66BFEFFF), 2.5f * u))
            2, 4 -> canvas.drawPath(shape, line(argb(0xFFE8D3B5), 2.5f * u))
            3 -> canvas.drawPath(shape, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 3.5f * u
                shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, argb(0xFF35E0FF), argb(0xFFB06BFF), Shader.TileMode.CLAMP)
            })
            5 -> canvas.drawPath(shape, line(argb(0x66A9B8FF), 2.5f * u))
            6 -> canvas.drawPath(shape, line(argb(0xAAFFFFFF), 3f * u))
        }
        paintOverflow(canvas, st, rect, u)

        // ---- header: Visiting pill + app tab
        val hy = rect.top + padTop
        val pillLabel = tp(24f, true, argb(0xFFFFFFFF)).apply { textSize = 24f * u }
        val pillW = 34f * u + pillLabel.measureText("Visiting") + 28f * u
        drawPill(canvas, st, rect.left + pad, hy, pillW, pillH, u)
        val tabLabel = tp(21f, true, argb(0xFFFFFFFF)).apply { textSize = 21f * u }
        val tabH = 40f * u
        val tabW = 22f * u + 28f * u + 8f * u + tabLabel.measureText("TTK GPS Cam") + 22f * u
        drawTab(canvas, st, rect.right - pad - tabW, hy + (pillH - tabH) / 2f, tabW, tabH, tabLabel, u)

        // ---- body
        val bodyTop = hy + pillH + gapHB
        var x = rect.left + pad
        if (showMap && map != null) {
            drawMap(canvas, st, map, x, bodyTop + (bodyH - msFrame) / 2f, msFrame, ms, u)
            x += msFrame + gap
        }
        var ty = bodyTop + (bodyH - textH) / 2f
        titleL?.let {
            canvas.save(); canvas.translate(x, ty); it.draw(canvas); canvas.restore()
            ty += it.height + (if (rows.isNotEmpty()) g1 else 0f)
        }
        rows.forEach { (l, kind) ->
            if (kind != 0) {
                val iy = ty + l.getLineBottom(0) / 2f
                val ir = 12f * u * fs
                if (kind == 1) drawPin(canvas, x + gutter * 0.4f, iy - ir * 0.55f, ir * 0.62f, lk.pin, if (st == 1 || st == 3 || st == 5) argb(0xFF14202B) else argb(0xFFFFFFFF))
                else drawClock(canvas, x + gutter * 0.4f, iy, ir * 0.85f, lk.clock, if (st == 1) argb(0xFF14202B) else argb(0xFFFFFFFF))
            }
            canvas.save(); canvas.translate(x + (if (kind != 0) gutter else 0f), ty); l.draw(canvas); canvas.restore()
            ty += l.height + g2
        }

        // ---- optional company logo slot (right side)
        if (logoOn) {
            val lx = rect.right - pad - logoW
            val box = RectF(lx, bodyTop + (bodyH - logoW) / 2f, lx + logoW, bodyTop + (bodyH + logoW) / 2f)
            hit?.logo = RectF(box)
            if (realLogo && logo != null) {
                val s = min(box.width() / logo.width, box.height() / logo.height)
                val bw = logo.width * s
                val bh = logo.height * s
                val dst = RectF(box.centerX() - bw / 2f, box.centerY() - bh / 2f, box.centerX() + bw / 2f, box.centerY() + bh / 2f)
                canvas.drawBitmap(logo, null, dst, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply { alpha = (c.logoOpacity * 255).toInt().coerceIn(0, 255) })
            } else {
                val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = 2.5f * u; color = lk.sub
                    pathEffect = DashPathEffect(floatArrayOf(10f * u, 8f * u), 0f)
                }
                canvas.drawRoundRect(box, 16f * u, 16f * u, dash)
                val p1 = tp(40f, true, lk.title)
                val p2 = tp(19f, false, lk.sub)
                canvas.drawText("+", box.centerX() - p1.measureText("+") / 2f, box.centerY(), p1)
                canvas.drawText("Logo", box.centerX() - p2.measureText("Logo") / 2f, box.centerY() + p2.textSize * 1.7f, p2)
            }
        }
        canvas.restoreToCount(layer)
        return total
    }

    fun draw(
        canvas: Canvas, w: Int, h: Int, c: StampConfig, d: StampData, map: Bitmap?, logo: Bitmap?,
        placeholder: Boolean, hit: StampRenderer.StampHit?,
    ) {
        val u = min(w, h) / 1080f
        val total = compose(null, w, h, u, c, d, map, logo, 0f, placeholder, null)
        val margin = 24f * u
        val y0 = if (c.position.name.startsWith("TOP")) margin else h - margin - 24f * u - total
        compose(canvas, w, h, u, c, d, map, logo, y0, placeholder, hit)
    }

    // ---------------------------------------------------------------- backgrounds

    private fun paintBackground(c: Canvas, st: Int, r: RectF, u: Float) {
        when (st) {
            1 -> {
                c.drawRect(r, vGrad(r.top, r.bottom, argb(0xF01E4054), argb(0xF00D2430)))
                c.drawRect(r, hGrad(r.left, r.right, argb(0x00000000), argb(0x3329D3A3)))
                cloud(c, r.right - 150f * u, r.top + 100f * u, 40f * u, fill(argb(0x33FFFFFF)))
                // hill, spire and trees on the right
                c.drawPath(Path().apply {
                    moveTo(r.right - 380f * u, r.bottom); quadTo(r.right - 200f * u, r.bottom - 80f * u, r.right, r.bottom - 46f * u)
                    lineTo(r.right, r.bottom); close()
                }, vGrad(r.bottom - 80f * u, r.bottom, argb(0xFF2B8F5B), argb(0xFF14573A)))
                val sx = r.right - 210f * u
                val sp = hGrad(sx - 40f * u, sx + 40f * u, argb(0x66FFFFFF), argb(0xCCFFFFFF))
                c.drawPath(Path().apply { moveTo(sx, r.bottom - 175f * u); quadTo(sx - 4f * u, r.bottom - 70f * u, sx - 46f * u, r.bottom - 20f * u); lineTo(sx + 6f * u, r.bottom - 24f * u); close() }, sp)
                c.drawPath(Path().apply { moveTo(sx + 6f * u, r.bottom - 150f * u); quadTo(sx + 16f * u, r.bottom - 70f * u, sx + 52f * u, r.bottom - 24f * u); lineTo(sx + 4f * u, r.bottom - 24f * u); close() }, sp)
                roundTree(c, r.right - 90f * u, r.bottom - 6f * u, 74f * u, argb(0xFF1F7A4C), argb(0xFF2E9A62))
                roundTree(c, r.right - 40f * u, r.bottom - 2f * u, 58f * u, argb(0xFF1B6B43), argb(0xFF27895A))
            }
            2 -> {
                c.drawRect(r, vGrad(r.top, r.bottom, argb(0xFFFFF6EA), argb(0xFFF7E8D3)))
                grass(c, r.left, r.bottom, u, false)
                grass(c, r.right, r.bottom, u, true)
                heart(c, r.right - 60f * u, r.top + 70f * u, 10f * u, argb(0xFFFF8FB1))
                heart(c, r.right - 36f * u, r.top + 50f * u, 7f * u, argb(0xFFFFB3C8))
            }
            3 -> {
                c.drawRect(r, vGrad(r.top, r.bottom, argb(0xFF15133F), argb(0xFF241A66)))
                c.drawRect(r, hGrad(r.left, r.right, argb(0x00000000), argb(0x338A5CFF)))
                // 3D location pin with ripple rings (bottom right)
                val px = r.right - 90f * u
                val py = r.bottom - 100f * u
                val ring = line(argb(0xAA35E0FF), 4f * u)
                c.drawOval(RectF(px - 62f * u, py + 36f * u, px + 62f * u, py + 76f * u), ring)
                c.drawOval(RectF(px - 38f * u, py + 46f * u, px + 38f * u, py + 68f * u), line(argb(0xAAB06BFF), 3f * u))
                c.drawPath(pinShape(px, py - 8f * u, 32f * u), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(px - 32f * u, py - 40f * u, px + 32f * u, py + 50f * u, argb(0xFFFF7BD5), argb(0xFF4FC3FF), Shader.TileMode.CLAMP)
                })
                c.drawCircle(px, py - 8f * u, 13f * u, fill(argb(0xFFFFFFFF)))
            }
            4 -> {
                c.drawRect(r, vGrad(r.top, r.bottom, argb(0xFFFFF6EA), argb(0xFFF7E8D3)))
                grass(c, r.left, r.bottom, u, false)
                grass(c, r.right, r.bottom, u, true)
                // dotted flight path + paper plane on the right
                val dots = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = 3f * u; color = argb(0xFF7C9CC9); pathEffect = DashPathEffect(floatArrayOf(2f * u, 9f * u), 0f); strokeCap = Paint.Cap.ROUND
                }
                c.drawPath(Path().apply {
                    moveTo(r.left + r.width() * 0.46f, r.top + 60f * u)
                    cubicTo(r.left + r.width() * 0.6f, r.top + 110f * u, r.left + r.width() * 0.7f, r.top + 20f * u, r.right - 86f * u, r.top + 62f * u)
                }, dots)
                glyph(c, 2, r.right - 56f * u, r.top + 60f * u, 24f * u, argb(0xFF5B7FB5))
            }
            5 -> {
                c.drawRect(r, vGrad(r.top, r.bottom, argb(0xFF1D2470), argb(0xFF101443)))
                val sp = fill(argb(0xCCFFFFFF))
                val spots = listOf(
                    floatArrayOf(0.40f, 0.18f, 7f), floatArrayOf(0.58f, 0.30f, 5f), floatArrayOf(0.12f, 0.12f, 6f),
                    floatArrayOf(0.74f, 0.14f, 6f), floatArrayOf(0.30f, 0.80f, 5f), floatArrayOf(0.66f, 0.62f, 4f),
                )
                for (s in spots) star4(c, r.left + r.width() * s[0], r.top + r.height() * s[1], s[2] * u, sp)
                // crescent moon
                val mx = r.right - 90f * u
                val my = r.top + 96f * u
                val moon = Path().apply {
                    val full = Path().apply { addCircle(mx, my, 28f * u, Path.Direction.CW) }
                    val cut = Path().apply { addCircle(mx + 14f * u, my - 8f * u, 25f * u, Path.Direction.CW) }
                    op(full, cut, Path.Op.DIFFERENCE)
                }
                c.drawPath(moon, fill(argb(0xFFFFE9A6)))
                // dark hill with pines (bottom right)
                c.drawPath(Path().apply {
                    moveTo(r.right - 300f * u, r.bottom); quadTo(r.right - 150f * u, r.bottom - 54f * u, r.right, r.bottom - 36f * u)
                    lineTo(r.right, r.bottom); close()
                }, fill(argb(0xFF0A0D33)))
                pine(c, r.right - 80f * u, r.bottom - 14f * u, 70f * u, argb(0xFF0A0D33))
                pine(c, r.right - 40f * u, r.bottom - 10f * u, 56f * u, argb(0xFF0A0D33))
                pine(c, r.right - 120f * u, r.bottom - 12f * u, 50f * u, argb(0xFF0A0D33))
            }
            else -> {
                c.drawRect(r, vGrad(r.top, r.bottom, argb(0xFF5FB6F4), argb(0xFFD2EEFA)))
                cloud(c, r.right - 110f * u, r.top + 88f * u, 38f * u, fill(argb(0xE6FFFFFF)))
                cloud(c, r.left + r.width() * 0.52f, r.top + 70f * u, 26f * u, fill(argb(0xB3FFFFFF)))
                c.drawPath(Path().apply {
                    moveTo(r.left, r.bottom - 60f * u); quadTo(r.left + r.width() * 0.25f, r.bottom - 120f * u, r.left + r.width() * 0.5f, r.bottom - 52f * u)
                    quadTo(r.left + r.width() * 0.78f, r.bottom - 120f * u, r.right, r.bottom - 50f * u); lineTo(r.right, r.bottom); lineTo(r.left, r.bottom); close()
                }, vGrad(r.bottom - 120f * u, r.bottom, argb(0xFF8EDB60), argb(0xFF3FAE49)))
                c.drawPath(Path().apply {
                    moveTo(r.left, r.bottom - 24f * u); quadTo(r.left + r.width() * 0.35f, r.bottom - 70f * u, r.left + r.width() * 0.7f, r.bottom - 22f * u)
                    quadTo(r.left + r.width() * 0.86f, r.bottom - 50f * u, r.right, r.bottom - 26f * u); lineTo(r.right, r.bottom); lineTo(r.left, r.bottom); close()
                }, vGrad(r.bottom - 70f * u, r.bottom, argb(0xFF63C247), argb(0xFF2F9A3E)))
                roundTree(c, r.left + 40f * u, r.bottom - 6f * u, 72f * u, argb(0xFF2E9A3E), argb(0xFF47B455))
                roundTree(c, r.left + 98f * u, r.bottom - 2f * u, 50f * u, argb(0xFF3AA84A), argb(0xFF5CC667))
                // folded map with an orange pin (bottom right)
                val mx = r.right - 100f * u
                val my = r.bottom - 36f * u
                c.drawPath(Path().apply {
                    moveTo(mx - 60f * u, my - 6f * u); lineTo(mx - 20f * u, my - 22f * u); lineTo(mx + 20f * u, my - 6f * u)
                    lineTo(mx + 60f * u, my - 22f * u); lineTo(mx + 44f * u, my + 20f * u); lineTo(mx + 4f * u, my + 6f * u)
                    lineTo(mx - 36f * u, my + 22f * u); close()
                }, fill(argb(0xFFE6F6C9)))
                drawPin(c, mx + 4f * u, my - 34f * u, 17f * u, argb(0xFFEF4444), argb(0xFFFFFFFF))
            }
        }
    }

    private fun grass(c: Canvas, cornerX: Float, bottom: Float, u: Float, right: Boolean) {
        val dir = if (right) -1f else 1f
        val dark = fill(argb(0xFF3FA34D))
        val light = fill(argb(0xFF7AD36B))
        c.drawCircle(cornerX + dir * 40f * u, bottom + 4f * u, 40f * u, dark)
        c.drawCircle(cornerX + dir * 96f * u, bottom + 14f * u, 30f * u, light)
        c.drawCircle(cornerX + dir * 14f * u, bottom - 14f * u, 24f * u, light)
        roundTree(c, cornerX + dir * 52f * u, bottom - 22f * u, 44f * u, argb(0xFF2E8B3D), argb(0xFF4CB85A))
    }

    /** Elements that stick out above the card edge (drawn unclipped). */
    private fun paintOverflow(c: Canvas, st: Int, r: RectF, u: Float) {
        when (st) {
            2 -> {
                // 3D-style camera badge, top right
                val cx = r.right - 78f * u
                val cy = r.top - 2f * u
                c.save(); c.rotate(14f, cx, cy)
                c.drawRoundRect(RectF(cx - 46f * u, cy - 32f * u, cx + 46f * u, cy + 34f * u), 16f * u, 16f * u,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = LinearGradient(cx, cy - 32f * u, cx, cy + 34f * u, argb(0xFFA78BFA), argb(0xFF6D4AE0), Shader.TileMode.CLAMP) })
                c.drawRect(cx - 14f * u, cy - 42f * u, cx + 22f * u, cy - 30f * u, fill(argb(0xFF5B3DC8)))
                c.drawCircle(cx, cy + 2f * u, 24f * u, fill(argb(0xFF1B2A5C)))
                c.drawCircle(cx, cy + 2f * u, 17f * u, fill(argb(0xFF3B82F6)))
                c.drawCircle(cx - 5f * u, cy - 3f * u, 5f * u, fill(argb(0xCCFFFFFF)))
                c.restore()
                sparks(c, r.left + 190f * u, r.top + 6f * u, u, argb(0xFFFFC83D))
            }
            4 -> {
                // smiling sun at the top
                val cx = r.left + r.width() * 0.34f
                val cy = r.top - 6f * u
                val ray = line(argb(0xFFFFB020), 4f * u)
                for (i in 0 until 12) {
                    val ang = Math.toRadians(i * 30.0)
                    c.drawLine(cx + (36f * u * Math.cos(ang)).toFloat(), cy + (36f * u * Math.sin(ang)).toFloat(),
                        cx + (50f * u * Math.cos(ang)).toFloat(), cy + (50f * u * Math.sin(ang)).toFloat(), ray)
                }
                c.drawCircle(cx, cy, 33f * u, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(cx, cy - 33f * u, cx, cy + 33f * u, argb(0xFFFFE066), argb(0xFFFFB020), Shader.TileMode.CLAMP)
                })
                c.drawCircle(cx - 11f * u, cy - 4f * u, 3.6f * u, fill(argb(0xFF5A3A00)))
                c.drawCircle(cx + 11f * u, cy - 4f * u, 3.6f * u, fill(argb(0xFF5A3A00)))
                c.drawArc(RectF(cx - 12f * u, cy + 2f * u, cx + 12f * u, cy + 20f * u), 20f, 140f, false, line(argb(0xFF5A3A00), 3f * u))
                c.drawCircle(cx - 20f * u, cy + 8f * u, 6f * u, fill(argb(0x66FF6B6B)))
                c.drawCircle(cx + 20f * u, cy + 8f * u, 6f * u, fill(argb(0x66FF6B6B)))
            }
        }
    }

    // ---------------------------------------------------------------- pill, tab, map

    private fun drawPill(c: Canvas, st: Int, x: Float, y: Float, w: Float, h: Float, u: Float) {
        val r = RectF(x, y, x + w, y + h)
        val label = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f * u; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val ty = y + h / 2f - (label.ascent() + label.descent()) / 2f
        val tx = x + 34f * u
        when (st) {
            3, 5 -> {
                c.drawRoundRect(r, h / 2f, h / 2f, fill(argb(0x6628A745)))
                c.drawRoundRect(r, h / 2f, h / 2f, line(argb(0x6634D399), 1.5f * u))
                c.drawCircle(x + 20f * u, y + h / 2f, 8f * u, fill(argb(0xFF34E07A)))
                label.color = argb(0xFF86F7AE)
                c.drawText("Visiting", tx, ty, label)
            }
            4 -> {
                c.save(); c.rotate(-6f, x + w / 2f, y + h / 2f)
                val tag = RectF(r.left - 4f * u, r.top - 2f * u, r.right + 6f * u, r.bottom + 4f * u)
                c.drawRoundRect(tag, 14f * u, 14f * u, fill(argb(0xFFFFC83D)))
                c.drawRoundRect(tag, 14f * u, 14f * u, line(argb(0xFFF0A800), 2f * u))
                c.drawCircle(x + 20f * u, y + h / 2f + 1f * u, 8f * u, line(argb(0xFFFFFFFF), 3.5f * u))
                label.color = argb(0xFF3A2A00)
                c.drawText("Visiting", tx, ty, label)
                c.restore()
            }
            else -> {
                c.drawRoundRect(r, h / 2f, h / 2f, hGrad(x, x + w, argb(0xFF35C463), argb(0xFF1F9A4A)))
                c.drawRoundRect(r, h / 2f, h / 2f, line(argb(0x55FFFFFF), 1.5f * u))
                c.drawCircle(x + 20f * u, y + h / 2f, 8f * u, fill(argb(0xFFFFFFFF)))
                label.color = argb(0xFFFFFFFF)
                c.drawText("Visiting", tx, ty, label)
            }
        }
    }

    private fun drawTab(c: Canvas, st: Int, x: Float, y: Float, w: Float, h: Float, label: TextPaint, u: Float) {
        val r = RectF(x, y, x + w, y + h)
        val kind: Int
        val ink: Int
        when (st) {
            1 -> { c.drawRoundRect(r, h / 2f, h / 2f, fill(argb(0x44FFFFFF))); kind = 0; ink = argb(0xFFFFFFFF) }
            2 -> { c.drawRoundRect(r, h / 2f, h / 2f, fill(argb(0xFFEADFCB))); kind = 1; ink = argb(0xFF2B2740) }
            3 -> { c.drawRoundRect(r, h / 2f, h / 2f, fill(argb(0x33FFFFFF))); kind = 2; ink = argb(0xFFFFFFFF) }
            4 -> { c.drawRoundRect(r, h / 2f, h / 2f, hGrad(x, x + w, argb(0xFF5BB0FF), argb(0xFF3B82F6))); kind = 1; ink = argb(0xFFFFFFFF) }
            5 -> { c.drawRoundRect(r, h / 2f, h / 2f, fill(argb(0x33FFFFFF))); kind = 1; ink = argb(0xFFFFFFFF) }
            else -> { c.drawRoundRect(r, h / 2f, h / 2f, fill(argb(0x88FFFFFF))); kind = 1; ink = argb(0xFF1D4ED8) }
        }
        label.color = if (st == 6) argb(0xFF0F2447) else ink
        glyph(c, kind, x + 22f * u + 12f * u, y + h / 2f, 12f * u, ink)
        c.drawText("TTK GPS Cam", x + 22f * u + 28f * u + 8f * u, y + h / 2f - (label.ascent() + label.descent()) / 2f, label)
    }

    private fun drawMap(c: Canvas, st: Int, map: Bitmap, x: Float, y: Float, frame: Float, ms: Float, u: Float) {
        fun cropped(dst: RectF) {
            val dr = dst.width() / dst.height()
            val sr = map.width.toFloat() / map.height
            val src = if (sr > dr) {
                val nw = (map.height * dr).toInt(); Rect((map.width - nw) / 2, 0, (map.width + nw) / 2, map.height)
            } else {
                val nh = (map.width / dr).toInt(); Rect(0, (map.height - nh) / 2, map.width, (map.height + nh) / 2)
            }
            c.drawBitmap(map, src, dst, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        }
        when (st) {
            5 -> {
                val cx = x + ms / 2f
                val cy = y + ms / 2f
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = 14f * u; color = argb(0xAA30D8E8); maskFilter = BlurMaskFilter(14f * u, BlurMaskFilter.Blur.NORMAL)
                }
                c.drawCircle(cx, cy, ms / 2f - 6f * u, glow)
                c.save()
                c.clipPath(Path().apply { addCircle(cx, cy, ms / 2f - 8f * u, Path.Direction.CW) })
                cropped(RectF(x, y, x + ms, y + ms))
                c.restore()
                c.drawCircle(cx, cy, ms / 2f - 8f * u, line(argb(0xFF30D8E8), 9f * u))
            }
            4 -> {
                val cx = x + frame / 2f
                val cy = y + frame / 2f
                c.save(); c.rotate(-5f, cx, cy)
                val outer = RectF(x, y, x + frame, y + frame)
                c.drawRoundRect(RectF(outer.left + 3f * u, outer.top + 6f * u, outer.right + 3f * u, outer.bottom + 6f * u), 12f * u, 12f * u, fill(argb(0x33000000)))
                c.drawRoundRect(outer, 12f * u, 12f * u, fill(argb(0xFFFFFFFF)))
                val inner = RectF(outer.left + 13f * u, outer.top + 13f * u, outer.right - 13f * u, outer.bottom - 13f * u)
                c.save(); c.clipPath(Path().apply { addRoundRect(inner, 6f * u, 6f * u, Path.Direction.CW) })
                cropped(inner)
                c.restore()
                c.drawRoundRect(RectF(cx - 34f * u, outer.top - 10f * u, cx + 34f * u, outer.top + 10f * u), 3f * u, 3f * u, fill(argb(0xAAA9D4EE)))
                c.restore()
            }
            else -> {
                val dst = RectF(x, y, x + ms, y + ms)
                c.save(); c.clipPath(Path().apply { addRoundRect(dst, 20f * u, 20f * u, Path.Direction.CW) })
                cropped(dst)
                c.restore()
                c.drawRoundRect(dst, 20f * u, 20f * u, line(argb(0xFFFFFFFF), 6f * u))
            }
        }
    }
}
