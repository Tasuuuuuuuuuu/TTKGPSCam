package com.ttk.gpscam.stamp

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.data.StampConfig
import com.ttk.gpscam.data.StampData
import com.ttk.gpscam.data.StampPosition
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * "GPS camera" style card: map thumbnail with a green tag on the left, place name, address, coordinates and date
 * in the middle, optional company-logo slot on the right, and a small app tab above the top-right corner.
 */
object GmcCard {
    private const val APP_NAME = "TTK GPS Cam"
    const val MAP_W = 250f
    const val MAP_H = 300f
    private const val ALPHABET = "23456789CFGHJMPQRVWX"

    fun plusCode(lat: Double, lon: Double): String {
        var la = lat.coerceIn(-90.0, 90.0 - 1e-9) + 90.0
        var lo = ((lon + 180.0) % 360.0 + 360.0) % 360.0
        var res = 20.0
        val sb = StringBuilder()
        for (i in 0 until 5) {
            val a = (la / res).toInt().coerceIn(0, 19)
            val b = (lo / res).toInt().coerceIn(0, 19)
            sb.append(ALPHABET[a]).append(ALPHABET[b])
            la -= a * res; lo -= b * res
            if (i < 4) res /= 20.0
        }
        val row = (la / (res / 5.0)).toInt().coerceIn(0, 4)
        val col = (lo / (res / 4.0)).toInt().coerceIn(0, 3)
        sb.append(ALPHABET[row * 4 + col])
        // drop the area prefix (first 4 chars) and put the '+' like a "short code"
        return sb.substring(4, 8) + "+" + sb.substring(8)
    }

    fun flagOf(country: String?): String {
        if (country.isNullOrBlank()) return ""
        val code = Locale.getISOCountries().firstOrNull {
            Locale("", it).getDisplayCountry(Locale.ENGLISH).equals(country, true) ||
                Locale("", it).getDisplayCountry(Locale.getDefault()).equals(country, true)
        } ?: return ""
        return code.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")
    }

    private fun layout(text: CharSequence, p: TextPaint, w: Int) =
        StaticLayout.Builder.obtain(text, 0, text.length, p, w.coerceAtLeast(1))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setIncludePad(false).setLineSpacing(0f, 1.04f)
            .setMaxLines(3).setEllipsize(android.text.TextUtils.TruncateAt.END).build()

    private fun withA(color: Int, a: Int) = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    /** Returns total height (card + app tab). Paints when [canvas] != null. */
    fun compose(
        canvas: Canvas?, w: Int, h: Int, u: Float, c: StampConfig, d: StampData, map: Bitmap?, logo: Bitmap?,
        y0: Float, placeholder: Boolean, hit: StampRenderer.StampHit?,
    ): Float {
        val fs = c.fontScale
        val margin = 24f * u
        val cardW = min(w - 2 * margin, 1060f * u * (c.cardWidth / 0.95f).coerceIn(0.5f, 1.2f))
        val x0 = (w - cardW) / 2f
        val pad = 14f * u
        val gap = 16f * u
        val tag = 34f * u
        val showMap = c.showMap && d.lat != null && map != null
        val mapW = if (showMap) MAP_W * u else 0f
        val realLogo = c.logoOn && logo != null && !logo.isRecycled && logo.width > 0 && logo.height > 0
        val logoOn = realLogo || (c.logoOn && placeholder)
        val logoW = if (logoOn) 150f * u else 0f
        val textW = cardW - 2 * pad - (if (showMap) mapW + gap else 0f) - (if (logoOn) logoW + gap * 1.5f else 0f)
        val tz = TimeZone.getTimeZone(d.tzId)

        fun tp(sizeU: Float, bold: Boolean, alpha: Float = 1f) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = sizeU * u * fs
            typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
            color = withA(c.textColor, (255 * alpha).toInt())
        }

        val a = d.address
        val ls = ArrayList<StaticLayout>()
        val gaps = ArrayList<Float>()
        val lat = d.lat
        val lon = d.lon
        if (lat == null || lon == null) {
            ls += layout("GPS location unavailable", tp(36f, true), textW.toInt())
        } else {
            if (c.showAddress) {
                val head = listOfNotNull(a?.city ?: a?.area, a?.state, a?.country).distinct().joinToString(", ")
                val flag = flagOf(a?.country)
                val title = if (head.isBlank()) "Location" else head + (if (flag.isNotEmpty()) "  $flag" else "")
                ls += layout(title, tp(36f, true), textW.toInt())
                val full = a?.line ?: listOfNotNull(a?.street, a?.area, a?.city, a?.state, a?.country).joinToString(", ")
                val second = plusCode(lat, lon) + (if (full.isNotBlank()) ", $full" else "")
                ls += layout(second, tp(23f, false, 0.92f), textW.toInt())
            }
            if (c.showCoords) {
                val la = Geo.coordinate(lat, true, c.coordFormat)
                val lo = Geo.coordinate(lon, false, c.coordFormat)
                ls += layout("Lat $la  Long $lo", tp(25f, false), textW.toInt())
            }
        }
        if (c.showDate || c.showTime) {
            val pat = (if (c.showDate) "EEEE, dd/MM/yyyy" else "") + (if (c.showDate && c.showTime) " " else "") +
                (if (c.showTime) (if (c.use24h) "HH:mm" else "hh:mm a") else "")
            val off = tz.getOffset(d.captureTimeMs) / 60000
            val gmt = " GMT " + (if (off < 0) "-" else "+") + String.format(Locale.US, "%02d:%02d", abs(off) / 60, abs(off) % 60)
            val s = SimpleDateFormat(pat, Locale.getDefault()).apply { timeZone = tz }.format(Date(d.captureTimeMs)) +
                (if (c.showTimezone) gmt else "")
            ls += layout(s, tp(23f, false, 0.95f), textW.toInt())
        }
        if (c.showAltitude || c.showSpeed || c.showAccuracy) {
            val parts = ArrayList<String>()
            if (c.showAltitude && d.altitudeM != null) parts += "Alt " + Geo.distance(d.altitudeM, c.units)
            if (c.showSpeed && d.speedMps != null) parts += "Speed " + Geo.speed(d.speedMps, c.units)
            if (c.showCompass && d.headingDeg != null) parts += Geo.heading(d.headingDeg)
            if (c.showAccuracy && d.accuracyM != null) parts += "±" + Geo.accuracy(d.accuracyM, c.units).removePrefix("±")
            if (parts.isNotEmpty()) ls += layout(parts.joinToString("  ·  "), tp(20f, false, 0.8f), textW.toInt())
        }
        if (c.customText.isNotBlank()) ls += layout(c.customText.trim(), tp(21f, false, 0.85f), textW.toInt())

        val g = 6f * u
        val textH = ls.sumOf { it.height.toDouble() }.toFloat() + g * max(0, ls.size - 1)
        val innerH = max(textH, if (showMap) 210f * u else 0f).coerceAtLeast(80f * u)
        val cardH = innerH + 2 * pad
        val total = cardH + tag
        if (canvas == null) return total

        val top = y0 + tag
        val card = RectF(x0, top, x0 + cardW, top + cardH)
        hit?.card = RectF(card)
        val bgAlpha = (c.bgOpacity * 255).toInt()
        val layer = canvas.saveLayerAlpha(x0 - 4f, y0 - 4f, x0 + cardW + 4f, top + cardH + 4f, (c.cardAlpha * 255).toInt().coerceIn(0, 255))
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withA(c.bgColor, bgAlpha) }
        val cr = c.cornerRadius * u

        // app tab above the top-right corner
        val tab = tp(19f, true, 0.95f)
        val name = APP_NAME
        val tabW = tab.measureText(name) + 52f * u
        val tabR = RectF(card.right - tabW - 10f * u, y0 + 2f * u, card.right - 10f * u, top + cr)
        canvas.drawRoundRect(tabR, 9f * u, 9f * u, bg)
        val pr = 7f * u
        val pcx = tabR.left + 20f * u
        val pcy = tabR.top + (tag - 2f * u) / 2f
        val pin = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF01B880.toInt() }
        canvas.drawCircle(pcx, pcy - pr * 0.25f, pr, pin)
        val tail = Path().apply { moveTo(pcx - pr * 0.8f, pcy); lineTo(pcx + pr * 0.8f, pcy); lineTo(pcx, pcy + pr * 1.5f); close() }
        canvas.drawPath(tail, pin)
        canvas.drawCircle(pcx, pcy - pr * 0.25f, pr * 0.38f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() })
        canvas.drawText(name, pcx + 16f * u, pcy + tab.textSize * 0.35f, tab)

        canvas.drawRoundRect(card, cr, cr, bg)

        var x = card.left + pad
        val y = card.top + pad
        if (showMap && map != null) {
            val dst = RectF(x, y, x + mapW, y + innerH)
            // centre-crop the bitmap to the destination aspect ratio
            val dr = dst.width() / dst.height()
            val sr = map.width.toFloat() / map.height
            val src = if (sr > dr) {
                val nw = (map.height * dr).toInt(); Rect((map.width - nw) / 2, 0, (map.width + nw) / 2, map.height)
            } else {
                val nh = (map.width / dr).toInt(); Rect(0, (map.height - nh) / 2, map.width, (map.height + nh) / 2)
            }
            canvas.save()
            canvas.clipPath(Path().apply { addRoundRect(dst, 10f * u, 10f * u, Path.Direction.CW) })
            canvas.drawBitmap(map, src, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF22A745.toInt() }
            canvas.drawRect(dst.left, dst.top, dst.right, dst.top + 28f * u, gp)
            val vt = tp(17f, true)
            vt.color = 0xFFFFFFFF.toInt()
            canvas.drawText("Visiting", dst.centerX() - vt.measureText("Visiting") / 2f, dst.top + 20f * u, vt)
            canvas.restore()
            x += mapW + gap
        }
        var ty = y + (innerH - textH) / 2f
        for (l in ls) {
            canvas.save(); canvas.translate(x, ty); l.draw(canvas); canvas.restore()
            ty += l.height + g
        }

        if (logoOn) {
            val lx = card.right - pad - logoW
            val div = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withA(c.textColor, 70); strokeWidth = max(1f, 2f * u) }
            canvas.drawLine(lx - gap * 0.75f, y + innerH * 0.08f, lx - gap * 0.75f, y + innerH * 0.92f, div)
            val box = RectF(lx, y + (innerH - logoW) / 2f, lx + logoW, y + (innerH + logoW) / 2f)
            hit?.logo = RectF(box)
            if (realLogo && logo != null) {
                val s = min(box.width() / logo.width, box.height() / logo.height)
                val bw = logo.width * s
                val bh = logo.height * s
                val dstL = RectF(box.centerX() - bw / 2f, box.centerY() - bh / 2f, box.centerX() + bw / 2f, box.centerY() + bh / 2f)
                canvas.drawBitmap(logo, null, dstL, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply { alpha = (c.logoOpacity * 255).toInt().coerceIn(0, 255) })
            } else {
                val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = 2.5f * u; color = withA(c.textColor, 200)
                    pathEffect = DashPathEffect(floatArrayOf(10f * u, 8f * u), 0f)
                }
                canvas.drawRoundRect(box, 14f * u, 14f * u, dash)
                val p1 = tp(40f, true); val p2 = tp(19f, false, 0.8f)
                canvas.drawText("+", box.centerX() - p1.measureText("+") / 2f, box.centerY(), p1)
                canvas.drawText("Logo", box.centerX() - p2.measureText("Logo") / 2f, box.centerY() + p2.textSize * 1.7f, p2)
            }
        }
        canvas.restoreToCount(layer)
        return total
    }

    fun draw(
        canvas: Canvas, w: Int, h: Int, c: StampConfig, d: StampData, map: Bitmap?, logo: Bitmap?,
        placeholder: Boolean, hit: StampRenderer.StampHit?,
    ) {
        val u = min(w, h) / 1080f
        val total = compose(null, w, h, u, c, d, map, logo, 0f, placeholder, null)
        val margin = 24f * u
        val y0 = if (c.position.name.startsWith("TOP")) margin else h - margin - 24f * u - total
        compose(canvas, w, h, u, c, d, map, logo, y0, placeholder, hit)
    }
}
