package com.ttk.gpscam.stamp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import com.ttk.gpscam.data.AppSettings
import com.ttk.gpscam.data.StampConfig
import com.ttk.gpscam.data.StampData
import com.ttk.gpscam.map.MapRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SavedPhoto(val uri: Uri, val name: String, val originalSaved: Boolean, val mapMissing: Boolean)

object PhotoProcessor {
    /** Decoded pixel cap. 16 MP keeps typical phone photos at full resolution while avoiding OOM on 50/108 MP sensors. */
    private const val MAX_PIXELS = 16_000_000L

    /**
     * Renders the stamp onto the decoded photo and writes a JPEG to [out].
     * Returns whether the requested map had to be omitted (offline / tiles unavailable).
     */
    suspend fun renderStamped(
        ctx: Context, open: () -> java.io.InputStream?, data: StampData, cfg: StampConfig,
        logo: Bitmap?, quality: Int, out: File,
    ): Boolean = withContext(Dispatchers.Default) {
        val bmp = PhotoStore.decodeOriented(open, MAX_PIXELS) ?: throw java.io.IOException("The photo could not be decoded.")
        try {
            var map: Bitmap? = null
            var mapMissing = false
            val size = StampRenderer.mapBoxSize(bmp.width, bmp.height, cfg)
            val lat = data.lat
            val lon = data.lon
            if (size != null && lat != null && lon != null) {
                map = withTimeoutOrNull(8000L) {
                    MapRenderer.render(ctx, cfg.mapStyle, lat, lon, cfg.mapZoom, size.first, size.second, true, data.accuracyM)
                }
                mapMissing = map == null
            }
            StampRenderer.draw(Canvas(bmp), bmp.width, bmp.height, cfg, data, map, logo)
            map?.recycle()
            out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(60, 100), it) }
            mapMissing
        } finally {
            bmp.recycle()
        }
    }

    private fun stampName(ms: Long) = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(ms))

    /** Capture pipeline: exactly ONE photo is saved (stamped, or plain when the stamp is switched off). */
    suspend fun processCapture(ctx: Context, tmp: File, data: StampData, s: AppSettings, logo: Bitmap?): SavedPhoto =
        withContext(Dispatchers.IO) {
            val stamp = stampName(data.captureTimeMs)
            val name = "TTK_$stamp.jpg"
            PhotoStore.writeGpsExif(tmp, data)
            if (!s.stampEnabled) {
                val u = PhotoStore.insertFromFile(ctx, name, PhotoStore.DIR, tmp, data.captureTimeMs)
                PhotoStore.saveMeta(ctx, name, PhotoMeta(data, null, null))
                return@withContext SavedPhoto(u, name, false, false)
            }
            val out = File(ctx.cacheDir, "stamped_$stamp.jpg")
            try {
                val mapMissing = renderStamped(ctx, { tmp.inputStream() }, data, s.stamp, logo, s.jpegQuality, out)
                PhotoStore.writeGpsExif(out, data)
                val uri = PhotoStore.insertFromFile(ctx, name, PhotoStore.DIR, out, data.captureTimeMs)
                PhotoStore.saveMeta(ctx, name, PhotoMeta(data, null, s.stamp.templateId))
                SavedPhoto(uri, name, false, mapMissing)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                throw java.io.IOException("Stamping failed: ${e.message ?: "unknown error"}.", e)
            } finally {
                out.delete()
            }
        }

    /** Creates a NEW stamped copy from the original photo; nothing is overwritten. */
    suspend fun restamp(
        ctx: Context, originalUri: Uri, originalName: String, data: StampData, cfg: StampConfig,
        logo: Bitmap?, quality: Int,
    ): SavedPhoto = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val base = originalName.removeSuffix(".jpg").removeSuffix("_orig")
        val name = "${base}_R${SimpleDateFormat("HHmmss", Locale.US).format(Date(now))}.jpg"
        val out = File(ctx.cacheDir, "restamp_$now.jpg")
        try {
            val mapMissing = renderStamped(ctx, { ctx.contentResolver.openInputStream(originalUri) }, data, cfg, logo, quality, out)
            PhotoStore.writeGpsExif(out, data)
            val uri = PhotoStore.insertFromFile(ctx, name, PhotoStore.DIR, out, data.captureTimeMs)
            PhotoStore.saveMeta(ctx, name, PhotoMeta(data, originalName, cfg.templateId))
            SavedPhoto(uri, name, true, mapMissing)
        } finally {
            out.delete()
        }
    }
}
