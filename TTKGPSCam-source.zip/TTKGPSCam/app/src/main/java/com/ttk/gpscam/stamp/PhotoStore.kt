package com.ttk.gpscam.stamp

import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.IntentSender
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import com.ttk.gpscam.data.StampData
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class PhotoItem(
    val id: Long, val uri: Uri, val name: String, val dateMs: Long,
    val size: Long, val width: Int, val height: Int,
)

data class PhotoMeta(val data: StampData, val originalName: String?, val templateId: String?)

/** Saves/reads photos in Pictures/TTK GPS Cam using MediaStore (no storage permission needed). */
object PhotoStore {
    const val DIR = "Pictures/TTK GPS Cam/"
    const val ORIG_DIR = "Pictures/TTK GPS Cam/Originals/"

    /** Copies [file] into MediaStore. Throws on failure and cleans up the partial entry. */
    fun insertFromFile(ctx: Context, name: String, relDir: String, file: File, takenMs: Long): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, relDir)
            put(MediaStore.Images.Media.DATE_TAKEN, takenMs)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw java.io.IOException("Could not create the photo in storage.")
        try {
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                ?: throw java.io.IOException("Could not open storage for writing.")
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri
    }

    fun list(ctx: Context): List<PhotoItem> {
        val out = ArrayList<PhotoItem>()
        val proj = arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.SIZE, MediaStore.Images.Media.WIDTH, MediaStore.Images.Media.HEIGHT,
        )
        runCatching {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj,
                "${MediaStore.Images.Media.RELATIVE_PATH} = ?", arrayOf(DIR),
                "${MediaStore.Images.Media.DATE_ADDED} DESC, ${MediaStore.Images.Media._ID} DESC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out += PhotoItem(
                        id, ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "photo.jpg", c.getLong(2) * 1000L, c.getLong(3), c.getInt(4), c.getInt(5),
                    )
                }
            }
        }
        return out
    }

    fun findOriginal(ctx: Context, originalName: String?): PhotoItem? {
        if (originalName == null) return null
        var found: PhotoItem? = null
        runCatching {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                arrayOf(
                    MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.SIZE, MediaStore.Images.Media.WIDTH, MediaStore.Images.Media.HEIGHT,
                ),
                "${MediaStore.Images.Media.RELATIVE_PATH} = ? AND ${MediaStore.Images.Media.DISPLAY_NAME} = ?",
                arrayOf(ORIG_DIR, originalName), null,
            )?.use { c ->
                if (c.moveToFirst()) {
                    val id = c.getLong(0)
                    found = PhotoItem(
                        id, ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: originalName, c.getLong(2) * 1000L, c.getLong(3), c.getInt(4), c.getInt(5),
                    )
                }
            }
        }
        return found
    }

    /** Result of a delete attempt: success, or an IntentSender the UI must launch to ask the user. */
    sealed interface DeleteResult {
        data object Done : DeleteResult
        data class NeedsConsent(val sender: IntentSender) : DeleteResult
        data class Failed(val message: String) : DeleteResult
    }

    fun delete(ctx: Context, uri: Uri): DeleteResult = try {
        ctx.contentResolver.delete(uri, null, null)
        DeleteResult.Done
    } catch (e: RecoverableSecurityException) {
        DeleteResult.NeedsConsent(e.userAction.actionIntent.intentSender)
    } catch (e: Exception) {
        DeleteResult.Failed(e.message ?: "Could not delete the photo.")
    }

    // ---------- sidecar metadata (private app storage; used for re-stamping and GPS info) ----------
    private fun metaFile(ctx: Context, name: String) = File(ctx.filesDir, "meta/$name.json")

    fun saveMeta(ctx: Context, name: String, meta: PhotoMeta) {
        runCatching {
            val f = metaFile(ctx, name)
            f.parentFile?.mkdirs()
            f.writeText(JSONObject().apply {
                put("data", meta.data.toJson()); put("original", meta.originalName ?: JSONObject.NULL)
                put("template", meta.templateId ?: JSONObject.NULL)
            }.toString())
        }
    }

    fun loadMeta(ctx: Context, name: String): PhotoMeta? = runCatching {
        val f = metaFile(ctx, name)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        PhotoMeta(
            StampData.fromJson(o.getJSONObject("data")),
            if (o.isNull("original")) null else o.optString("original"),
            if (o.isNull("template")) null else o.optString("template"),
        )
    }.getOrNull()

    fun deleteMeta(ctx: Context, name: String) { runCatching { metaFile(ctx, name).delete() } }

    /** Fallback when no sidecar exists: GPS/time from the photo's EXIF. Address is unknown. */
    fun metaFromExif(ctx: Context, uri: Uri): StampData? = runCatching {
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            val ex = ExifInterface(ins)
            val ll = ex.latLong
            val t = ex.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)?.let {
                runCatching { SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).parse(it)?.time }.getOrNull()
            } ?: System.currentTimeMillis()
            val alt = ex.getAltitude(Double.NaN).takeIf { !it.isNaN() }
            StampData(
                lat = ll?.get(0), lon = ll?.get(1), accuracyM = null, altitudeM = alt, speedMps = null,
                headingDeg = null, captureTimeMs = t, fixTimeMs = null, fixAgeMs = null,
                tzId = TimeZone.getDefault().id, isMock = false, address = null,
            )
        }
    }.getOrNull()

    fun writeGpsExif(file: File, d: StampData) {
        runCatching {
            val ex = ExifInterface(file.absolutePath)
            val lat = d.lat
            val lon = d.lon
            if (lat != null && lon != null) {
                ex.setLatLong(lat, lon)
                d.altitudeM?.let { ex.setAltitude(it) }
            }
            ex.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).format(Date(d.captureTimeMs)))
            ex.saveAttributes()
        }
    }

    // ---------- decoding ----------
    /** Decodes with EXIF orientation applied, limited to [maxPixels]; retries smaller on OutOfMemory. */
    fun decodeOriented(open: () -> InputStream?, maxPixels: Long): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > maxPixels) sample *= 2
        val orientation = runCatching {
            open()?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
        var attempt = 0
        while (attempt < 3) {
            try {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sample; inMutable = true; inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val bmp = open()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
                return applyOrientation(bmp, orientation)
            } catch (e: OutOfMemoryError) {
                sample *= 2; attempt++
            }
        }
        return null
    }

    private fun applyOrientation(bmp: Bitmap, orientation: Int): Bitmap {
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (rotated !== bmp) bmp.recycle()
        return if (rotated.isMutable) rotated else rotated.copy(Bitmap.Config.ARGB_8888, true).also { rotated.recycle() }
    }
}
