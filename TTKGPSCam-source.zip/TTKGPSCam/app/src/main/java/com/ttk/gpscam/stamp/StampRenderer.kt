package com.ttk.gpscam.stamp

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.StyleSpan
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.data.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Draws the GPS dashboard card onto any canvas. All sizes are in "design units" (1080 px short side = 1 unit/px),
 * so the live preview and the saved photo look the same regardless of resolution.
 */
object StampRenderer {
    private const val APP_BADGE = "TTK GPS Cam"

    private class Row(
        val label: String?, val text: String, val scale: Float, val bold: Boolean,
        val dim: Boolean = false, var col: Int = 0, val icon: Int = 0,
    )

    fun effectiveMapPos(c: StampConfig): MapPos = if (c.layout == LayoutKind.MAP_FOCUS) MapPos.TOP else c.mapPos

    /** Small vector icons: 1 = map pin, 2 = target, 3 = clock. Centered at (cx, cy). */
    private fun drawIcon(c: Canvas, kind: Int, cx: Float, cy: Float, r: Float, color: Int) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.STROKE; strokeWidth = r * 0.28f }
        when (kind) {
            1 -> {
                val path = Path().apply {
                    moveTo(cx, cy + r * 1.1f)
                    lineTo(cx - r * 0.75f, cy - r * 0.1f)
                    addCircle(cx, cy - r * 0.45f, r * 0.8f, Path.Direction.CW)
                    lineTo(cx + r * 0.75f, cy - r * 0.1f)
                    close()
                }
                c.drawPath(path, fill)
                c.drawCircle(cx, cy - r * 0.45f, r * 0.3f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFF2B2B2B.toInt() })
            }
            2 -> {
                c.drawCircle(cx, cy, r * 0.62f, line)
                c.drawCircle(cx, cy, r * 0.2f, fill)
                c.drawLine(cx, cy - r * 1.05f, cx, cy - r * 0.5f, line); c.drawLine(cx, cy + r * 0.5f, cx, cy + r * 1.05f, line)
                c.drawLine(cx - r * 1.05f, cy, cx - r * 0.5f, cy, line); c.drawLine(cx + r * 0.5f, cy, cx + r * 1.05f, cy, line)
            }
            3 -> {
                c.drawCircle(cx, cy, r * 0.95f, line)
                c.drawLine(cx, cy, cx, cy - r * 0.55f, line)
                c.drawLine(cx, cy, cx + r * 0.4f, cy + r * 0.15f, line)
            }
        }
    }

    private fun marginOf(c: StampConfig, u: Float) = if (c.layout == LayoutKind.LANDSCAPE) 0f else 24f * u
    private fun cardWidthPx(w: Int, c: StampConfig, u: Float): Float =
        (w * c.cardWidth).coerceAtMost(w - 2 * marginOf(c, u)).coerceAtLeast(120f)

    /** Pixel size the map bitmap should have for an image of [w]x[h]; null when the map is off. */
    fun mapBoxSize(w: Int, h: Int, c: StampConfig): Pair<Int, Int>? {
        if (!c.showMap) return null
        val u = min(w, h) / 1080f
        if (c.layout == LayoutKind.CARDS) return Pair((CardStyles.MAP_REQ * u).toInt().coerceAtLeast(64), (CardStyles.MAP_REQ * u).toInt().coerceAtLeast(64))
        if (c.layout == LayoutKind.GMC) return Pair((GmcCard.MAP_W * u).toInt().coerceAtLeast(64), (GmcCard.MAP_H * u).toInt().coerceAtLeast(64))
        val inner = cardWidthPx(w, c, u) - 2 * c.padding * u
        return if (effectiveMapPos(c) == MapPos.TOP) {
            Pair(inner.toInt().coerceAtLeast(64), (inner * c.mapSize).toInt().coerceAtLeast(64))
        } else {
            val s = (inner * c.mapSize).toInt().coerceAtLeast(64)
            Pair(s, s)
        }
    }

    private fun typeface(f: FontFace): Typeface = when (f) {
        FontFace.SANS -> Typeface.SANS_SERIF
        FontFace.SERIF -> Typeface.SERIF
        FontFace.MONO -> Typeface.MONOSPACE
        FontFace.CONDENSED -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        FontFace.LIGHT -> Typeface.create("sans-serif-light", Typeface.NORMAL)
    }

    private fun withAlpha(color: Int, factor: Float): Int =
        Color.argb((Color.alpha(color) * factor).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun withAlphaInt(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun layoutOf(text: CharSequence, p: TextPaint, width: Int, align: Layout.Alignment): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width.coerceAtLeast(1))
            .setAlignment(align).setIncludePad(false).setLineSpacing(0f, 1.05f).build()

    private fun timePattern(c: StampConfig): String =
        if (c.use24h) (if (c.showSeconds) "HH:mm:ss" else "HH:mm") else (if (c.showSeconds) "hh:mm:ss a" else "hh:mm a")

    private fun buildRows(c: StampConfig, d: StampData, companyAsRow: String?): List<Row> {
        val out = ArrayList<Row>()
        val biz = c.layout == LayoutKind.BUSINESS
        val tz = TimeZone.getTimeZone(d.tzId)
        fun fmt(p: String): String = SimpleDateFormat(p, Locale.getDefault()).apply { timeZone = tz }.format(Date(d.captureTimeMs))
        val lat = d.lat
        val lon = d.lon
        val hasFix = lat != null && lon != null

        if (companyAsRow != null) out += Row(null, companyAsRow, 1.2f, true)
        if (c.title.isNotBlank()) out += Row(null, c.title.trim(), 1.25f, true)
        if (c.subtitle.isNotBlank()) out += Row(null, c.subtitle.trim(), 0.95f, false, dim = true)

        if (c.showAddress) {
            val a = d.address
            val line = a?.line ?: a?.let {
                listOfNotNull(it.street, it.area, it.city, it.state, it.country).joinToString(", ").ifBlank { null }
            }
            if (c.layout == LayoutKind.FULL_ADDRESS && a != null) {
                if (line != null) out += Row(null, line, 1.1f, true, icon = 1)
                listOfNotNull(
                    a.street?.let { "Street: $it" }, a.area?.let { "Area: $it" }, a.city?.let { "City: $it" },
                    a.district?.let { "District: $it" }, a.state?.let { "State: $it" },
                    a.country?.let { "Country: $it" }, a.postal?.let { "Postal code: $it" },
                ).forEach { out += Row(null, it, 0.9f, false) }
            } else if (line != null) {
                out += Row(if (biz) "Address" else null, line, if (c.layout == LayoutKind.COMPACT) 0.9f else 1.05f, !biz, icon = 1)
            } else if (hasFix) {
                out += Row(if (biz) "Address" else null, "Address unavailable", 0.95f, false, dim = true)
            }
        }

        if (lat == null || lon == null) {
            out += Row(if (biz) "GPS" else null, "GPS location unavailable at capture time", 1f, true)
        } else if (c.showCoords) {
            val la = Geo.coordinate(lat, true, c.coordFormat)
            val lo = Geo.coordinate(lon, false, c.coordFormat)
            when {
                c.layout == LayoutKind.COORDS_FOCUS -> {
                    out += Row(null, "Lat  $la", 1.35f, true)
                    out += Row(null, "Long  $lo", 1.35f, true)
                }
                biz -> out += Row("Coordinates", "$la, $lo", 1f, false)
                else -> out += Row(null, "Lat  $la\nLong  $lo", 0.95f, false, icon = 2)
            }
        }

        val dt = ArrayList<String>()
        if (c.showDate) dt += fmt(c.dateFormat)
        if (c.showTime) dt += fmt(timePattern(c))
        if (c.showTimezone) dt += fmt("zzz")
        if (dt.isNotEmpty()) out += Row(if (biz) "Date / time" else null, dt.joinToString("  "), 0.95f, false, icon = 3)

        if (hasFix) {
            val meta = ArrayList<Pair<String, String>>()
            val alt = d.altitudeM
            val spd = d.speedMps
            val hdg = d.headingDeg
            val acc = d.accuracyM
            if (c.showAltitude && alt != null) meta += (if (biz) "Altitude" else "Alt") to Geo.distance(alt, c.units)
            if (c.showSpeed && spd != null) meta += "Speed" to Geo.speed(spd, c.units)
            if (c.showCompass && hdg != null) meta += (if (biz) "Direction" else "Dir") to Geo.heading(hdg)
            if (c.showAccuracy) {
                meta += "Accuracy" to (if (acc != null) "${Geo.accuracy(acc, c.units)} (${Geo.accuracyLevel(acc).label})" else "unknown")
            }
            if (biz) meta.forEach { out += Row(it.first, it.second, 0.95f, false) }
            else if (meta.isNotEmpty()) out += Row(null, meta.joinToString("  ·  ") { "${it.first} ${it.second}" }, 0.85f, false, dim = true)

            val age = d.fixAgeMs
            if (age != null && age > 30_000L) out += Row(null, "Cached location, ${Geo.ageText(age)} old", 0.85f, true)
            if (d.isMock) out += Row(null, "Mock location provider active", 0.85f, true)
        }
        if (c.customText.isNotBlank()) out += Row(null, c.customText.trim(), 0.9f, false, dim = true)

        if (c.layout == LayoutKind.LANDSCAPE) {
            val half = (out.size + 1) / 2
            out.forEachIndexed { i, r -> r.col = if (i < half) 0 else 1 }
        }
        return out
    }

    /** Where the card and logo slot ended up (pixel coords of the canvas), for tap targets in the live preview. */
    class StampHit { var card: RectF? = null; var logo: RectF? = null }

    /**
     * [placeholder] draws an empty "add logo" slot when no logo is set. Only the live preview uses it; saved photos never do.
     */
    fun draw(
        canvas: Canvas, w: Int, h: Int, c: StampConfig, d: StampData, map: Bitmap?, logo: Bitmap?,
        placeholder: Boolean = false, hit: StampHit? = null,
    ) {
        if (c.layout == LayoutKind.GMC) { GmcCard.draw(canvas, w, h, c, d, map, logo, placeholder, hit); return }
        if (c.layout == LayoutKind.CARDS) { CardStyles.draw(canvas, w, h, c, d, map, logo, placeholder, hit); return }
        val u = min(w, h) / 1080f
        var fs = 1f
        var cardH = compose(null, w, h, u, c, d, map, logo, fs, 0f, placeholder, null)
        while (cardH > h * 0.55f && fs > 0.45f) {
            fs *= 0.9f
            cardH = compose(null, w, h, u, c, d, map, logo, fs, 0f, placeholder, null)
        }
        val margin = marginOf(c, u)
        val y0 = if (c.position.name.startsWith("TOP")) margin else h - margin - (if (c.layout == LayoutKind.LANDSCAPE) 0f else 24f * u) - cardH
        compose(canvas, w, h, u, c, d, map, logo, fs, y0, placeholder, hit)
    }

    /** Lays the card out (and paints it when [canvas] is non-null). Returns the card height in px. */
    private fun compose(
        canvas: Canvas?, w: Int, h: Int, u: Float, c: StampConfig, d: StampData,
        map: Bitmap?, logo: Bitmap?, fs: Float, y0: Float, placeholder: Boolean, hit: StampHit?,
    ): Float {
        val margin = marginOf(c, u)
        val cardW = cardWidthPx(w, c, u)
        val x0 = when (c.position) {
            StampPosition.TOP_LEFT, StampPosition.BOTTOM_LEFT -> margin
            StampPosition.TOP_CENTER, StampPosition.BOTTOM_CENTER -> (w - cardW) / 2f
            StampPosition.TOP_RIGHT, StampPosition.BOTTOM_RIGHT -> w - margin - cardW
        }
        val pad = c.padding * u
        val gap = c.spacing * u
        val inner = cardW - 2 * pad
        val base = 30f * u * c.fontScale * fs
        val face = typeface(c.fontFace)
        val boldFace = Typeface.create(face, Typeface.BOLD)
        val bgA = (c.bgOpacity * 255).toInt().coerceIn(0, 255)
        val textShadow = c.shadow && bgA <= 12
        val align = when (c.align) {
            TextAlignment.LEFT -> Layout.Alignment.ALIGN_NORMAL
            TextAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignment.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
        }

        fun paintFor(scale: Float, bold: Boolean, dim: Boolean): TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = if (bold) boldFace else face
            textSize = base * scale
            color = if (dim) withAlpha(c.textColor, 0.78f) else c.textColor
            if (textShadow) setShadowLayer(5f * u, 0f, 2f * u, 0xCC000000.toInt())
        }

        // ---- logo geometry (aspect ratio always preserved) ----
        val realLogo = c.logoOn && logo != null && !logo.isRecycled && logo.width > 0 && logo.height > 0
        val logoActive = realLogo || (c.logoOn && placeholder)
        val lp = if (c.logoBgOn || c.logoBorderOn) c.logoPadding * u else 0f
        var logoW = 0f
        var logoH = 0f
        if (realLogo && logo != null) {
            val maxH = c.logoSize * u * fs.coerceAtLeast(0.6f)
            val maxW = inner * 0.42f
            val s = min(maxH / logo.height, maxW / logo.width)
            logoW = logo.width * s
            logoH = logo.height * s
        } else if (logoActive) {
            logoW = c.logoSize * u * fs.coerceAtLeast(0.6f)
            logoH = logoW
        }
        val boxW = logoW + 2 * lp
        val boxH = logoH + 2 * lp
        val company = if (c.showCompany && c.companyName.isNotBlank()) c.companyName.trim() else null
        val headerBand = (c.logoPos == LogoPos.TOP || c.logoPos == LogoPos.BOTTOM) && (logoActive || company != null)
        val sideLogo = logoActive && (c.logoPos == LogoPos.LEFT || c.logoPos == LogoPos.RIGHT)
        val companyAsRow = if (!headerBand) company else null

        var companyLayout: StaticLayout? = null
        var headerH = 0f
        var groupW = 0f
        if (headerBand) {
            if (company != null) {
                val cp = paintFor(1.2f, true, false)
                val maxW = (inner - (if (logoActive) boxW + gap else 0f)).coerceAtLeast(40f)
                val desired = Layout.getDesiredWidth(company, cp)
                companyLayout = layoutOf(company, cp, ceil(min(desired, maxW)).toInt(), Layout.Alignment.ALIGN_NORMAL)
            }
            val cH = companyLayout?.height?.toFloat() ?: 0f
            headerH = max(if (logoActive) boxH else 0f, cH)
            groupW = (if (logoActive) boxW else 0f) +
                (if (logoActive && companyLayout != null) gap else 0f) +
                (companyLayout?.width?.toFloat() ?: 0f)
        }

        // ---- map geometry ----
        val mapPos = if (map != null) effectiveMapPos(c) else null
        var mapDrawW = 0f
        var mapDrawH = 0f
        if (map != null && mapPos != null) {
            if (mapPos == MapPos.TOP) {
                mapDrawW = inner
                mapDrawH = map.height * (inner / map.width)
            } else {
                val s = min(map.width.toFloat(), inner * 0.5f) / map.width
                mapDrawW = map.width * s
                mapDrawH = map.height * s
            }
        }
        val mapSide = mapPos == MapPos.LEFT || mapPos == MapPos.RIGHT

        // ---- text ----
        val sideW = if (sideLogo) boxW + gap else 0f
        val mapSideW = if (mapSide) mapDrawW + gap else 0f
        val textW = (inner - sideW - mapSideW).coerceAtLeast(inner * 0.3f)
        val rows = buildRows(c, d, companyAsRow)
        val nCol = if (c.layout == LayoutKind.LANDSCAPE) 2 else 1
        val colW = (textW - gap * (nCol - 1)) / nCol
        val useIcons = c.layout == LayoutKind.CLASSIC || c.layout == LayoutKind.MODERN
        val gutter = if (useIcons) base * 1.5f else 0f
        val cols = List(nCol) { ArrayList<Pair<StaticLayout, Int>>() }
        for (r in rows) {
            val cp = paintFor(r.scale, r.bold, r.dim)
            val text: CharSequence = if (r.label != null) {
                SpannableStringBuilder().apply {
                    append(r.label).append(": ")
                    setSpan(StyleSpan(Typeface.BOLD), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    append(r.text)
                }
            } else r.text
            cols[r.col.coerceIn(0, nCol - 1)] += Pair(layoutOf(text, cp, (colW - gutter).toInt(), align), r.icon)
        }
        val colHeights = cols.map { ls -> ls.sumOf { it.first.height.toDouble() }.toFloat() + gap * max(0, ls.size - 1) }
        val textH = colHeights.maxOrNull() ?: 0f

        val badgePaint = paintFor(0.6f, true, true)
        val badgeH = if (c.showAppBadge) badgePaint.fontSpacing else 0f

        val contentH = max(textH, max(if (mapSide) mapDrawH else 0f, if (sideLogo) boxH else 0f))
        val mapTopH = if (mapPos == MapPos.TOP) mapDrawH + gap else 0f
        val headerTop = headerBand && c.logoPos == LogoPos.TOP
        val headerBottom = headerBand && c.logoPos == LogoPos.BOTTOM
        val cardH = pad * 2 +
            (if (headerTop) headerH + gap else 0f) + mapTopH + contentH +
            (if (headerBottom) gap + headerH else 0f) +
            (if (c.showAppBadge) gap * 0.6f + badgeH else 0f)

        if (canvas == null) return cardH

        // ---- paint ----
        val rect = RectF(x0, y0, x0 + cardW, y0 + cardH)
        hit?.card = RectF(rect)
        val ext = 30f * u
        val layer = canvas.saveLayerAlpha(
            rect.left - ext, rect.top - ext, rect.right + ext, rect.bottom + ext,
            (c.cardAlpha * 255).toInt().coerceIn(0, 255),
        )
        val cr = c.cornerRadius * u
        if (bgA > 0) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = withAlphaInt(c.bgColor, bgA)
                if (c.shadow) setShadowLayer(14f * u, 0f, 5f * u, 0x55000000)
            }
            canvas.drawRoundRect(rect, cr, cr, bp)
        }
        if (c.borderOn) {
            val bw = c.borderWidth * u
            val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = bw; color = c.borderColor }
            canvas.drawRoundRect(RectF(rect.left + bw / 2, rect.top + bw / 2, rect.right - bw / 2, rect.bottom - bw / 2), cr, cr, bp)
        }

        val cx = x0 + pad
        var cy = y0 + pad

        fun drawLogoBox(x: Float, y: Float) {
            val box = RectF(x, y, x + boxW, y + boxH)
            hit?.logo = RectF(box)
            if (!realLogo || logo == null) {
                val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = 2.5f * u; color = withAlpha(c.textColor, 0.8f)
                    pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f * u, 8f * u), 0f)
                }
                canvas.drawRoundRect(box, 14f * u, 14f * u, dash)
                val tp = paintFor(0.8f, true, false)
                val cxm = box.centerX()
                canvas.drawText("+", cxm - tp.measureText("+") / 2f, box.centerY() - tp.descent() * 0.2f, tp)
                val lt = paintFor(0.55f, false, true)
                canvas.drawText("Logo", cxm - lt.measureText("Logo") / 2f, box.centerY() + lt.textSize * 1.6f, lt)
                return
            }
            logo ?: return
            val rad = c.logoCorner * u
            if (c.logoBgOn) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlphaInt(c.logoBgColor, (c.logoBgOpacity * 255).toInt()) }
                canvas.drawRoundRect(box, rad, rad, p)
            }
            if (c.logoBorderOn) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * u; color = c.logoBorderColor }
                canvas.drawRoundRect(box, rad, rad, p)
            }
            val lpaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply { alpha = (c.logoOpacity * 255).toInt().coerceIn(0, 255) }
            canvas.drawBitmap(logo, null, RectF(x + lp, y + lp, x + lp + logoW, y + lp + logoH), lpaint)
        }

        fun drawHeader(top: Float) {
            var x = when (c.logoAlign) {
                LogoAlign.START -> cx
                LogoAlign.CENTER -> cx + (inner - groupW) / 2f
                LogoAlign.END -> cx + inner - groupW
            }
            if (logoActive) { drawLogoBox(x, top + (headerH - boxH) / 2f); x += boxW + gap }
            companyLayout?.let {
                canvas.save(); canvas.translate(x, top + (headerH - it.height) / 2f); it.draw(canvas); canvas.restore()
            }
        }

        fun drawMap(x: Float, y: Float) {
            if (map == null) return
            val dst = RectF(x, y, x + mapDrawW, y + mapDrawH)
            canvas.save()
            val clip = Path().apply { val r = min(cr * 0.6f, 14f * u); addRoundRect(dst, r, r, Path.Direction.CW) }
            canvas.clipPath(clip)
            canvas.drawBitmap(map, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            canvas.restore()
        }

        if (headerTop) { drawHeader(cy); cy += headerH + gap }
        if (mapPos == MapPos.TOP) { drawMap(cx, cy); cy += mapDrawH + gap }

        val rowY = cy
        var xl = cx
        var xr = cx + inner
        fun logoY(): Float = when (c.logoAlign) {
            LogoAlign.START -> rowY
            LogoAlign.CENTER -> rowY + (contentH - boxH) / 2f
            LogoAlign.END -> rowY + contentH - boxH
        }
        if (sideLogo && c.logoPos == LogoPos.LEFT) { drawLogoBox(xl, logoY()); xl += boxW + gap }
        if (sideLogo && c.logoPos == LogoPos.RIGHT) { xr -= boxW; drawLogoBox(xr, logoY()); xr -= gap }
        if (mapSide && mapPos == MapPos.LEFT) { drawMap(xl, rowY); xl += mapDrawW + gap }
        if (mapSide && mapPos == MapPos.RIGHT) { xr -= mapDrawW; drawMap(xr, rowY); xr -= gap }

        for (i in 0 until nCol) {
            var y = rowY
            val x = xl + i * (colW + gap)
            for ((l, icon) in cols[i]) {
                if (icon != 0) drawIcon(canvas, icon, x + gutter * 0.4f, y + l.getLineBottom(0).toFloat() / 2f, base * 0.5f, c.textColor)
                canvas.save(); canvas.translate(x + gutter, y); l.draw(canvas); canvas.restore()
                y += l.height + gap
            }
        }
        if (useIcons) {
            val dp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = withAlpha(c.textColor, 0.3f); strokeWidth = max(1f, 2f * u) }
            val y1 = rowY + contentH * 0.1f
            val y2 = rowY + contentH * 0.9f
            if (mapSide && mapPos == MapPos.LEFT) canvas.drawLine(xl - gap / 2f, y1, xl - gap / 2f, y2, dp)
            if (mapSide && mapPos == MapPos.RIGHT) canvas.drawLine(xr + gap / 2f, y1, xr + gap / 2f, y2, dp)
            if (sideLogo && c.logoPos == LogoPos.RIGHT) canvas.drawLine(xr + gap / 2f, y1, xr + gap / 2f, y2, dp)
        }
        cy = rowY + contentH
        if (headerBottom) { drawHeader(cy + gap); cy += gap + headerH }

        if (c.showAppBadge) {
            val tw = badgePaint.measureText(APP_BADGE)
            val dot = badgePaint.textSize * 0.55f
            val total = tw + dot * 2.2f
            val bx = if (c.align == TextAlignment.CENTER) cx + (inner - total) / 2f else cx + inner - total
            val by = y0 + cardH - pad - badgeH
            val dp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFBBF24.toInt() }
            canvas.drawCircle(bx + dot * 0.6f, by + badgeH / 2f, dot * 0.5f, dp)
            canvas.drawText(APP_BADGE, bx + dot * 2.2f, by - badgePaint.ascent(), badgePaint)
        }
        canvas.restoreToCount(layer)
        return cardH
    }
}
