package com.ttk.gpscam.ui

import android.content.Context
import android.content.res.Configuration
import android.util.Size
import android.view.OrientationEventListener
import android.view.Surface
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.asImageBitmap
import com.ttk.gpscam.stamp.PhotoStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FlashAuto
import androidx.compose.material.icons.outlined.FlashOff
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.FlipCameraAndroid
import androidx.compose.material.icons.outlined.GpsFixed
import androidx.compose.material.icons.outlined.GpsNotFixed
import androidx.compose.material.icons.outlined.GpsOff
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ttk.gpscam.CaptureUi
import com.ttk.gpscam.MainViewModel
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.core.UnitSystem
import com.ttk.gpscam.data.AppSettings
import com.ttk.gpscam.data.AspectPref
import com.ttk.gpscam.data.FlashPref
import com.ttk.gpscam.data.ResPref
import com.ttk.gpscam.location.GpsStatus
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.math.roundToInt

private suspend fun Context.awaitCameraProvider(): ProcessCameraProvider = suspendCoroutine { cont ->
    val f = ProcessCameraProvider.getInstance(this)
    f.addListener({ cont.resume(f.get()) }, ContextCompat.getMainExecutor(this))
}

@Composable
fun CameraScreen(vm: MainViewModel, settings: AppSettings, onOpenLocation: () -> Unit, onOpenSettings: () -> Unit, onOpenGallery: () -> Unit) {
    val ctx = LocalContext.current
    val perms = rememberPerms(vm)
    LocationEffect(vm)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!perms.camera) {
            PermissionPrompt(askedBefore = perms.askedBefore, onGrant = perms.request, onSettings = { openAppSettings(ctx) })
        } else {
            CameraContent(vm, settings, perms.location, perms.askedBefore, perms.request, onOpenLocation, onOpenSettings, onOpenGallery)
        }
    }
}

@Composable
private fun PermissionPrompt(askedBefore: Boolean, onGrant: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Outlined.PhotoCamera, null, tint = Amber, modifier = Modifier.size(64.dp))
        Text("Camera access needed", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Text(
            "TTK GPS Cam needs the camera to take photos and your location to stamp them. Nothing leaves your phone.",
            color = Color(0xFFB4C4C2), modifier = Modifier.padding(vertical = 16.dp),
        )
        Button(onClick = onGrant) { Text("Grant permissions") }
        if (askedBefore) {
            TextButton(onClick = onSettings) { Text("Open app settings", color = Amber) }
        }
    }
}

@Composable
private fun CameraContent(
    vm: MainViewModel, settings: AppSettings, locationGranted: Boolean, askedBefore: Boolean, requestPerms: () -> Unit,
    onOpenLocation: () -> Unit, onOpenSettings: () -> Unit, onOpenGallery: () -> Unit,
) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val config = LocalConfiguration.current
    val portrait = config.orientation == Configuration.ORIENTATION_PORTRAIT
    val loc by vm.location.state.collectAsState()
    val capture by vm.capture.collectAsState()
    val logo by vm.logo.collectAsState()

    var front by remember(settings.frontCamera) { mutableStateOf(settings.frontCamera) }
    var flash by remember(settings.flash) { mutableStateOf(settings.flash) }
    var aspect by remember(settings.aspect) { mutableStateOf(settings.aspect) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var provider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var hasFlash by remember { mutableStateOf(false) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }
    var zoomMin by remember { mutableFloatStateOf(1f) }
    var zoomMax by remember { mutableFloatStateOf(1f) }
    var focusPoint by remember { mutableStateOf(Offset.Zero) }
    var focusTick by remember { mutableIntStateOf(0) }
    var focusVisible by remember { mutableStateOf(false) }
    // Device rotation (clockwise degrees: 0, 90, 180, 270). The UI itself stays portrait; the stamp card and the
    // icons counter-rotate smoothly so they always read upright, like a native camera app.
    var deviceRot by remember { mutableIntStateOf(0) }
    var target by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(deviceRot) {
        val want = (-deviceRot).toFloat()
        var diff = ((want - target) % 360f + 540f) % 360f - 180f
        target += diff
    }
    val angle by animateFloatAsState(target, animationSpec = androidx.compose.animation.core.tween(320), label = "rot")

    val previewView = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    // (Re)bind the camera when lens, aspect or resolution change.
    LaunchedEffect(front, aspect, settings.resolution) {
        cameraError = null
        try {
            val p = ctx.awaitCameraProvider()
            provider = p
            val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            if (!p.hasCamera(selector)) {
                cameraError = if (front) "No front camera is available on this device." else "No rear camera is available on this device."
                return@LaunchedEffect
            }
            val aspectStrategy = if (aspect == AspectPref.R4_3) AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            else AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            val resStrategy = when (settings.resolution) {
                ResPref.MAX -> ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY
                ResPref.HIGH -> ResolutionStrategy(Size(3264, 2448), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                ResPref.STANDARD -> ResolutionStrategy(Size(1600, 1200), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
            }
            val preview = Preview.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspectStrategy).build())
                .build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val cap = ImageCapture.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspectStrategy).setResolutionStrategy(resStrategy).build())
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setTargetRotation(previewView.display?.rotation ?: Surface.ROTATION_0)
                .build()
            p.unbindAll()
            val cam = p.bindToLifecycle(lifecycleOwner, selector, preview, cap)
            camera = cam
            imageCapture = cap
            hasFlash = cam.cameraInfo.hasFlashUnit()
            val zs = cam.cameraInfo.zoomState.value
            zoomMin = zs?.minZoomRatio ?: 1f
            zoomMax = zs?.maxZoomRatio ?: 1f
            zoomRatio = settings.defaultZoom.coerceIn(zoomMin, zoomMax)
        } catch (e: Exception) {
            cameraError = "Camera unavailable: ${e.message ?: "unknown error"}"
        }
    }

    LaunchedEffect(flash, imageCapture) {
        imageCapture?.flashMode = when (flash) {
            FlashPref.AUTO -> ImageCapture.FLASH_MODE_AUTO
            FlashPref.ON -> ImageCapture.FLASH_MODE_ON
            FlashPref.OFF -> ImageCapture.FLASH_MODE_OFF
        }
    }
    LaunchedEffect(zoomRatio, camera) { camera?.cameraControl?.setZoomRatio(zoomRatio) }
    LaunchedEffect(focusTick) {
        if (focusTick > 0) { focusVisible = true; delay(1200); focusVisible = false }
    }

    // Keep photo orientation correct in portrait, landscape and reverse landscape.
    DisposableEffect(imageCapture) {
        val l = object : OrientationEventListener(ctx) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                deviceRot = when (o) { in 45..134 -> 90; in 135..224 -> 180; in 225..314 -> 270; else -> 0 }
                imageCapture?.targetRotation = when (o) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
            }
        }
        if (l.canDetectOrientation()) l.enable()
        onDispose { l.disable() }
    }
    DisposableEffect(Unit) { onDispose { provider?.unbindAll() } }

    val ratio = when {
        portrait && aspect == AspectPref.R4_3 -> 3f / 4f
        portrait -> 9f / 16f
        aspect == AspectPref.R4_3 -> 4f / 3f
        else -> 16f / 9f
    }

    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let { vm.importLogo(it) } }
    val pickLogo = { logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    val galleryVersion by vm.galleryVersion.collectAsState()
    val lastThumb by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, galleryVersion) {
        value = withContext(Dispatchers.IO) {
            val first = PhotoStore.list(ctx).firstOrNull() ?: return@withContext null
            runCatching { ctx.contentResolver.loadThumbnail(first.uri, Size(200, 200), null).asImageBitmap() }.getOrNull()
        }
    }

    val glass = Color(0x22FFFFFF)
    val glassEdge = Color(0x4D3FE0B0)
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF052A20), Color(0xFF021812))))) {
        // ---------- curved top bar ----------
        Row(
            Modifier.fillMaxWidth()
                .clip(WaveShape(top = false))
                .background(Brush.verticalGradient(listOf(Color(0xFF0C4234), Color(0xFF04271E))))
                .statusBarsPadding()
                .padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 22.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // GPS status (opens the Location screen): a dot shows the state, no accuracy text
            val dot = when (loc.status) {
                GpsStatus.HIGH_ACCURACY -> Color(0xFF22E58A)
                GpsStatus.ACQUIRED -> Color(0xFF84CC16)
                GpsStatus.LOW_ACCURACY, GpsStatus.STALE -> Amber
                GpsStatus.ACQUIRING -> Color(0xFF60A5FA)
                else -> Color(0xFFEF4444)
            }
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(glass).border(1.dp, glassEdge, CircleShape).clickable(onClick = onOpenLocation),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Outlined.GpsFixed, "Location", tint = Color.White, modifier = Modifier.graphicsLayer { rotationZ = angle })
                Box(Modifier.align(Alignment.TopEnd).padding(7.dp).size(9.dp).clip(CircleShape).background(dot))
            }
            Box(Modifier.weight(1f))
            if (hasFlash) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(glass).border(1.dp, glassEdge, CircleShape)
                        .clickable { flash = when (flash) { FlashPref.AUTO -> FlashPref.ON; FlashPref.ON -> FlashPref.OFF; FlashPref.OFF -> FlashPref.AUTO } },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        when (flash) { FlashPref.AUTO -> Icons.Outlined.FlashAuto; FlashPref.ON -> Icons.Outlined.FlashOn; FlashPref.OFF -> Icons.Outlined.FlashOff },
                        "Flash ${flash.label}", tint = Color.White, modifier = Modifier.graphicsLayer { rotationZ = angle },
                    )
                }
                Box(Modifier.size(10.dp))
            }
            Text(
                aspect.label, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(glass).border(1.dp, glassEdge, RoundedCornerShape(14.dp))
                    .clickable { aspect = if (aspect == AspectPref.R4_3) AspectPref.R16_9 else AspectPref.R4_3 }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            )
            Box(Modifier.size(10.dp))
            Box(
                Modifier.size(44.dp).clickable(onClick = onOpenSettings),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Settings, "Settings", tint = Color.White, modifier = Modifier.graphicsLayer { rotationZ = angle }) }
        }
        // zoom pill
        Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
            Text(
                String.format("%.1fx", zoomRatio), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x99021812)).border(1.dp, glassEdge, RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 5.dp),
            )
        }
        val notice: String? = when {
            cameraError != null -> cameraError
            !locationGranted -> "Location permission denied – photos can't be stamped with GPS data."
            loc.status == GpsStatus.SERVICES_DISABLED -> "Location services are turned off."
            loc.warning != null -> loc.warning
            else -> null
        }
        if (notice != null) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF3A2A00)).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(notice, color = Amber, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                if (!locationGranted) TextButton(onClick = { if (askedBefore) openAppSettings(ctx) else requestPerms() }) { Text(if (askedBefore) "Settings" else "Allow", color = Color.White) }
                else if (loc.status == GpsStatus.SERVICES_DISABLED) TextButton(onClick = { openLocationSettings(ctx) }) { Text("Turn on", color = Color.White) }
            }
        }

        // ---------- preview ----------
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.aspectRatio(ratio).clip(RoundedCornerShape(0.dp))) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                Box(
                    Modifier.fillMaxSize()
                        .pointerInput(camera) {
                            detectTapGestures { off ->
                                val cam = camera ?: return@detectTapGestures
                                val pt = previewView.meteringPointFactory.createPoint(off.x, off.y)
                                val action = FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                                    .setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                                runCatching { cam.cameraControl.startFocusAndMetering(action) }
                                focusPoint = off; focusTick++
                            }
                        }
                        .pointerInput(camera) {
                            detectTransformGestures { _, _, zoom, _ ->
                                if (zoom != 1f) zoomRatio = (zoomRatio * zoom).coerceIn(zoomMin, zoomMax)
                            }
                        },
                )
                Crosshair(Modifier.align(Alignment.Center))
                if (settings.stampEnabled) {
                    StampOverlay(cfg = settings.stamp, st = loc, logo = logo, modifier = Modifier.fillMaxSize(), onLogoTap = pickLogo, angle = angle, landscape = deviceRot % 180 == 90)
                }
                if (focusVisible) {
                    Box(
                        Modifier
                            .offset { IntOffset((focusPoint.x - 36.dp.toPx()).roundToInt(), (focusPoint.y - 36.dp.toPx()).roundToInt()) }
                            .size(72.dp).border(2.dp, Amber, CircleShape),
                    )
                }
                val cap = capture
                if (cap is CaptureUi.Waiting) {
                    Row(
                        Modifier.align(Alignment.Center).clip(RoundedCornerShape(16.dp)).background(Color(0xCC000000)).padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        CircularProgressIndicator(Modifier.size(18.dp), color = Amber, strokeWidth = 2.dp)
                        Text(
                            "Waiting for ±${cap.targetM} m (now ${cap.accuracyM?.let { Geo.accuracy(it, UnitSystem.METRIC) } ?: "no fix"})",
                            color = Color.White, style = MaterialTheme.typography.bodySmall,
                        )
                        TextButton(onClick = { vm.skipAccuracyWait() }) { Text("Now", color = Amber) }
                    }
                }
            }
        }

        // ---------- curved bottom panel with the shutter row ----------
        Row(
            Modifier.fillMaxWidth()
                .clip(WaveShape(top = true))
                .background(Brush.verticalGradient(listOf(Color(0xFF04271E), Color(0xFF021812))))
                .padding(start = 28.dp, end = 28.dp, top = 30.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(62.dp).graphicsLayer { rotationZ = angle }.clip(CircleShape).background(glass).border(1.dp, glassEdge, CircleShape).clickable(onClick = onOpenGallery),
                contentAlignment = Alignment.Center,
            ) {
                val t = lastThumb
                if (t != null) androidx.compose.foundation.Image(t, "Gallery", Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                else Icon(Icons.Outlined.PhotoLibrary, "Gallery", tint = Color.White)
            }
            ShutterButton(busy = capture !is CaptureUi.Idle, enabled = imageCapture != null && cameraError == null) {
                imageCapture?.let { vm.capture(it) }
            }
            Box(
                Modifier.size(62.dp).clip(CircleShape).background(glass).border(1.dp, glassEdge, CircleShape).clickable { front = !front },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.FlipCameraAndroid, "Switch camera", tint = Color.White, modifier = Modifier.graphicsLayer { rotationZ = angle }) }
        }
    }
}

/** Header / panel outline with a gently curved edge (bottom edge for the header, top edge for the panel). */
private class WaveShape(private val top: Boolean) : androidx.compose.ui.graphics.Shape {
    override fun createOutline(size: androidx.compose.ui.geometry.Size, layoutDirection: androidx.compose.ui.unit.LayoutDirection, density: androidx.compose.ui.unit.Density): androidx.compose.ui.graphics.Outline {
        val w = size.width
        val h = size.height
        val a = 14f * density.density
        val p = androidx.compose.ui.graphics.Path()
        if (!top) {
            p.moveTo(0f, 0f); p.lineTo(w, 0f); p.lineTo(w, h - a)
            p.cubicTo(w * 0.75f, h + a * 0.4f, w * 0.35f, h - a * 1.6f, 0f, h - a * 0.2f)
            p.close()
        } else {
            p.moveTo(0f, a * 1.2f)
            p.cubicTo(w * 0.3f, -a * 0.2f, w * 0.7f, a * 1.8f, w, a * 0.2f)
            p.lineTo(w, h); p.lineTo(0f, h)
            p.close()
        }
        return androidx.compose.ui.graphics.Outline.Generic(p)
    }
}

/** Small centre cross in the viewfinder (preview only, never in the saved photo). */
@Composable
private fun Crosshair(modifier: Modifier) {
    androidx.compose.foundation.Canvas(modifier.size(34.dp)) {
        val c = Color(0xDDFFFFFF)
        drawLine(c, Offset(size.width / 2f, 0f), Offset(size.width / 2f, size.height), 1.6.dp.toPx())
        drawLine(c, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1.6.dp.toPx())
    }
}

@Composable
private fun ShutterButton(busy: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.86f else 1f, label = "shutter")
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(92.dp).scale(s)) {
        Box(Modifier.size(92.dp).clip(CircleShape).background(Color(0x221DE9B6)))
        Box(
            Modifier.size(84.dp).border(4.dp, Color(0xFF1DE9B6), CircleShape).padding(8.dp).clip(CircleShape)
                .background(if (busy || !enabled) Color(0xFF8A9A98) else Color.White)
                .clickable(interactionSource = interaction, indication = null, enabled = enabled && !busy, onClick = onClick),
        )
        if (busy) CircularProgressIndicator(Modifier.size(36.dp), color = Color(0xFF01B880), strokeWidth = 3.dp)
    }
}

@Composable
fun GpsChip(status: GpsStatus, accuracyM: Float?, ageMs: Long) {
    val color = when (status) {
        GpsStatus.HIGH_ACCURACY -> Color(0xFF22C55E)
        GpsStatus.ACQUIRED -> Color(0xFF84CC16)
        GpsStatus.LOW_ACCURACY, GpsStatus.STALE -> Amber
        GpsStatus.ACQUIRING -> Color(0xFF60A5FA)
        else -> Color(0xFFEF4444)
    }
    val text = buildString {
        append(status.label)
        if (accuracyM != null && status != GpsStatus.PERMISSION_DENIED && status != GpsStatus.SERVICES_DISABLED) {
            append(" · ").append(Geo.accuracy(accuracyM, UnitSystem.METRIC))
        }
        if (status == GpsStatus.STALE) append(" · ").append(Geo.ageText(ageMs)).append(" old")
    }
    Row(
        Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x66FFFFFF).compositeOver(Color(0xFF1B1B1B))).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (status == GpsStatus.ACQUIRING) CircularProgressIndicator(Modifier.size(12.dp), color = color, strokeWidth = 2.dp)
        else Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Text(text, color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}
