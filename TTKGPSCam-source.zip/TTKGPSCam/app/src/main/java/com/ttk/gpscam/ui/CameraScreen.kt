package com.ttk.gpscam.ui

import android.content.Context
import android.content.res.Configuration
import android.util.Size
import android.view.OrientationEventListener
import android.view.Surface
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FlashAuto
import androidx.compose.material.icons.outlined.FlashOff
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.FlipCameraAndroid
import androidx.compose.material.icons.outlined.GpsFixed
import androidx.compose.material.icons.outlined.GpsNotFixed
import androidx.compose.material.icons.outlined.GpsOff
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ttk.gpscam.CaptureUi
import com.ttk.gpscam.MainViewModel
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.core.UnitSystem
import com.ttk.gpscam.data.AppSettings
import com.ttk.gpscam.data.AspectPref
import com.ttk.gpscam.data.FlashPref
import com.ttk.gpscam.data.ResPref
import com.ttk.gpscam.location.GpsStatus
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.math.roundToInt

private suspend fun Context.awaitCameraProvider(): ProcessCameraProvider = suspendCoroutine { cont ->
    val f = ProcessCameraProvider.getInstance(this)
    f.addListener({ cont.resume(f.get()) }, ContextCompat.getMainExecutor(this))
}

@Composable
fun CameraScreen(vm: MainViewModel, settings: AppSettings) {
    val ctx = LocalContext.current
    val perms = rememberPerms(vm)
    LocationEffect(vm)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!perms.camera) {
            PermissionPrompt(askedBefore = perms.askedBefore, onGrant = perms.request, onSettings = { openAppSettings(ctx) })
        } else {
            CameraContent(vm, settings, perms.location, perms.askedBefore, perms.request)
        }
    }
}

@Composable
private fun PermissionPrompt(askedBefore: Boolean, onGrant: () -> Unit, onSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Outlined.PhotoCamera, null, tint = Amber, modifier = Modifier.size(64.dp))
        Text("Camera access needed", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Text(
            "TTK GPS Cam needs the camera to take photos and your location to stamp them. Nothing leaves your phone.",
            color = Color(0xFFB4C4C2), modifier = Modifier.padding(vertical = 16.dp),
        )
        Button(onClick = onGrant) { Text("Grant permissions") }
        if (askedBefore) {
            TextButton(onClick = onSettings) { Text("Open app settings", color = Amber) }
        }
    }
}

@Composable
private fun CameraContent(vm: MainViewModel, settings: AppSettings, locationGranted: Boolean, askedBefore: Boolean, requestPerms: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val config = LocalConfiguration.current
    val portrait = config.orientation == Configuration.ORIENTATION_PORTRAIT
    val loc by vm.location.state.collectAsState()
    val capture by vm.capture.collectAsState()
    val logo by vm.logo.collectAsState()

    var front by remember(settings.frontCamera) { mutableStateOf(settings.frontCamera) }
    var flash by remember(settings.flash) { mutableStateOf(settings.flash) }
    var aspect by remember(settings.aspect) { mutableStateOf(settings.aspect) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var provider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var hasFlash by remember { mutableStateOf(false) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }
    var zoomMin by remember { mutableFloatStateOf(1f) }
    var zoomMax by remember { mutableFloatStateOf(1f) }
    var focusPoint by remember { mutableStateOf(Offset.Zero) }
    var focusTick by remember { mutableIntStateOf(0) }
    var focusVisible by remember { mutableStateOf(false) }

    val previewView = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    // (Re)bind the camera when lens, aspect or resolution change.
    LaunchedEffect(front, aspect, settings.resolution) {
        cameraError = null
        try {
            val p = ctx.awaitCameraProvider()
            provider = p
            val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            if (!p.hasCamera(selector)) {
                cameraError = if (front) "No front camera is available on this device." else "No rear camera is available on this device."
                return@LaunchedEffect
            }
            val aspectStrategy = if (aspect == AspectPref.R4_3) AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            else AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            val resStrategy = when (settings.resolution) {
                ResPref.MAX -> ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY
                ResPref.HIGH -> ResolutionStrategy(Size(3264, 2448), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                ResPref.STANDARD -> ResolutionStrategy(Size(1600, 1200), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
            }
            val preview = Preview.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspectStrategy).build())
                .build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val cap = ImageCapture.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspectStrategy).setResolutionStrategy(resStrategy).build())
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setTargetRotation(previewView.display?.rotation ?: Surface.ROTATION_0)
                .build()
            p.unbindAll()
            val cam = p.bindToLifecycle(lifecycleOwner, selector, preview, cap)
            camera = cam
            imageCapture = cap
            hasFlash = cam.cameraInfo.hasFlashUnit()
            val zs = cam.cameraInfo.zoomState.value
            zoomMin = zs?.minZoomRatio ?: 1f
            zoomMax = zs?.maxZoomRatio ?: 1f
            zoomRatio = settings.defaultZoom.coerceIn(zoomMin, zoomMax)
        } catch (e: Exception) {
            cameraError = "Camera unavailable: ${e.message ?: "unknown error"}"
        }
    }

    LaunchedEffect(flash, imageCapture) {
        imageCapture?.flashMode = when (flash) {
            FlashPref.AUTO -> ImageCapture.FLASH_MODE_AUTO
            FlashPref.ON -> ImageCapture.FLASH_MODE_ON
            FlashPref.OFF -> ImageCapture.FLASH_MODE_OFF
        }
    }
    LaunchedEffect(zoomRatio, camera) { camera?.cameraControl?.setZoomRatio(zoomRatio) }
    LaunchedEffect(focusTick) {
        if (focusTick > 0) { focusVisible = true; delay(1200); focusVisible = false }
    }

    // Keep photo orientation correct in portrait, landscape and reverse landscape.
    DisposableEffect(imageCapture) {
        val l = object : OrientationEventListener(ctx) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                imageCapture?.targetRotation = when (o) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
            }
        }
        if (l.canDetectOrientation()) l.enable()
        onDispose { l.disable() }
    }
    DisposableEffect(Unit) { onDispose { provider?.unbindAll() } }

    val ratio = when {
        portrait && aspect == AspectPref.R4_3 -> 3f / 4f
        portrait -> 9f / 16f
        aspect == AspectPref.R4_3 -> 4f / 3f
        else -> 16f / 9f
    }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.align(Alignment.Center).aspectRatio(ratio).clip(RoundedCornerShape(0.dp))) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
            if (settings.stampEnabled) {
                StampOverlay(cfg = settings.stamp, st = loc, logo = logo, modifier = Modifier.fillMaxSize())
            }
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(camera) {
                        detectTapGestures { off ->
                            val cam = camera ?: return@detectTapGestures
                            val pt = previewView.meteringPointFactory.createPoint(off.x, off.y)
                            val action = FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                                .setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                            runCatching { cam.cameraControl.startFocusAndMetering(action) }
                            focusPoint = off; focusTick++
                        }
                    }
                    .pointerInput(camera) {
                        detectTransformGestures { _, _, zoom, _ ->
                            if (zoom != 1f) zoomRatio = (zoomRatio * zoom).coerceIn(zoomMin, zoomMax)
                        }
                    },
            )
            if (focusVisible) {
                Box(
                    Modifier
                        .offset { IntOffset((focusPoint.x - 36.dp.toPx()).roundToInt(), (focusPoint.y - 36.dp.toPx()).roundToInt()) }
                        .size(72.dp).border(2.dp, Amber, CircleShape),
                )
            }
        }

        // ---------- top overlay ----------
        Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                GpsChip(loc.status, loc.fix?.accuracyM, loc.ageMs)
                Box(Modifier.weight(1f))
                if (hasFlash) {
                    IconButton(onClick = { flash = when (flash) { FlashPref.AUTO -> FlashPref.ON; FlashPref.ON -> FlashPref.OFF; FlashPref.OFF -> FlashPref.AUTO } }) {
                        Icon(
                            when (flash) { FlashPref.AUTO -> Icons.Outlined.FlashAuto; FlashPref.ON -> Icons.Outlined.FlashOn; FlashPref.OFF -> Icons.Outlined.FlashOff },
                            "Flash ${flash.label}", tint = Color.White,
                        )
                    }
                }
                TextButton(onClick = { aspect = if (aspect == AspectPref.R4_3) AspectPref.R16_9 else AspectPref.R4_3 }) {
                    Text(aspect.label, color = Color.White, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { vm.update { it.copy(stampEnabled = !it.stampEnabled) } }) {
                    Icon(Icons.Outlined.Layers, "Toggle stamp", tint = if (settings.stampEnabled) Amber else Color.White)
                }
                IconButton(onClick = { front = !front }) { Icon(Icons.Outlined.FlipCameraAndroid, "Switch camera", tint = Color.White) }
            }
            when {
                cameraError != null -> Banner(cameraError ?: "")
                !locationGranted -> Banner(
                    if (loc.approxOnly) "Location permission denied." else "Location permission denied – photos can't be stamped with GPS data.",
                    action = if (askedBefore) "Settings" else "Allow",
                    onAction = { if (askedBefore) openAppSettings(ctx) else requestPerms() },
                )
                loc.status == GpsStatus.SERVICES_DISABLED -> Banner("Location services are turned off.", action = "Turn on", onAction = { openLocationSettings(ctx) })
                loc.warning != null -> Banner(loc.warning ?: "")
                loc.addressMessage != null && settings.stamp.showAddress -> Banner(loc.addressMessage ?: "")
            }
        }

        // ---------- bottom controls ----------
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 12.dp, start = 16.dp, end = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val cap = capture
            if (cap is CaptureUi.Waiting) {
                Row(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xCC000000)).padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = Amber, strokeWidth = 2.dp)
                    Text(
                        "Waiting for ±${cap.targetM} m (now ${cap.accuracyM?.let { Geo.accuracy(it, UnitSystem.METRIC) } ?: "no fix"})",
                        color = Color.White, style = MaterialTheme.typography.bodySmall,
                    )
                    TextButton(onClick = { vm.skipAccuracyWait() }) { Text("Capture now", color = Amber) }
                }
            }
            if (zoomMax > zoomMin + 0.01f) {
                Row(Modifier.fillMaxWidth(0.8f), verticalAlignment = Alignment.CenterVertically) {
                    Text(String.format("%.1fx", zoomRatio), color = Color.White, modifier = Modifier.padding(end = 8.dp), style = MaterialTheme.typography.labelLarge)
                    Slider(value = zoomRatio, onValueChange = { zoomRatio = it }, valueRange = zoomMin..minOf(zoomMax, 10f))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.location.refresh() }, modifier = Modifier.size(56.dp)) {
                    Icon(
                        when (loc.status) {
                            GpsStatus.HIGH_ACCURACY, GpsStatus.ACQUIRED -> Icons.Outlined.GpsFixed
                            GpsStatus.ACQUIRING -> Icons.Outlined.GpsNotFixed
                            else -> Icons.Outlined.GpsOff
                        }, "Refresh location", tint = Color.White,
                    )
                }
                ShutterButton(busy = capture !is CaptureUi.Idle, enabled = imageCapture != null && cameraError == null) {
                    imageCapture?.let { vm.capture(it) }
                }
                TextButton(
                    onClick = { vm.update { it.copy(requireAccurate = !it.requireAccurate) } },
                    modifier = Modifier.size(width = 56.dp, height = 56.dp),
                ) {
                    Text(
                        if (settings.requireAccurate) "±${settings.accuracyThreshold}m\nwait" else "wait\noff",
                        color = if (settings.requireAccurate) Amber else Color.White, style = MaterialTheme.typography.labelSmall,
                    )
                }
            }
        }
    }
}

@Composable
private fun ShutterButton(busy: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.86f else 1f, label = "shutter")
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(84.dp).scale(s)) {
        Box(
            Modifier.size(84.dp).border(4.dp, Color.White, CircleShape).padding(8.dp).clip(CircleShape)
                .background(if (busy || !enabled) Color(0xFF8A9A98) else Color.White)
                .clickable(interactionSource = interaction, indication = null, enabled = enabled && !busy, onClick = onClick),
        )
        if (busy) CircularProgressIndicator(Modifier.size(36.dp), color = Color(0xFF0F766E), strokeWidth = 3.dp)
    }
}

@Composable
fun GpsChip(status: GpsStatus, accuracyM: Float?, ageMs: Long) {
    val color = when (status) {
        GpsStatus.HIGH_ACCURACY -> Color(0xFF22C55E)
        GpsStatus.ACQUIRED -> Color(0xFF84CC16)
        GpsStatus.LOW_ACCURACY, GpsStatus.STALE -> Amber
        GpsStatus.ACQUIRING -> Color(0xFF60A5FA)
        else -> Color(0xFFEF4444)
    }
    val text = buildString {
        append(status.label)
        if (accuracyM != null && status != GpsStatus.PERMISSION_DENIED && status != GpsStatus.SERVICES_DISABLED) {
            append(" · ").append(Geo.accuracy(accuracyM, UnitSystem.METRIC))
        }
        if (status == GpsStatus.STALE) append(" · ").append(Geo.ageText(ageMs)).append(" old")
    }
    Row(
        Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (status == GpsStatus.ACQUIRING) CircularProgressIndicator(Modifier.size(12.dp), color = color, strokeWidth = 2.dp)
        else Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Text(text, color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}
