package com.ttk.gpscam.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.ttk.gpscam.MainViewModel
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.data.AppSettings
import com.ttk.gpscam.data.StampConfig
import com.ttk.gpscam.data.StampData
import com.ttk.gpscam.data.Templates
import com.ttk.gpscam.stamp.PhotoItem
import com.ttk.gpscam.stamp.PhotoMeta
import com.ttk.gpscam.stamp.PhotoProcessor
import com.ttk.gpscam.stamp.PhotoStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

fun shareUri(ctx: Context, uri: Uri) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Share photo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}


/** Deletes [uris]; returns true when all were deleted directly, or launches one consent dialog for the rest. */
private fun deleteMany(ctx: Context, uris: List<Uri>, launch: (IntentSenderRequest) -> Unit): Boolean {
    val rest = ArrayList<Uri>()
    for (u in uris) {
        when (PhotoStore.delete(ctx, u)) {
            is PhotoStore.DeleteResult.Done -> {}
            is PhotoStore.DeleteResult.NeedsConsent -> rest += u
            is PhotoStore.DeleteResult.Failed -> rest += u
        }
    }
    if (rest.isEmpty()) return true
    if (android.os.Build.VERSION.SDK_INT >= 30) {
        runCatching {
            val pi = android.provider.MediaStore.createDeleteRequest(ctx.contentResolver, rest)
            launch(IntentSenderRequest.Builder(pi.intentSender).build())
        }
    }
    return false
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(vm: MainViewModel, settings: AppSettings) {
    val ctx = LocalContext.current
    val version by vm.galleryVersion.collectAsState()
    var items by remember { mutableStateOf<List<PhotoItem>?>(null) }
    var openIndex by rememberSaveable { mutableIntStateOf(-1) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var confirm by remember { mutableStateOf(false) }

    LaunchedEffect(version) { items = withContext(Dispatchers.IO) { PhotoStore.list(ctx) } }
    LaunchedEffect(openIndex >= 0) { vm.viewerOpen.value = openIndex >= 0 }
    DisposableEffect(Unit) { onDispose { vm.viewerOpen.value = false } }
    val selecting = selected.isNotEmpty()
    BackHandler(enabled = openIndex >= 0 || selecting) { if (openIndex >= 0) openIndex = -1 else selected = emptySet() }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        items?.filter { it.id in selected }?.forEach { PhotoStore.deleteMeta(ctx, it.name) }
        selected = emptySet(); vm.galleryChanged()
    }

    val list = items
    if (openIndex >= 0 && list != null && list.isNotEmpty()) {
        PhotoViewer(vm, settings, list, openIndex.coerceAtMost(list.size - 1), onClose = { openIndex = -1 })
        return
    }
    if (openIndex >= 0) openIndex = -1

    Column(Modifier.fillMaxSize().background(Color(0xFF101312)).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selecting) {
                IconButton(onClick = { selected = emptySet() }) { Icon(Icons.Outlined.Close, "Cancel", tint = Color.White) }
                Text("${selected.size} selected", color = Color.White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { list?.let { l -> selected = if (selected.size == l.size) emptySet() else l.map { it.id }.toSet() } }) {
                    Icon(Icons.Outlined.SelectAll, "Select all", tint = Color.White)
                }
                IconButton(onClick = { confirm = true }) { Icon(Icons.Outlined.Delete, "Delete", tint = Color.White) }
            } else {
                Text("Gallery", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp).weight(1f))
                if (!list.isNullOrEmpty()) Text("${list.size} photos", color = Color(0xFF9AA5A3), modifier = Modifier.padding(end = 8.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.PhotoLibrary, null, Modifier.padding(bottom = 12.dp), tint = Color(0xFF9AA5A3))
                Text("No photos yet", color = Color.White, style = MaterialTheme.typography.titleMedium)
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                items(list.size, key = { list[it].id }) { idx ->
                    val it0 = list[idx]
                    val isSel = it0.id in selected
                    Box(
                        Modifier.aspectRatio(1f).combinedClickable(
                            onClick = {
                                if (selecting) selected = if (isSel) selected - it0.id else selected + it0.id
                                else openIndex = idx
                            },
                            onLongClick = { selected = if (isSel) selected - it0.id else selected + it0.id },
                        ),
                    ) {
                        Thumb(it0, Modifier.fillMaxSize())
                        if (isSel) Box(Modifier.fillMaxSize().background(Color(0x66000000)))
                        if (selecting) Icon(
                            if (isSel) Icons.Outlined.CheckCircle else Icons.Outlined.RadioButtonUnchecked, null,
                            tint = if (isSel) Color(0xFF01B880) else Color.White,
                            modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                        )
                    }
                }
            }
        }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Delete ${selected.size} photo${if (selected.size == 1) "" else "s"}?") },
        text = { Text("They will be permanently removed from your phone.") },
        confirmButton = {
            TextButton(onClick = {
                confirm = false
                val sel = list?.filter { it.id in selected } ?: emptyList()
                val done = deleteMany(ctx, sel.map { it.uri }) { consent.launch(it) }
                if (done) { sel.forEach { PhotoStore.deleteMeta(ctx, it.name) }; selected = emptySet(); vm.galleryChanged() }
            }) { Text("Delete", color = Color(0xFFEF4444)) }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
    )
}

@Composable
private fun Thumb(item: PhotoItem, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, item.uri) {
        value = withContext(Dispatchers.IO) {
            runCatching { ctx.contentResolver.loadThumbnail(item.uri, Size(320, 320), null).asImageBitmap() }.getOrNull()
        }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant)) {
        bmp?.let { Image(it, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
private fun ZoomableImage(uri: Uri, active: Boolean, onZoomed: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            PhotoStore.decodeOriented({ ctx.contentResolver.openInputStream(uri) }, 6_000_000L)?.asImageBitmap()
        }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    LaunchedEffect(scale) { onZoomed(scale > 1.01f) }
    LaunchedEffect(active) { if (!active) { scale = 1f; offset = Offset.Zero } }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = size.width * (s - 1f) / 2f
        val my = size.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    Box(
        Modifier.fillMaxSize().onSizeChanged { size = it }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1.01f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        if (ev.changes.size >= 2 || scale > 1.01f) {
                            val ns = (scale * zoom).coerceIn(1f, 6f)
                            scale = ns
                            offset = if (ns <= 1.01f) Offset.Zero else clamp(offset + pan, ns)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b == null) CircularProgressIndicator(color = Color.White)
        else Image(
            b, null, Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y),
            contentScale = ContentScale.Fit,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PhotoViewer(vm: MainViewModel, settings: AppSettings, items: List<PhotoItem>, start: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = start) { items.size }
    val item = items[pager.currentPage.coerceIn(0, items.size - 1)]
    var zoomed by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var chrome by remember { mutableStateOf(true) }

    val meta by produceState<PhotoMeta?>(null, item.name) {
        value = withContext(Dispatchers.IO) { PhotoStore.loadMeta(ctx, item.name) }
    }
    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) { PhotoStore.deleteMeta(ctx, item.name); vm.galleryChanged() }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, userScrollEnabled = !zoomed, modifier = Modifier.fillMaxSize().clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { chrome = !chrome }) { page ->
            val isCur = page == pager.currentPage
            ZoomableImage(items[page].uri, isCur) { z -> if (isCur) zoomed = z }
        }
        if (chrome) {
            Row(
                Modifier.fillMaxWidth().background(Color(0x88000000)).statusBarsPadding().padding(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = Color.White) }
                Text("${pager.currentPage + 1} / ${items.size}", color = Color.White, modifier = Modifier.weight(1f))
                IconButton(onClick = { showInfo = true }) { Icon(Icons.Outlined.Info, "Info", tint = Color.White) }
            }
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x99000000)).navigationBarsPadding(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                IconButton(onClick = { shareUri(ctx, item.uri) }) { Icon(Icons.Outlined.Share, "Share", tint = Color.White) }
                IconButton(onClick = { showDelete = true }) { Icon(Icons.Outlined.Delete, "Delete", tint = Color.White) }
            }
        }
    }

    if (showInfo) {
        val data: StampData? = meta?.data ?: remember(item.id) { PhotoStore.metaFromExif(ctx, item.uri) }
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text("Photo information") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("File: ${item.name}")
                    Text("Size: ${item.width} × ${item.height} px, ${Formatter.formatFileSize(ctx, item.size)}")
                    Text("Saved: ${DateFormat.getDateTimeInstance().format(Date(item.dateMs))}")
                    val lat = data?.lat
                    val lon = data?.lon
                    if (data == null || lat == null || lon == null) Text("No GPS data stored for this photo.")
                    else {
                        val f = settings.stamp.coordFormat
                        Text("Latitude: ${Geo.coordinate(lat, true, f)}")
                        Text("Longitude: ${Geo.coordinate(lon, false, f)}")
                        data.address?.line?.let { Text("Address: $it") }
                        data.accuracyM?.let { Text("Accuracy: ${Geo.accuracy(it, settings.stamp.units)} (${Geo.accuracyLevel(it).label})") }
                        data.altitudeM?.let { Text("Altitude: ${Geo.distance(it, settings.stamp.units)}") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Close") } },
            dismissButton = {
                val d = meta?.data
                if (d?.lat != null && d.lon != null) TextButton(onClick = { copyText(ctx, Geo.plainLatLon(d.lat, d.lon)); vm.toast("Coordinates copied") }) { Text("Copy coordinates") }
            },
        )
    }

    if (showDelete) AlertDialog(
        onDismissRequest = { showDelete = false },
        title = { Text("Delete photo?") },
        text = { Text("This permanently deletes the photo.") },
        confirmButton = {
            TextButton(onClick = {
                showDelete = false
                val done = deleteMany(ctx, listOf(item.uri)) { consent.launch(it) }
                if (done) { PhotoStore.deleteMeta(ctx, item.name); vm.galleryChanged(); if (items.size <= 1) onClose() }
            }) { Text("Delete", color = Color(0xFFEF4444)) }
        },
        dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } },
    )
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    cm.setPrimaryClip(android.content.ClipData.newPlainText("TTK GPS Cam", text))
}
