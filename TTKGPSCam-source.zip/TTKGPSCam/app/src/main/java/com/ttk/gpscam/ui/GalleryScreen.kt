package com.ttk.gpscam.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.ttk.gpscam.MainViewModel
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.data.AppSettings
import com.ttk.gpscam.data.StampConfig
import com.ttk.gpscam.data.StampData
import com.ttk.gpscam.data.Templates
import com.ttk.gpscam.stamp.PhotoItem
import com.ttk.gpscam.stamp.PhotoMeta
import com.ttk.gpscam.stamp.PhotoProcessor
import com.ttk.gpscam.stamp.PhotoStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

fun shareUri(ctx: Context, uri: Uri) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Share photo").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun GalleryScreen(vm: MainViewModel, settings: AppSettings) {
    val ctx = LocalContext.current
    val version by vm.galleryVersion.collectAsState()
    var items by remember { mutableStateOf<List<PhotoItem>?>(null) }
    var openIndex by rememberSaveable { mutableIntStateOf(-1) }

    LaunchedEffect(version) { items = withContext(Dispatchers.IO) { PhotoStore.list(ctx) } }
    LaunchedEffect(openIndex >= 0) { vm.viewerOpen.value = openIndex >= 0 }
    DisposableEffect(Unit) { onDispose { vm.viewerOpen.value = false } }
    BackHandler(enabled = openIndex >= 0) { openIndex = -1 }

    val list = items
    if (openIndex >= 0 && list != null && list.isNotEmpty()) {
        PhotoViewer(vm, settings, list, openIndex.coerceAtMost(list.size - 1), onClose = { openIndex = -1 })
        return
    }
    if (openIndex >= 0) openIndex = -1

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Gallery", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.PhotoLibrary, null, Modifier.padding(bottom = 12.dp), tint = MaterialTheme.colorScheme.outline)
                Text("No photos yet", style = MaterialTheme.typography.titleMedium)
                Text("Photos you take with TTK GPS Cam appear here (saved in Pictures/TTK GPS Cam).", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(110.dp), modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                items(list.size, key = { list[it].id }) { idx ->
                    Thumb(list[idx], Modifier.aspectRatio(1f).clip(MaterialTheme.shapes.small).clickable { openIndex = idx })
                }
            }
        }
    }
}

@Composable
private fun Thumb(item: PhotoItem, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, item.uri) {
        value = withContext(Dispatchers.IO) {
            runCatching { ctx.contentResolver.loadThumbnail(item.uri, Size(320, 320), null).asImageBitmap() }.getOrNull()
        }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant)) {
        bmp?.let { Image(it, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
private fun ZoomableImage(uri: Uri, active: Boolean, onZoomed: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            PhotoStore.decodeOriented({ ctx.contentResolver.openInputStream(uri) }, 6_000_000L)?.asImageBitmap()
        }
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    LaunchedEffect(scale) { onZoomed(scale > 1.01f) }
    LaunchedEffect(active) { if (!active) { scale = 1f; offset = Offset.Zero } }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = size.width * (s - 1f) / 2f
        val my = size.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    Box(
        Modifier.fillMaxSize().onSizeChanged { size = it }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1.01f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        if (ev.changes.size >= 2 || scale > 1.01f) {
                            val ns = (scale * zoom).coerceIn(1f, 6f)
                            scale = ns
                            offset = if (ns <= 1.01f) Offset.Zero else clamp(offset + pan, ns)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b == null) CircularProgressIndicator(color = Color.White)
        else Image(
            b, null, Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y),
            contentScale = ContentScale.Fit,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PhotoViewer(vm: MainViewModel, settings: AppSettings, items: List<PhotoItem>, start: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val logo by vm.logo.collectAsState()
    val pager = rememberPagerState(initialPage = start) { items.size }
    val item = items[pager.currentPage.coerceIn(0, items.size - 1)]
    var zoomed by remember { mutableStateOf(false) }
    var showOriginal by remember(item.id) { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var showRestamp by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var exportSource by remember { mutableStateOf<Uri?>(null) }

    val meta by produceState<PhotoMeta?>(null, item.name, vm.galleryVersion.collectAsState().value) {
        value = withContext(Dispatchers.IO) { PhotoStore.loadMeta(ctx, item.name) }
    }
    val original by produceState<PhotoItem?>(null, item.name, meta) {
        value = withContext(Dispatchers.IO) { PhotoStore.findOriginal(ctx, meta?.originalName) }
    }
    val displayUri = if (showOriginal && original != null) original!!.uri else item.uri

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { dest ->
        val src = exportSource
        if (dest != null && src != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        ctx.contentResolver.openInputStream(src)!!.use { i -> ctx.contentResolver.openOutputStream(dest)!!.use { o -> i.copyTo(o) } }
                    }.isSuccess
                }
                vm.toast(if (ok) "Exported" else "Export failed")
            }
        }
    }
    var pendingDelete by remember { mutableStateOf(false) }
    val consentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) { PhotoStore.deleteMeta(ctx, item.name); vm.galleryChanged() }
        pendingDelete = false
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, userScrollEnabled = !zoomed, modifier = Modifier.fillMaxSize()) { page ->
            val isCur = page == pager.currentPage
            ZoomableImage(if (isCur) displayUri else items[page].uri, isCur) { z -> if (isCur) zoomed = z }
        }
        Row(
            Modifier.fillMaxWidth().background(Color(0x88000000)).statusBarsPadding().padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = Color.White) }
            Text(
                (if (showOriginal && original != null) "Original · " else "") + item.name, color = Color.White,
                style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f),
            )
            Text("${pager.currentPage + 1}/${items.size}", color = Color.White, modifier = Modifier.padding(end = 12.dp))
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x99000000)).navigationBarsPadding()) {
            if (original != null) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Show original (no stamp)", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(checked = showOriginal, onCheckedChange = { showOriginal = it })
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton(onClick = { shareUri(ctx, displayUri) }) { Icon(Icons.Outlined.Share, "Share", tint = Color.White) }
                IconButton(onClick = { exportSource = displayUri; exportLauncher.launch(if (showOriginal) "orig_${item.name}" else item.name) }) {
                    Icon(Icons.Outlined.FileDownload, "Export", tint = Color.White)
                }
                IconButton(onClick = { showInfo = true }) { Icon(Icons.Outlined.Info, "Info", tint = Color.White) }
                IconButton(onClick = { showRestamp = true }) { Icon(Icons.Outlined.AutoFixHigh, "Re-stamp", tint = Color.White) }
                IconButton(onClick = { showDelete = true }) { Icon(Icons.Outlined.Delete, "Delete", tint = Color.White) }
            }
        }
        if (busy) Box(Modifier.fillMaxSize().background(Color(0x88000000)), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }
    }

    if (showInfo) {
        val data: StampData? = meta?.data ?: remember(item.id) { PhotoStore.metaFromExif(ctx, item.uri) }
        AlertDialog(
            onDismissRequest = { showInfo = false },
            title = { Text("Photo information") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("File: ${item.name}")
                    Text("Size: ${item.width} × ${item.height} px, ${Formatter.formatFileSize(ctx, item.size)}")
                    Text("Saved: ${DateFormat.getDateTimeInstance().format(Date(item.dateMs))}")
                    Text("Folder: Pictures/TTK GPS Cam")
                    Text("Original kept: ${if (original != null) "yes" else "no"}")
                    Text("GPS information", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                    val lat = data?.lat
                    val lon = data?.lon
                    if (data == null || lat == null || lon == null) Text("No GPS data stored for this photo.")
                    else {
                        val f = settings.stamp.coordFormat
                        Text("Latitude: ${Geo.coordinate(lat, true, f)}")
                        Text("Longitude: ${Geo.coordinate(lon, false, f)}")
                        data.address?.line?.let { Text("Address: $it") }
                        data.accuracyM?.let { Text("Accuracy: ${Geo.accuracy(it, settings.stamp.units)} (${Geo.accuracyLevel(it).label})") }
                        data.altitudeM?.let { Text("Altitude: ${Geo.distance(it, settings.stamp.units)}") }
                        data.speedMps?.let { Text("Speed: ${Geo.speed(it, settings.stamp.units)}") }
                        data.headingDeg?.let { Text("Direction: ${Geo.heading(it)}") }
                        Text("Captured: ${DateFormat.getDateTimeInstance().format(Date(data.captureTimeMs))} (${data.tzId})")
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Close") } },
            dismissButton = {
                val d = meta?.data
                if (d?.lat != null && d.lon != null) TextButton(onClick = { copyText(ctx, Geo.plainLatLon(d.lat, d.lon)); vm.toast("Coordinates copied") }) { Text("Copy coordinates") }
            },
        )
    }

    if (showDelete) {
        var alsoOriginal by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete photo?") },
            text = {
                Column {
                    Text("This permanently deletes ${item.name}.")
                    if (original != null) Row(Modifier.clickable { alsoOriginal = !alsoOriginal }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(alsoOriginal, { alsoOriginal = it }); Text("Also delete the original")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showDelete = false
                    when (val r = PhotoStore.delete(ctx, item.uri)) {
                        is PhotoStore.DeleteResult.Done -> {
                            if (alsoOriginal) original?.let { PhotoStore.delete(ctx, it.uri) }
                            PhotoStore.deleteMeta(ctx, item.name); vm.galleryChanged()
                            if (items.size <= 1) onClose()
                        }
                        is PhotoStore.DeleteResult.NeedsConsent -> { pendingDelete = true; consentLauncher.launch(IntentSenderRequest.Builder(r.sender).build()) }
                        is PhotoStore.DeleteResult.Failed -> vm.toast(r.message)
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { showDelete = false }) { Text("Cancel") } },
        )
    }

    if (showRestamp) {
        val orig = original
        var choice by remember { mutableStateOf("current") }
        AlertDialog(
            onDismissRequest = { showRestamp = false },
            title = { Text("Create new stamped copy") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (orig == null) Text("The unstamped original of this photo is not available, so it cannot be re-stamped without stamping twice.")
                    else {
                        Text("A new photo is created from the original. Nothing is overwritten.", style = MaterialTheme.typography.bodySmall)
                        val opts = listOf("current" to "Current dashboard settings") +
                            Templates.builtIn.filter { it.id != Templates.CUSTOM_ID }.map { it.id to it.name } +
                            settings.customTemplates.map { it.id to "★ ${it.name}" }
                        opts.forEach { (id, label) ->
                            Row(Modifier.fillMaxWidth().clickable { choice = id }, verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(choice == id, { choice = id }); Text(label)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = orig != null, onClick = {
                    showRestamp = false
                    val o = orig ?: return@TextButton
                    val cfg: StampConfig = when {
                        choice == "current" -> settings.stamp
                        else -> settings.customTemplates.firstOrNull { it.id == choice }?.config
                            ?: Templates.apply(choice, settings.stamp)
                    }
                    scope.launch {
                        busy = true
                        try {
                            val data = meta?.data ?: PhotoStore.metaFromExif(ctx, o.uri) ?: throw java.io.IOException("No location data available for this photo.")
                            val r = PhotoProcessor.restamp(ctx, o.uri, o.name, data, cfg, logo, settings.jpegQuality)
                            vm.galleryChanged()
                            vm.toast("Created ${r.name}" + if (r.mapMissing) " (map omitted: offline)" else "")
                        } catch (e: Throwable) {
                            vm.toast(e.message ?: "Could not create the copy")
                        } finally { busy = false }
                    }
                }) { Text("Create copy") }
            },
            dismissButton = { TextButton(onClick = { showRestamp = false }) { Text("Cancel") } },
        )
    }
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    cm.setPrimaryClip(android.content.ClipData.newPlainText("TTK GPS Cam", text))
}
