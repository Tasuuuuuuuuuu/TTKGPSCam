package com.ttk.gpscam.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ttk.gpscam.core.TileMath
import com.ttk.gpscam.data.MapStyle
import com.ttk.gpscam.map.TileStore
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

/** Pan/zoom OpenStreetMap view drawn from cached/downloaded tiles. Marker = real current fix. */
@Composable
fun LiveMap(
    lat: Double?, lon: Double?, accuracyM: Float?, style: MapStyle,
    zoom: Int, onZoom: (Int) -> Unit, recenterTick: Int, modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val k = LocalDensity.current.density.coerceAtLeast(1f)
    var size by remember { mutableStateOf(IntSize.Zero) }
    var cLat by remember { mutableDoubleStateOf(lat ?: 0.0) }
    var cLon by remember { mutableDoubleStateOf(lon ?: 0.0) }
    var follow by remember { mutableStateOf(true) }
    var pinch by remember { mutableFloatStateOf(1f) }
    val z = zoom.coerceIn(3, style.maxZoom)
    val tiles = remember(style) { mutableStateMapOf<String, ImageBitmap>() }

    LaunchedEffect(recenterTick) { follow = true; if (lat != null && lon != null) { cLat = lat; cLon = lon } }
    LaunchedEffect(lat, lon) { if (follow && lat != null && lon != null) { cLat = lat; cLon = lon } }

    val tileSize = TileMath.TILE * k
    val cx = TileMath.worldX(cLon, z)
    val cy = TileMath.worldY(cLat, z)
    val halfW = size.width / 2.0 / k
    val halfH = size.height / 2.0 / k
    val tx0 = floor((cx - halfW) / 256.0).toInt()
    val tx1 = floor((cx + halfW) / 256.0).toInt()
    val ty0 = floor((cy - halfH) / 256.0).toInt()
    val ty1 = floor((cy + halfH) / 256.0).toInt()
    val n = 1 shl z

    LaunchedEffect(z, style, tx0, tx1, ty0, ty1, size) {
        if (size.width == 0) return@LaunchedEffect
        for (ty in ty0..ty1) for (tx in tx0..tx1) {
            if (ty < 0 || ty >= n) continue
            val wx = ((tx % n) + n) % n
            val key = "$z/$wx/$ty"
            if (tiles.containsKey(key)) continue
            TileStore.get(ctx, style, z, wx, ty, true)?.let { tiles[key] = it.asImageBitmap() }
        }
    }

    Box(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFFDDE0E4)).onSizeChanged { size = it }
            .pointerInput(z, style) {
                detectTransformGestures { _, pan, zm, _ ->
                    if (pan != Offset.Zero) {
                        follow = false
                        val nx = TileMath.worldX(cLon, z) - pan.x / k
                        val ny = TileMath.worldY(cLat, z) - pan.y / k
                        cLon = TileMath.lonFromX(nx, z).coerceIn(-180.0, 180.0)
                        cLat = TileMath.latFromY(ny, z).coerceIn(-85.0, 85.0)
                    }
                    pinch *= zm
                    if (pinch > 1.7f) { pinch = 1f; onZoom((z + 1).coerceAtMost(style.maxZoom)) }
                    else if (pinch < 0.6f) { pinch = 1f; onZoom((z - 1).coerceAtLeast(3)) }
                }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val ox = size.width / 2f
            val oy = size.height / 2f
            val dst = IntSize(ceil(tileSize).toInt() + 1, ceil(tileSize).toInt() + 1)
            for (ty in ty0..ty1) for (tx in tx0..tx1) {
                if (ty < 0 || ty >= n) continue
                val wx = ((tx % n) + n) % n
                val img = tiles["$z/$wx/$ty"] ?: continue
                val x = ox + ((tx * 256.0 - cx) * k).toFloat()
                val y = oy + ((ty * 256.0 - cy) * k).toFloat()
                drawImage(img, dstOffset = IntOffset(x.roundToInt(), y.roundToInt()), dstSize = dst)
            }
            if (lat != null && lon != null) {
                val px = ox + ((TileMath.worldX(lon, z) - cx) * k).toFloat()
                val py = oy + ((TileMath.worldY(lat, z) - cy) * k).toFloat()
                if (accuracyM != null) {
                    val r = (accuracyM / TileMath.metersPerPixel(lat, z)).toFloat() * k
                    if (r > 8f) {
                        drawCircle(Color(0x331976D2), r, Offset(px, py))
                        drawCircle(Color(0xAA1976D2), r, Offset(px, py), style = Stroke(2f))
                    }
                }
                drawCircle(Color.White, 11.dp.toPx(), Offset(px, py))
                drawCircle(Color(0xFF1976D2), 8.dp.toPx(), Offset(px, py))
            }
        }
        Text(
            style.attribution, fontSize = 10.sp, color = Color(0xFF222222),
            modifier = Modifier.align(Alignment.BottomEnd).background(Color(0xCCFFFFFF)).padding(horizontal = 4.dp, vertical = 1.dp),
            style = MaterialTheme.typography.labelSmall,
        )
    }
}
