package com.ttk.gpscam.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ttk.gpscam.MainViewModel
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.data.AppSettings
import com.ttk.gpscam.data.MapStyle
import com.ttk.gpscam.location.GpsStatus
import java.text.DateFormat
import java.util.Date

@Composable
fun LocationScreen(vm: MainViewModel, settings: AppSettings) {
    val ctx = LocalContext.current
    val perms = rememberPerms(vm)
    LocationEffect(vm)
    val st by vm.location.state.collectAsState()
    var zoom by remember { mutableIntStateOf(16) }
    var tick by remember { mutableIntStateOf(0) }
    val fix = st.fix
    val c = settings.stamp

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Location", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            GpsChip(st.status, fix?.accuracyM, st.ageMs)
        }
        if (!perms.location) Banner("Location permission is required.", action = if (perms.askedBefore) "Settings" else "Allow",
            onAction = { if (perms.askedBefore) openAppSettings(ctx) else perms.request() })
        else if (st.status == GpsStatus.SERVICES_DISABLED) Banner("Location services are turned off.", action = "Turn on", onAction = { openLocationSettings(ctx) })
        else st.warning?.let { Banner(it) }

        Box(Modifier.fillMaxWidth().height(320.dp)) {
            LiveMap(fix?.lat, fix?.lon, fix?.accuracyM, settings.liveMapStyle, zoom, { zoom = it }, tick, Modifier.fillMaxSize())
            Column(Modifier.align(Alignment.CenterEnd).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FilledTonalIconButton(onClick = { zoom = (zoom + 1).coerceAtMost(settings.liveMapStyle.maxZoom) }) { Icon(Icons.Outlined.Add, "Zoom in") }
                FilledTonalIconButton(onClick = { zoom = (zoom - 1).coerceAtLeast(3) }) { Icon(Icons.Outlined.Remove, "Zoom out") }
                FilledTonalIconButton(onClick = { tick++ }) { Icon(Icons.Outlined.MyLocation, "Center map") }
            }
            if (fix == null) Text(
                if (st.status == GpsStatus.ACQUIRING) "Acquiring GPS…" else "No location yet",
                Modifier.align(Alignment.Center).padding(8.dp), color = MaterialTheme.colorScheme.onSurface,
            )
        }

        ChoiceRow("Map style", MapStyle.entries, settings.liveMapStyle, { it.label }) { s -> vm.update { it.copy(liveMapStyle = s) } }

        SectionCard("Current position") {
            if (fix == null) Text("No GPS fix yet. Nothing is shown until Android reports a real location.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            else {
                Info("Latitude", Geo.coordinate(fix.lat, true, c.coordFormat))
                Info("Longitude", Geo.coordinate(fix.lon, false, c.coordFormat))
                Info("Address", st.address?.line ?: (st.addressMessage ?: "Looking up address…"))
                Info("Accuracy", fix.accuracyM?.let { "${Geo.accuracy(it, c.units)} (${Geo.accuracyLevel(it).label})" } ?: "not reported")
                Info("Altitude", fix.altitudeM?.let { Geo.distance(it, c.units) } ?: "not reported")
                Info("Speed", fix.speedMps?.let { Geo.speed(it, c.units) } ?: "not reported")
                Info("Direction", st.heading?.let { Geo.heading(it) } ?: "not available")
                Info("Fix time", DateFormat.getDateTimeInstance().format(Date(fix.fixTimeMs)) + if (st.isStale) " (cached)" else "")
                Info("Now", DateFormat.getDateTimeInstance().format(Date(System.currentTimeMillis())))
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.location.refresh() }, Modifier.weight(1f)) { Icon(Icons.Outlined.Refresh, null); Text(" Refresh") }
            OutlinedButton(enabled = fix != null, onClick = { fix?.let { copyText(ctx, Geo.plainLatLon(it.lat, it.lon)); vm.toast("Coordinates copied") } }, Modifier.weight(1f)) {
                Icon(Icons.Outlined.ContentCopy, null); Text(" Copy")
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = fix != null, modifier = Modifier.weight(1f), onClick = {
                fix?.let {
                    val txt = "My location: ${Geo.plainLatLon(it.lat, it.lon)}\nhttps://www.openstreetmap.org/?mlat=${it.lat}&mlon=${it.lon}#map=17/${it.lat}/${it.lon}"
                    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, txt) }
                    ctx.startActivity(Intent.createChooser(i, "Share location").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }) { Icon(Icons.Outlined.Share, null); Text(" Share") }
            OutlinedButton(enabled = fix != null, modifier = Modifier.weight(1f), onClick = {
                fix?.let {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:${it.lat},${it.lon}?q=${it.lat},${it.lon}(My location)"))
                    try { ctx.startActivity(Intent.createChooser(i, "Open in maps").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    catch (e: Exception) { vm.toast("No maps app found") }
                }
            }) { Icon(Icons.Outlined.OpenInNew, null); Text(" Open in maps") }
        }
        Text("Your location is only shared when you tap Share.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Info(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.35f))
        Text(value, modifier = Modifier.weight(0.65f), fontWeight = FontWeight.Medium)
    }
}
