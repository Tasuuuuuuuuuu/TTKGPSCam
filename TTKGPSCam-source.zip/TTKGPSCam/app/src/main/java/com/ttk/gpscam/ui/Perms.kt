package com.ttk.gpscam.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ttk.gpscam.MainViewModel

class Perms(val camera: Boolean, val fine: Boolean, val coarse: Boolean, val askedBefore: Boolean, val request: () -> Unit) {
    val location: Boolean get() = fine || coarse
}

private fun has(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun rememberPerms(vm: MainViewModel): Perms {
    val ctx = LocalContext.current
    fun read() = Triple(has(ctx, Manifest.permission.CAMERA), has(ctx, Manifest.permission.ACCESS_FINE_LOCATION), has(ctx, Manifest.permission.ACCESS_COARSE_LOCATION))
    var state by remember { mutableStateOf(read()) }
    var asked by rememberSaveable { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        state = read(); asked = true; vm.location.onPermissionChanged()
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                val n = read()
                if (n != state) { state = n; vm.location.onPermissionChanged() }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return Perms(state.first, state.second, state.third, asked) {
        launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
}

fun openAppSettings(ctx: Context) {
    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun openLocationSettings(ctx: Context) {
    ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** Keeps location updates running only while the screen is visible (started). */
@Composable
fun LocationEffect(vm: MainViewModel) {
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        var held = false
        fun hold() { if (!held) { held = true; vm.location.acquire() } }
        fun drop() { if (held) { held = false; vm.location.release() } }
        if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) hold()
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_START -> hold()
                Lifecycle.Event.ON_STOP -> drop()
                else -> {}
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); drop() }
    }
}
