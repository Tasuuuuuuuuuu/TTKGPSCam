package com.ttk.gpscam.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ttk.gpscam.MainViewModel
import com.ttk.gpscam.core.Geo
import com.ttk.gpscam.data.*
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel, settings: AppSettings, openEditor: () -> Unit) {
    LocationEffect(vm)
    val st by vm.location.state.collectAsState()
    val c = settings.stamp
    var dialog by remember { mutableStateOf<String?>(null) }
    fun u(f: (StampConfig) -> StampConfig) = vm.updateStamp(f)
    var custom by remember { mutableStateOf(settings.accuracyThreshold.toString()) }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))

        SectionCard("Camera") {
            ChoiceRow("Default camera", listOf(false, true), settings.frontCamera, { if (it) "Front" else "Rear" }) { v -> vm.update { it.copy(frontCamera = v) } }
            ChoiceRow("Flash", FlashPref.entries, settings.flash, { it.label }) { v -> vm.update { it.copy(flash = v) } }
            ChoiceRow("Resolution (where supported)", ResPref.entries, settings.resolution, { it.label }) { v -> vm.update { it.copy(resolution = v) } }
            ChoiceRow("Aspect ratio", AspectPref.entries, settings.aspect, { it.label }) { v -> vm.update { it.copy(aspect = v) } }
            SliderRow("Default zoom", settings.defaultZoom, 1f..5f, String.format("%.1fx", settings.defaultZoom), { v -> vm.update { it.copy(defaultZoom = v) } })
        }

        SectionCard("GPS") {
            Text(
                "Now: ${st.status.label}" + (st.fix?.accuracyM?.let { " · ${Geo.accuracy(it, c.units)} (${Geo.accuracyLevel(it).label})" } ?: ""),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(onClick = { vm.location.refresh() }) { Text("Refresh location") }
            SwitchRow(
                "Require accurate location before capture", settings.requireAccurate, { v -> vm.update { it.copy(requireAccurate = v) } },
                "Waits up to 25 s. If the target is not reached the photo is still taken and the real accuracy is stamped.",
            )
            ChoiceRow("Accuracy threshold", listOf(10, 20, 50), settings.accuracyThreshold, { "$it m" }) { v ->
                vm.update { it.copy(accuracyThreshold = v) }; custom = v.toString()
            }
            TextRow("Custom threshold (meters, 3–500)", custom, { t ->
                custom = t.filter { ch -> ch.isDigit() }.take(3)
                custom.toIntOrNull()?.let { n -> if (n in 3..500) vm.update { it.copy(accuracyThreshold = n) } }
            }, number = true)
            ChoiceRow("Coordinate format", com.ttk.gpscam.core.CoordFormat.entries, c.coordFormat, { it.label }) { v -> u { it.copy(coordFormat = v) } }
            ChoiceRow("Units", com.ttk.gpscam.core.UnitSystem.entries, c.units, { it.label }) { v -> u { it.copy(units = v) } }
            SwitchRow("Show address", c.showAddress, { v -> u { it.copy(showAddress = v) } })
            SwitchRow("Show altitude", c.showAltitude, { v -> u { it.copy(showAltitude = v) } })
            SwitchRow("Show speed", c.showSpeed, { v -> u { it.copy(showSpeed = v) } })
            SwitchRow("Show compass", c.showCompass, { v -> u { it.copy(showCompass = v) } })
        }

        SectionCard("Dashboard") {
            ChoiceRow("Default template", Templates.builtIn, Templates.builtIn.firstOrNull { it.id == c.templateId }, { it?.name ?: "" }) { t ->
                if (t != null) vm.applyTemplate(t.id)
            }
            ChoiceRow("Position", StampPosition.entries, c.position, { it.label }) { v -> u { it.copy(position = v) } }
            TextRow("Company name", c.companyName, { v -> u { it.copy(companyName = v) } })
            SwitchRow("Show logo", c.logoOn, { v -> u { it.copy(logoOn = v) } })
            ChoiceRow("Font", FontFace.entries, c.fontFace, { it.label }) { v -> u { it.copy(fontFace = v) } }
            SliderRow("Background opacity", c.bgOpacity, 0f..1f, "${(c.bgOpacity * 100).roundToInt()}%", { v -> u { it.copy(bgOpacity = v) } })
            SliderRow("Card transparency", c.cardAlpha, 0.3f..1f, "${(c.cardAlpha * 100).roundToInt()}%", { v -> u { it.copy(cardAlpha = v) } })
            Button(onClick = openEditor) { Text("Open full template editor") }
        }
        StampFormatSection(vm, c)

        SectionCard("Map") {
            SwitchRow("Show map on photos", c.showMap, { v -> u { it.copy(showMap = v) } })
            ChoiceRow("Map style", MapStyle.entries, c.mapStyle, { it.label }) { v -> u { it.copy(mapStyle = v, mapZoom = minOf(it.mapZoom, v.maxZoom)) } }
            SliderRow("Map zoom", c.mapZoom.toFloat(), 8f..19f, c.mapZoom.toString(), { v -> u { it.copy(mapZoom = v.roundToInt()) } }, steps = 10)
        }

        SectionCard("Photos") {
            SliderRow("JPEG quality", settings.jpegQuality.toFloat(), 70f..100f, "${settings.jpegQuality}", { v -> vm.update { it.copy(jpegQuality = v.roundToInt()) } })
            SwitchRow("Keep unstamped original", settings.saveOriginal, { v -> vm.update { it.copy(saveOriginal = v) } }, "Saved to Pictures/TTK GPS Cam/Originals")
            SwitchRow("Stamp photos", settings.stampEnabled, { v -> vm.update { it.copy(stampEnabled = v) } })
        }

        SectionCard("App") {
            ChoiceRow("Theme", ThemeMode.entries, settings.theme, { it.label }) { v -> vm.update { it.copy(theme = v) } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { dialog = "privacy" }) { Text("Privacy") }
                OutlinedButton(onClick = { dialog = "about" }) { Text("About") }
                OutlinedButton(onClick = { dialog = "reset" }) { Text("Reset") }
            }
        }
    }

    when (dialog) {
        "privacy" -> InfoDialog("Privacy", PRIVACY_TEXT) { dialog = null }
        "about" -> InfoDialog("About TTK GPS Cam", ABOUT_TEXT) { dialog = null }
        "reset" -> AlertDialog(
            onDismissRequest = { dialog = null }, title = { Text("Reset all settings?") },
            text = { Text("Restores defaults and removes your logo and saved templates. Photos are not touched.") },
            confirmButton = { TextButton(onClick = { vm.resetAll(); dialog = null }) { Text("Reset") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun InfoDialog(title: String, body: String, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, title = { Text(title) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(body) } },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } },
    )
}

private const val PRIVACY_TEXT = """TTK GPS Cam has no ads, no analytics, no tracking, no account and no subscription.

Location: read from Android's location services only while the camera, location, templates or settings screens are visible. It is used to stamp your photos and show your position. It is never uploaded automatically. It leaves your phone only if you tap Share.

Address lookup: uses Android's built-in geocoder, which may contact your device's location service provider over the internet. If it is unavailable the app shows coordinates only.

Maps: map tiles are downloaded from OpenStreetMap-compatible tile servers (tile requests contain the tile numbers around your position and your IP address, like any web map). Tiles are cached on the device.

Photos, originals, logo, templates and settings are stored only on your device. Photos are saved in Pictures/TTK GPS Cam."""

private const val ABOUT_TEXT = """TTK GPS Cam 1.0.0
Package: com.ttk.gpscam

Free, open and fully unlocked. Maps © OpenStreetMap contributors (and HOT / OpenTopoMap when selected). Accuracy shown is the 68% confidence radius reported by Android; categories: Excellent ≤ 5 m, Good ≤ 15 m, Moderate ≤ 50 m, Poor > 50 m."""
