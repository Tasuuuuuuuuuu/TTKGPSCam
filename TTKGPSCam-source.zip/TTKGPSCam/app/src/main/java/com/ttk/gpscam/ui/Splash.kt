package com.ttk.gpscam.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sin

private const val SPLASH_SECONDS = 2.8f

/** ~2.8 s intro: two cats play with a yarn ball, then a speech bubble pops up. Tap to skip. */
@Composable
fun CatSplash(onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        t.animateTo(SPLASH_SECONDS, tween((SPLASH_SECONDS * 1000).toInt(), easing = LinearEasing))
        onDone()
    }
    val time = t.value
    val fade = if (time > SPLASH_SECONDS - 0.35f) ((SPLASH_SECONDS - time) / 0.35f).coerceIn(0f, 1f) else 1f
    Box(
        Modifier.fillMaxSize().alpha(fade)
            .background(Brush.verticalGradient(listOf(Color(0xFF0E2A24), Color(0xFF01B880))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDone() },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val unit = size.width / 8f
            val ground = size.height * 0.58f
            drawGround(ground)
            val beat = time * 2f * PI.toFloat() * 0.9f
            val a = Offset(cx - unit * 2.1f, ground)
            val b = Offset(cx + unit * 2.1f, ground)
            drawCat(a, unit, Color(0xFFFFA94D), Color(0xFFFFE3BF), false, beat, time)
            drawCat(b, unit, Color(0xFF9AA5B1), Color(0xFFE8ECF0), true, beat + PI.toFloat(), time)
            // yarn ball flies between the cats
            val p = (time * 0.9f) % 1f
            val tri = if (p < 0.5f) p * 2f else (1f - p) * 2f
            val bx = a.x + (b.x - a.x) * tri
            val by = ground - unit * 0.35f - sin(tri * PI.toFloat()) * unit * 0.2f - abs(sin(p * 2f * PI.toFloat())) * unit * 1.0f
            drawYarn(Offset(bx, by), unit * 0.42f, time * 6f)
        }
        // speech bubble
        val s = ((time - 1.0f) / 0.45f).coerceIn(0f, 1f)
        if (s > 0f) {
            val over = 1f + 1.70158f * (s - 1f).pow(3) + 0.70158f * (s - 1f).pow(2)
            Box(
                Modifier.align(Alignment.Center).padding(bottom = 300.dp)
                    .graphicsLayer { scaleX = over; scaleY = over; alpha = s.coerceAtMost(1f) },
                contentAlignment = Alignment.BottomCenter,
            ) {
                Canvas(Modifier.size(28.dp, 22.dp).align(Alignment.BottomCenter).graphicsLayer { translationY = 18.dp.toPx() }) {
                    val path = Path().apply { moveTo(0f, 0f); lineTo(size.width, 0f); lineTo(size.width * 0.35f, size.height); close() }
                    drawPath(path, Color.White)
                }
                Text(
                    "Created By Tasirul",
                    color = Color(0xFF0E2A24), fontWeight = FontWeight.ExtraBold, fontSize = 22.sp,
                    modifier = Modifier.background(Color.White, RoundedCornerShape(26.dp)).padding(horizontal = 24.dp, vertical = 14.dp),
                )
            }
        }
    }
}

private fun DrawScope.drawGround(y: Float) {
    drawOval(Color(0x33000000), Offset(size.width * 0.08f, y - 6f), Size(size.width * 0.84f, size.width * 0.09f))
}

private fun DrawScope.drawYarn(c: Offset, r: Float, spin: Float) {
    drawCircle(Color(0xFFFF6B9A), r, c)
    rotate(spin * 20f, c) {
        val st = Stroke(width = r * 0.14f, cap = StrokeCap.Round)
        drawArc(Color(0xFFFFC2D6), 20f, 120f, false, Offset(c.x - r * 0.75f, c.y - r * 0.75f), Size(r * 1.5f, r * 1.5f), style = st)
        drawArc(Color(0xFFFFC2D6), 200f, 110f, false, Offset(c.x - r * 0.45f, c.y - r * 0.45f), Size(r * 0.9f, r * 0.9f), style = st)
    }
}

private fun DrawScope.drawCat(base: Offset, u: Float, fur: Color, belly: Color, flip: Boolean, phase: Float, time: Float) {
    val dir = if (flip) -1f else 1f
    val hop = abs(sin(phase)) * u * 0.55f
    val squash = 1f + (0.06f * (1f - abs(sin(phase))))
    val y = base.y - hop
    // tail
    val tail = Path().apply {
        moveTo(base.x - dir * u * 0.75f, y - u * 0.5f)
        val w = sin(time * 9f) * u * 0.35f
        cubicTo(base.x - dir * u * 1.5f, y - u * 0.4f + w, base.x - dir * u * 1.5f, y - u * 1.5f, base.x - dir * u * 1.05f, y - u * 1.7f + w)
    }
    drawPath(tail, fur, style = Stroke(width = u * 0.3f, cap = StrokeCap.Round))
    // body
    drawOval(fur, Offset(base.x - u * 0.8f, y - u * 1.25f), Size(u * 1.6f, u * 1.25f * squash))
    drawOval(belly, Offset(base.x - u * 0.45f, y - u * 0.95f), Size(u * 0.9f, u * 0.85f))
    // paws
    drawCircle(fur, u * 0.22f, Offset(base.x - u * 0.4f, y - u * 0.02f))
    drawCircle(fur, u * 0.22f, Offset(base.x + u * 0.4f, y - u * 0.02f))
    // head (tilts while playing)
    val head = Offset(base.x, y - u * 1.65f)
    rotate(sin(phase) * 7f * dir, head) {
        // ears
        for (sx in listOf(-1f, 1f)) {
            val ear = Path().apply {
                moveTo(head.x + sx * u * 0.2f, head.y - u * 0.45f)
                lineTo(head.x + sx * u * 0.72f, head.y - u * 0.95f)
                lineTo(head.x + sx * u * 0.78f, head.y - u * 0.15f)
                close()
            }
            drawPath(ear, fur)
            val inner = Path().apply {
                moveTo(head.x + sx * u * 0.33f, head.y - u * 0.45f)
                lineTo(head.x + sx * u * 0.64f, head.y - u * 0.78f)
                lineTo(head.x + sx * u * 0.67f, head.y - u * 0.28f)
                close()
            }
            drawPath(inner, Color(0xFFFF9FB5))
        }
        drawCircle(fur, u * 0.82f, head)
        // cheeks
        drawCircle(Color(0x55FF6B9A), u * 0.16f, Offset(head.x - u * 0.5f, head.y + u * 0.2f))
        drawCircle(Color(0x55FF6B9A), u * 0.16f, Offset(head.x + u * 0.5f, head.y + u * 0.2f))
        // eyes (blink)
        val blink = if ((time * 1.7f) % 1f > 0.93f) 0.15f else 1f
        for (sx in listOf(-1f, 1f)) {
            val e = Offset(head.x + sx * u * 0.33f, head.y - u * 0.02f)
            drawOval(Color(0xFF222222), Offset(e.x - u * 0.12f, e.y - u * 0.16f * blink), Size(u * 0.24f, u * 0.32f * blink))
            if (blink > 0.5f) drawCircle(Color.White, u * 0.045f, Offset(e.x + u * 0.03f, e.y - u * 0.07f))
        }
        // nose + mouth
        drawCircle(Color(0xFFFF6B9A), u * 0.07f, Offset(head.x, head.y + u * 0.15f))
        val m = Path().apply {
            moveTo(head.x, head.y + u * 0.22f)
            quadraticBezierTo(head.x - u * 0.1f, head.y + u * 0.36f, head.x - u * 0.2f, head.y + u * 0.26f)
            moveTo(head.x, head.y + u * 0.22f)
            quadraticBezierTo(head.x + u * 0.1f, head.y + u * 0.36f, head.x + u * 0.2f, head.y + u * 0.26f)
        }
        drawPath(m, Color(0xFF222222), style = Stroke(width = u * 0.04f, cap = StrokeCap.Round))
        // whiskers
        for (sx in listOf(-1f, 1f)) for (k in -1..1) {
            drawLine(Color(0x99FFFFFF), Offset(head.x + sx * u * 0.55f, head.y + u * 0.2f + k * u * 0.06f),
                Offset(head.x + sx * u * 1.05f, head.y + u * 0.15f + k * u * 0.14f), u * 0.025f)
        }
    }
}
