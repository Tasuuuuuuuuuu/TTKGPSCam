package com.ttk.gpscam.ui

import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.widget.ImageView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.pow

private const val SPLASH_SECONDS = 3.0f

/**
 * Opening screen: the supplied animated GIF (assets/intro.gif) fills the screen, everything fades out after 3 seconds. Tap to skip.
 */
@Composable
fun IntroSplash(onDone: () -> Unit) {
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        t.animateTo(SPLASH_SECONDS, tween((SPLASH_SECONDS * 1000).toInt(), easing = LinearEasing))
        onDone()
    }
    val time = t.value
    val fade = if (time > SPLASH_SECONDS - 0.4f) ((SPLASH_SECONDS - time) / 0.4f).coerceIn(0f, 1f) else 1f
    var drawable: AnimatedImageDrawable? = null

    Box(
        Modifier.fillMaxSize().alpha(fade)
            .background(Brush.verticalGradient(listOf(Color(0xFF0F8A5F), Color(0xFF9BD65A))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDone() },
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                ImageView(ctx).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    runCatching {
                        val src = ImageDecoder.createSource(ctx.assets, "intro.gif")
                        val d = ImageDecoder.decodeDrawable(src)
                        setImageDrawable(d)
                        if (d is AnimatedImageDrawable) {
                            d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                            d.start()
                            drawable = d
                        }
                    }
                }
            },
        )
        DisposableEffect(Unit) { onDispose { drawable?.stop() } }

    }
}
