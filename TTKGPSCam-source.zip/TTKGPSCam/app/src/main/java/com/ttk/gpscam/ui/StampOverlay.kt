package com.ttk.gpscam.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import com.ttk.gpscam.data.StampConfig
import com.ttk.gpscam.location.LocState
import com.ttk.gpscam.map.MapRenderer
import com.ttk.gpscam.stamp.StampRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * Live preview of the exact stamp that will be burned into the photo, drawn with the same renderer
 * from the real current location (or an honest "GPS unavailable" card when there is no fix).
 */
@Composable
fun StampOverlay(cfg: StampConfig, st: LocState, logo: Bitmap?, modifier: Modifier = Modifier, onLogoTap: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    var size by remember { mutableStateOf(IntSize.Zero) }
    var mapBmp by remember { mutableStateOf<Bitmap?>(null) }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    var logoRect by remember { mutableStateOf<android.graphics.RectF?>(null) }

    val rw: Int
    val rh: Int
    if (size.width > 0 && size.height > 0) {
        val k = 720f / min(size.width, size.height)
        rw = (size.width * k).toInt().coerceAtLeast(1)
        rh = (size.height * k).toInt().coerceAtLeast(1)
    } else { rw = 0; rh = 0 }

    val fix = st.fix
    val latKey = fix?.lat?.let { (it * 1e5).roundToLong() }
    val lonKey = fix?.lon?.let { (it * 1e5).roundToLong() }
    val mapReq = if (rw > 0) StampRenderer.mapBoxSize(rw, rh, cfg) else null

    LaunchedEffect(latKey, lonKey, mapReq, cfg.mapZoom, cfg.mapStyle) {
        val f = fix
        mapBmp = if (mapReq == null || f == null) null
        else MapRenderer.render(ctx, cfg.mapStyle, f.lat, f.lon, cfg.mapZoom, mapReq.first, mapReq.second, true, f.accuracyM)
    }

    val now = System.currentTimeMillis()
    val bucket = if (cfg.showSeconds) 1000L else 60_000L
    val data = st.toStampData(now / bucket * bucket).let { it.copy(fixAgeMs = it.fixAgeMs?.let { a -> a / 10_000L * 10_000L }) }

    LaunchedEffect(cfg, data, mapBmp, logo, rw, rh) {
        if (rw <= 0) return@LaunchedEffect
        val hit = StampRenderer.StampHit()
        image = withContext(Dispatchers.Default) {
            val bmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
            StampRenderer.draw(Canvas(bmp), rw, rh, cfg, data, mapBmp, logo, placeholder = onLogoTap != null, hit = hit)
            bmp.asImageBitmap()
        }
        logoRect = hit.logo
    }

    Box(modifier.onSizeChanged { size = it }) {
        image?.let { Image(it, contentDescription = "Stamp preview", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds) }
        val lr = logoRect
        if (onLogoTap != null && lr != null && rw > 0 && size.width > 0) {
            val sx = size.width.toFloat() / rw
            val sy = size.height.toFloat() / rh
            val d = androidx.compose.ui.platform.LocalDensity.current
            Box(
                Modifier
                    .offset(with(d) { (lr.left * sx).toDp() }, with(d) { (lr.top * sy).toDp() })
                    .size(with(d) { (lr.width() * sx).toDp() }, with(d) { (lr.height() * sy).toDp() })
                    .clickable { onLogoTap() },
            )
        }
    }
}
