package com.ttk.gpscam.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import com.ttk.gpscam.data.StampConfig
import com.ttk.gpscam.location.LocState
import com.ttk.gpscam.map.MapRenderer
import com.ttk.gpscam.stamp.StampRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * Live preview of the exact stamp that will be burned into the photo, drawn with the same renderer
 * from the real current location (or an honest "GPS unavailable" card when there is no fix).
 */
@Composable
fun StampOverlay(
    cfg: StampConfig, st: LocState, logo: Bitmap?, modifier: Modifier = Modifier, onLogoTap: (() -> Unit)? = null,
    angle: Float = 0f, landscape: Boolean = false,
) {
    val ctx = LocalContext.current
    var size by remember { mutableStateOf(IntSize.Zero) }
    var mapBmp by remember { mutableStateOf<Bitmap?>(null) }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    var logoRect by remember { mutableStateOf<android.graphics.RectF?>(null) }

    val rw: Int
    val rh: Int
    // The stamp is laid out in the frame the saved photo will have: portrait, or landscape when the phone is on its side.
    val bw = if (landscape) size.height else size.width
    val bh = if (landscape) size.width else size.height
    if (bw > 0 && bh > 0) {
        val k = 720f / min(bw, bh)
        rw = (bw * k).toInt().coerceAtLeast(1)
        rh = (bh * k).toInt().coerceAtLeast(1)
    } else { rw = 0; rh = 0 }

    val fix = st.fix
    val latKey = fix?.lat?.let { (it * 1e5).roundToLong() }
    val lonKey = fix?.lon?.let { (it * 1e5).roundToLong() }
    val mapReq = if (rw > 0) StampRenderer.mapBoxSize(rw, rh, cfg) else null

    LaunchedEffect(latKey, lonKey, mapReq, cfg.mapZoom, cfg.mapStyle) {
        val f = fix
        mapBmp = if (mapReq == null || f == null) null
        else MapRenderer.render(ctx, cfg.mapStyle, f.lat, f.lon, cfg.mapZoom, mapReq.first, mapReq.second, true, f.accuracyM)
    }

    val now = System.currentTimeMillis()
    val bucket = if (cfg.showSeconds) 1000L else 60_000L
    val data = st.toStampData(now / bucket * bucket).let { it.copy(fixAgeMs = it.fixAgeMs?.let { a -> a / 10_000L * 10_000L }) }

    LaunchedEffect(cfg, data, mapBmp, logo, rw, rh) {
        if (rw <= 0) return@LaunchedEffect
        val hit = StampRenderer.StampHit()
        image = withContext(Dispatchers.Default) {
            val bmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
            StampRenderer.draw(Canvas(bmp), rw, rh, cfg, data, mapBmp, logo, placeholder = onLogoTap != null, hit = hit)
            bmp.asImageBitmap()
        }
        logoRect = hit.logo
    }

    Box(modifier.onSizeChanged { size = it }.clipToBounds(), contentAlignment = Alignment.Center) {
        val d = androidx.compose.ui.platform.LocalDensity.current
        if (bw > 0 && bh > 0) {
            val th = Math.toRadians(angle.toDouble())
            val c = abs(cos(th)).toFloat()
            val sn = abs(sin(th)).toFloat()
            // scale so the rotating frame always stays inside the preview (1.0 when upright)
            val fit = min(size.width / (bw * c + bh * sn), size.height / (bw * sn + bh * c)).coerceAtMost(1f)
            Box(
                Modifier
                    .requiredSize(with(d) { bw.toDp() }, with(d) { bh.toDp() })
                    .graphicsLayer { rotationZ = angle; scaleX = fit; scaleY = fit },
            ) {
                image?.let { Image(it, contentDescription = "Stamp preview", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds) }
                val lr = logoRect
                if (onLogoTap != null && lr != null && rw > 0) {
                    val sx = bw.toFloat() / rw
                    val sy = bh.toFloat() / rh
                    Box(
                        Modifier
                            .offset(with(d) { (lr.left * sx).toDp() }, with(d) { (lr.top * sy).toDp() })
                            .size(with(d) { (lr.width() * sx).toDp() }, with(d) { (lr.height() * sy).toDp() })
                            .clickable { onLogoTap() },
                    )
                }
            }
        }
    }
}
