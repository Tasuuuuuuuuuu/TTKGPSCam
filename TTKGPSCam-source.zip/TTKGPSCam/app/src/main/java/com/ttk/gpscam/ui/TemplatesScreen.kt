package com.ttk.gpscam.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ttk.gpscam.MainViewModel
import com.ttk.gpscam.core.CoordFormat
import com.ttk.gpscam.core.UnitSystem
import com.ttk.gpscam.data.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun TemplatesScreen(vm: MainViewModel, settings: AppSettings) {
    LocationEffect(vm)
    val st by vm.location.state.collectAsState()
    val logo by vm.logo.collectAsState()
    val c = settings.stamp
    var saveDialog by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let { vm.importLogo(it) } }
    fun u(f: (StampConfig) -> StampConfig) = vm.updateStamp(f)

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Templates", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp))
        Box(Modifier.fillMaxWidth().height(290.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.fillMaxHeight().padding(vertical = 4.dp).aspectRatio(3f / 4f).clip(RoundedCornerShape(16.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF5B7A8C), Color(0xFF2B3A44)))),
            ) {
                StampOverlay(cfg = c, st = st, logo = logo, modifier = Modifier.fillMaxSize())
                if (!st.hasFix) Text(
                    "Preview – waiting for a real GPS fix", color = Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.TopCenter).padding(8.dp),
                )
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Templates.builtIn) { t ->
                    TemplateCard(t.name, t.description, c.templateId == t.id) { vm.applyTemplate(t.id) }
                }
                items(settings.customTemplates) { t ->
                    TemplateCard("★ ${t.name}", "Saved template", c.templateId == t.id) { vm.applyCustomTemplate(t) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { saveDialog = true }, Modifier.weight(1f)) { Text("Save as template") }
                OutlinedButton(onClick = { vm.resetCurrentTemplate() }, Modifier.weight(1f)) { Text("Reset") }
            }
            if (settings.customTemplates.any { it.id == c.templateId }) {
                OutlinedButton(onClick = { vm.deleteCustomTemplate(c.templateId) }, Modifier.fillMaxWidth()) { Text("Delete this saved template") }
            }

            SectionCard("Layout & position") {
                ChoiceRow("Dashboard position", StampPosition.entries, c.position, { it.label }) { v -> u { it.copy(position = v) } }
                SliderRow("Card size (width)", c.cardWidth, 0.3f..1f, "${(c.cardWidth * 100).roundToInt()}%", { v -> u { it.copy(cardWidth = v) } })
                ChoiceRow("Text alignment", TextAlignment.entries, c.align, { it.label }) { v -> u { it.copy(align = v) } }
                SliderRow("Padding", c.padding, 6f..50f, c.padding.roundToInt().toString(), { v -> u { it.copy(padding = v) } })
                SliderRow("Line spacing", c.spacing, 2f..24f, c.spacing.roundToInt().toString(), { v -> u { it.copy(spacing = v) } })
            }
            SectionCard("Style") {
                ChoiceRow("Font", FontFace.entries, c.fontFace, { it.label }) { v -> u { it.copy(fontFace = v) } }
                SliderRow("Font size", c.fontScale, 0.6f..1.6f, "${(c.fontScale * 100).roundToInt()}%", { v -> u { it.copy(fontScale = v) } })
                ColorRow("Text color", c.textColor) { v -> u { it.copy(textColor = v) } }
                ColorRow("Background color", c.bgColor) { v -> u { it.copy(bgColor = v) } }
                SliderRow("Background opacity", c.bgOpacity, 0f..1f, "${(c.bgOpacity * 100).roundToInt()}%", { v -> u { it.copy(bgOpacity = v) } })
                SliderRow("Card transparency (overall opacity)", c.cardAlpha, 0.3f..1f, "${(c.cardAlpha * 100).roundToInt()}%", { v -> u { it.copy(cardAlpha = v) } })
                SliderRow("Corner radius", c.cornerRadius, 0f..50f, c.cornerRadius.roundToInt().toString(), { v -> u { it.copy(cornerRadius = v) } })
                SwitchRow("Border", c.borderOn, { v -> u { it.copy(borderOn = v) } })
                if (c.borderOn) {
                    ColorRow("Border color", c.borderColor) { v -> u { it.copy(borderColor = v) } }
                    SliderRow("Border thickness", c.borderWidth, 1f..10f, c.borderWidth.roundToInt().toString(), { v -> u { it.copy(borderWidth = v) } })
                }
                SwitchRow("Shadow", c.shadow, { v -> u { it.copy(shadow = v) } })
            }
            SectionCard("Map") {
                SwitchRow("Show map", c.showMap, { v -> u { it.copy(showMap = v) } }, "Omitted automatically when map tiles are unavailable")
                if (c.showMap) {
                    ChoiceRow("Map position", MapPos.entries, c.mapPos, { it.label }) { v -> u { it.copy(mapPos = v) } }
                    SliderRow("Map size", c.mapSize, 0.15f..0.6f, "${(c.mapSize * 100).roundToInt()}%", { v -> u { it.copy(mapSize = v) } })
                    SliderRow("Map zoom", c.mapZoom.toFloat(), 8f..19f, c.mapZoom.toString(), { v -> u { it.copy(mapZoom = v.roundToInt()) } }, steps = 10)
                    ChoiceRow("Map style", MapStyle.entries, c.mapStyle, { it.label }) { v -> u { it.copy(mapStyle = v, mapZoom = minOf(it.mapZoom, v.maxZoom)) } }
                }
            }
            StampInfoSection(vm, c)
            SectionCard("Text") {
                TextRow("Company / brand name", c.companyName, { v -> u { it.copy(companyName = v) } })
                TextRow("Custom title", c.title, { v -> u { it.copy(title = v) } })
                TextRow("Custom subtitle", c.subtitle, { v -> u { it.copy(subtitle = v) } })
                TextRow("Custom text", c.customText, { v -> u { it.copy(customText = v) } }, singleLine = false)
            }
            StampFormatSection(vm, c)
            SectionCard("Company logo") {
                if (logo != null) {
                    Box(Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF8899A0)), contentAlignment = Alignment.Center) {
                        Image(logo!!.asImageBitmap(), "Logo", Modifier.padding(8.dp).fillMaxSize(), contentScale = ContentScale.Fit)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                        Text(if (logo == null) "Upload logo" else "Replace logo")
                    }
                    if (logo != null) OutlinedButton(onClick = { vm.removeLogo() }) { Text("Remove") }
                }
                Text("PNG, JPG or WebP. Transparency is kept and the logo is never stretched.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                SwitchRow("Show logo on photos", c.logoOn, { v -> u { it.copy(logoOn = v) } })
                SwitchRow("Show company name", c.showCompany, { v -> u { it.copy(showCompany = v) } })
                if (logo != null) {
                    ChoiceRow("Logo position", LogoPos.entries, c.logoPos, { it.label }) { v -> u { it.copy(logoPos = v) } }
                    ChoiceRow("Logo alignment", LogoAlign.entries, c.logoAlign, { it.label }) { v -> u { it.copy(logoAlign = v) } }
                    SliderRow("Logo size", c.logoSize, 30f..160f, c.logoSize.roundToInt().toString(), { v -> u { it.copy(logoSize = v) } })
                    SliderRow("Logo opacity", c.logoOpacity, 0.2f..1f, "${(c.logoOpacity * 100).roundToInt()}%", { v -> u { it.copy(logoOpacity = v) } })
                    SliderRow("Logo padding", c.logoPadding, 0f..30f, c.logoPadding.roundToInt().toString(), { v -> u { it.copy(logoPadding = v) } })
                    SwitchRow("Background behind logo", c.logoBgOn, { v -> u { it.copy(logoBgOn = v) } })
                    if (c.logoBgOn) {
                        ColorRow("Logo background color", c.logoBgColor) { v -> u { it.copy(logoBgColor = v) } }
                        SliderRow("Logo background transparency", c.logoBgOpacity, 0f..1f, "${(c.logoBgOpacity * 100).roundToInt()}%", { v -> u { it.copy(logoBgOpacity = v) } })
                    }
                    SwitchRow("Logo border", c.logoBorderOn, { v -> u { it.copy(logoBorderOn = v) } })
                    if (c.logoBorderOn) ColorRow("Logo border color", c.logoBorderColor) { v -> u { it.copy(logoBorderColor = v) } }
                    SliderRow("Logo corner radius", c.logoCorner, 0f..40f, c.logoCorner.roundToInt().toString(), { v -> u { it.copy(logoCorner = v) } })
                }
            }
        }
    }

    if (saveDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { saveDialog = false },
            title = { Text("Save custom template") },
            text = {
                Column {
                    Text("Saves the current look, map and logo style.", style = MaterialTheme.typography.bodySmall)
                    TextRow("Template name", name, { name = it })
                }
            },
            confirmButton = { TextButton(onClick = { vm.saveCustomTemplate(name); saveDialog = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { saveDialog = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun TemplateCard(name: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.width(150.dp).clip(RoundedCornerShape(14.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
        Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun StampInfoSection(vm: MainViewModel, c: StampConfig) {
    fun u(f: (StampConfig) -> StampConfig) = vm.updateStamp(f)
    SectionCard("Information shown") {
        SwitchRow("Address", c.showAddress, { v -> u { it.copy(showAddress = v) } })
        SwitchRow("Latitude & longitude", c.showCoords, { v -> u { it.copy(showCoords = v) } })
        SwitchRow("Date", c.showDate, { v -> u { it.copy(showDate = v) } })
        SwitchRow("Time", c.showTime, { v -> u { it.copy(showTime = v) } })
        SwitchRow("Time zone", c.showTimezone, { v -> u { it.copy(showTimezone = v) } })
        SwitchRow("Altitude", c.showAltitude, { v -> u { it.copy(showAltitude = v) } })
        SwitchRow("Speed", c.showSpeed, { v -> u { it.copy(showSpeed = v) } })
        SwitchRow("Compass direction", c.showCompass, { v -> u { it.copy(showCompass = v) } })
        SwitchRow("GPS accuracy", c.showAccuracy, { v -> u { it.copy(showAccuracy = v) } })
        SwitchRow("TTK GPS Cam badge", c.showAppBadge, { v -> u { it.copy(showAppBadge = v) } })
    }
}

@Composable
fun StampFormatSection(vm: MainViewModel, c: StampConfig) {
    fun u(f: (StampConfig) -> StampConfig) = vm.updateStamp(f)
    val now = Date()
    SectionCard("Formats & units") {
        ChoiceRow("Date format", DATE_FORMATS, c.dateFormat, { SimpleDateFormat(it, Locale.getDefault()).format(now) }) { v -> u { it.copy(dateFormat = v) } }
        SwitchRow("24-hour time", c.use24h, { v -> u { it.copy(use24h = v) } })
        SwitchRow("Show seconds", c.showSeconds, { v -> u { it.copy(showSeconds = v) } })
        ChoiceRow("Coordinate format", CoordFormat.entries, c.coordFormat, { it.label }) { v -> u { it.copy(coordFormat = v) } }
        ChoiceRow("Units", UnitSystem.entries, c.units, { it.label }) { v -> u { it.copy(units = v) } }
    }
}
