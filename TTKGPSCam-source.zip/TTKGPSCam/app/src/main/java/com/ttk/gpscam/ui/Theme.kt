package com.ttk.gpscam.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Teal = Color(0xFF0F766E)
val Amber = Color(0xFFFBBF24)

private val LightColors = lightColorScheme(
    primary = Teal, onPrimary = Color.White, primaryContainer = Color(0xFFCCF0EA), onPrimaryContainer = Color(0xFF00201C),
    secondary = Color(0xFFB45309), onSecondary = Color.White,
    background = Color(0xFFF4F7F7), onBackground = Color(0xFF10201F),
    surface = Color.White, onSurface = Color(0xFF10201F),
    surfaceVariant = Color(0xFFE3ECEB), onSurfaceVariant = Color(0xFF3F4F4E),
    outline = Color(0xFF7A8C8A),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5EEAD4), onPrimary = Color(0xFF00201C), primaryContainer = Color(0xFF0B4A44), onPrimaryContainer = Color(0xFFCCF0EA),
    secondary = Amber, onSecondary = Color(0xFF2B1D00),
    background = Color(0xFF0B1214), onBackground = Color(0xFFE2ECEA),
    surface = Color(0xFF121C1F), onSurface = Color(0xFFE2ECEA),
    surfaceVariant = Color(0xFF1E2B2E), onSurfaceVariant = Color(0xFFB4C4C2),
    outline = Color(0xFF6F8381),
)

@Composable
fun TtkTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        shapes = Shapes(
            small = RoundedCornerShape(10.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp),
        ),
        content = content,
    )
}
