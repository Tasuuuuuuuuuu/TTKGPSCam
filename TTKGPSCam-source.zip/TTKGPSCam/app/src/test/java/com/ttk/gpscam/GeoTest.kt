package com.ttk.gpscam

import com.ttk.gpscam.core.*
import org.junit.Assert.*
import org.junit.Test

class GeoTest {
    @Test fun accuracyLevels() {
        assertEquals(AccuracyLevel.EXCELLENT, Geo.accuracyLevel(3f))
        assertEquals(AccuracyLevel.GOOD, Geo.accuracyLevel(10f))
        assertEquals(AccuracyLevel.MODERATE, Geo.accuracyLevel(30f))
        assertEquals(AccuracyLevel.POOR, Geo.accuracyLevel(120f))
    }

    @Test fun decimalDegrees() {
        assertEquals("23.810331° N", Geo.coordinate(23.810331, true, CoordFormat.DD))
        assertEquals("90.412521° W", Geo.coordinate(-90.412521, false, CoordFormat.DD))
    }

    @Test fun dms() {
        assertEquals("23° 48′ 37.19″ N", Geo.coordinate(23.810331, true, CoordFormat.DMS))
        assertEquals("0° 0′ 0.00″ E", Geo.coordinate(0.0, false, CoordFormat.DMS))
    }

    @Test fun decimalMinutes() {
        assertEquals("23° 48.6199′ N", Geo.coordinate(23.810331, true, CoordFormat.DDM))
    }

    @Test fun cardinalPoints() {
        assertEquals("N", Geo.cardinal(0f))
        assertEquals("N", Geo.cardinal(359f))
        assertEquals("E", Geo.cardinal(90f))
        assertEquals("SW", Geo.cardinal(225f))
    }

    @Test fun units() {
        assertEquals("100 m", Geo.distance(100.0, UnitSystem.METRIC))
        assertEquals("328 ft", Geo.distance(100.0, UnitSystem.IMPERIAL))
        assertEquals("36.0 km/h", Geo.speed(10f, UnitSystem.METRIC))
    }

    @Test fun haversine() {
        val d = Geo.haversineMeters(0.0, 0.0, 0.0, 1.0)
        assertEquals(111195.0, d, 200.0)
    }

    @Test fun tileMathRoundTrip() {
        val z = 15
        val lat = 23.810331
        val lon = 90.412521
        val x = TileMath.worldX(lon, z)
        val y = TileMath.worldY(lat, z)
        assertEquals(lon, TileMath.lonFromX(x, z), 1e-6)
        assertEquals(lat, TileMath.latFromY(y, z), 1e-6)
    }

    @Test fun tileMathKnownTile() {
        // London (51.5074, -0.1278) at z=10 is tile x=511, y=340
        val z = 10
        assertEquals(511, (TileMath.worldX(-0.1278, z) / 256).toInt())
        assertEquals(340, (TileMath.worldY(51.5074, z) / 256).toInt())
    }
}
